#include "mainwindow.h"

#include <QMenuBar>
#include <QMenu>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QSplitter>
#include <QStandardItem>
#include <QLabel>
#include <QString>
#include <QVariantMap>
#include <QDebug>
#include <QCheckBox>
#include <QMessageBox>
#include <QMap>
#include <QGroupBox>




MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
{
    setModel( vfvpModel1 );
    vfvpMap.insert(vfvpModel1.charVfvp.vfvp_kod, &vfvpModel1);
    setModel1( vfvpModel2 );
    vfvpMap.insert(vfvpModel2.charVfvp.vfvp_kod, &vfvpModel2);
    setModel2( vfvpModel3 );
    vfvpMap.insert(vfvpModel3.charVfvp.vfvp_kod, &vfvpModel3);
    setModel3( vfvpModel4 );
    vfvpMap.insert(vfvpModel4.charVfvp.vfvp_kod, &vfvpModel4);
    setModel4( vfvpModel5 );
    vfvpMap.insert(vfvpModel5.charVfvp.vfvp_kod, &vfvpModel5);
    createTreeView();
    createTabWidget();

    QSplitter *splitter = new QSplitter(Qt::Horizontal, this);
    splitter->addWidget(treeView);
    splitter->addWidget(tabWidget);
    splitter->setStretchFactor(1, 1);
    splitter->setCollapsible(0, false);
    splitter->setCollapsible(1, false);

    QWidget *centralWidget = new QWidget(this);
    QVBoxLayout *layout = new QVBoxLayout(centralWidget);
    layout->addWidget(splitter);
    setCentralWidget(centralWidget);

    connect( treeView, SIGNAL( clicked(QModelIndex)),
            this, SLOT( onTreeViewItemClicked(QModelIndex))
             );

}

MainWindow::~MainWindow()
{
}
void MainWindow::createTreeView()
{
    model = new QStandardItemModel(this);
    QStandardItem* rootItem = model->invisibleRootItem();
    // Создал контейнер для помещения туда элементов верхнего уровня
    QList<QStandardItem*> topLevelItems;
    foreach (VFVPModel* vfvpModel, vfvpMap)
    {
        if (!hasParent(vfvpModel))
        {
            QStandardItem* parentItem = new QStandardItem(vfvpModel->charVfvp.vfvp_name);
            parentItem->setData(vfvpModel->charVfvp.vfvp_kod, Qt::UserRole);
            topLevelItems.append(parentItem);
        }
    }
    foreach (QStandardItem* item, topLevelItems)
    {
        rootItem->appendRow(item);
    }
    while (!topLevelItems.isEmpty())
    {
       QStandardItem* parentItem = topLevelItems.takeFirst();
        createChildItems(parentItem, topLevelItems);
    }
    treeView = new QTreeView(this);
    treeView->setModel(model);
    treeView->setHeaderHidden(true);
    treeView->setSelectionMode(QAbstractItemView::SingleSelection);
}

void MainWindow::createChildItems(QStandardItem* parentItem, QList<QStandardItem*>& topLevelItems)
{
    QString parentCode = parentItem->data(Qt::UserRole).toString();
    foreach (VFVPModel* childModel, vfvpMap)
    {
        if (childModel->charVfvp.vfvp_org == parentCode)
        {
            QStandardItem* childItem = new QStandardItem(childModel->charVfvp.vfvp_name);
            childItem->setData(childModel->charVfvp.vfvp_kod, Qt::UserRole);
            parentItem->appendRow(childItem);
            topLevelItems.append(childItem);
        }
    }
}

bool MainWindow::hasParent(VFVPModel* vfvpModel)
{
    QString parentCode = vfvpModel->charVfvp.vfvp_org;
    foreach (VFVPModel* otherModel, vfvpMap)
    {
        if (otherModel->charVfvp.vfvp_kod == parentCode)
            return true;
    }
    return false;
}

void MainWindow::createTabWidget()
{
    // добавляю вкладки
    tabWidget = new QTabWidget(this);

    tab2 = new QWidget(tabWidget);
    tab3 = new QWidget(tabWidget);
    tab4 = new QWidget(tabWidget);
    tab5 = new QWidget(tabWidget);
    tab6 = new QWidget(tabWidget);
//    tab2->setHidden(true);
//    tab3->setHidden(true);

    tabWidget->addTab(tab2, ("Положение ВФ [ pvfvp ]"));    
    tabWidget->addTab(tab3, ("Направление действий ВФ [ ndvfvp ]"));
    tabWidget->addTab(tab4, ("Личный состав"));
    tabWidget->addTab(tab5, ("ВВТ [ vvtvfvp ]"));
    tabWidget->addTab(tab6, ("Картографические данные [ kdou ]"));


    //tabIndex2 = 0;
    tabIndex2 = tabWidget->indexOf(tab2);
    tabWidget->removeTab(tabIndex2);
    // Обновление значения tabIndex2
    tabIndex2 = 0;
   // tabIndex3 = 1;
    tabIndex3 = tabWidget->indexOf(tab3);
    tabWidget->removeTab(tabIndex3);
    // Обновление значения tabIndex3
    tabIndex3 = 1;
    tabIndex4 = tabWidget->indexOf(tab4);
    tabWidget->removeTab(tabIndex4);
    // Обновление значения tabIndex5
    tabIndex4 = 2;
   // tabIndex4 = 2;
    tabIndex5 = tabWidget->indexOf(tab5);
    tabWidget->removeTab(tabIndex5);
    // Обновление значения tabIndex4
    tabIndex5 = 3;
    //tabIndex5 = 3;
    tabIndex8 = tabWidget->indexOf(tab6);
    tabWidget->removeTab(tabIndex8);
    // Обновление значения tabIndex5
    tabIndex8 = 4;

     activeTabIndex = tabWidget->currentIndex();

    // onTreeViewItemClicked(activeTabIndex);
    // Установка текущей вкладки на первую

//     tabWidget->setCurrentIndex(0);
    // tabWidget->setTabVisible(tabIndex4, false);
   // tabWidget->setTabEnabled(tabWidget->indexOf(tab6), false);

//    QVBoxLayout *tab6Layout = new QVBoxLayout(tab6);
//    textTab6Edit1 = new QLineEdit(tab6);
//    textTab6Edit1->setObjectName("TextEdit1Tab6");
//    textTab6Edit2 = new QLineEdit(tab6);
//    textTab6Edit2->setObjectName("TextEdit2Tab6");
//    textTab6Edit3 = new QLineEdit(tab6);
//    textTab6Edit3->setObjectName("TextEdit3Tab6");
//    textTab6Edit4 = new QLineEdit(tab6);
//    textTab6Edit4->setObjectName("TextEdit4Tab6");
//    textTab6Edit5 = new QLineEdit(tab6);
//    textTab6Edit5->setObjectName("TextEdit5Tab6");
//    textTab6Edit6 = new QLineEdit(tab6);
//    textTab6Edit6->setObjectName("TextEdit6Tab6");
//    textTab6Edit7 = new QLineEdit(tab6);
//    textTab6Edit7->setObjectName("TextEdit7Tab6");


//tab6->setLayout( tab6Layout );


//    QLabel *labelc1Tab6 = new QLabel(("Ключ знака ( уникальный идентификатор )"), tab6);
//    QLabel *labelc2Tab6 = new QLabel(("Код знака ( код серии знаков )"), tab6);
//    QLabel *labelc3Tab6 = new QLabel(("Тип знака ( векторный / линейный / площадной )"), tab6);
//    QLabel *labelc4Tab6 = new QLabel(("Метрика знака. Координаты объекта ( 1я точка - расположение знака )"), tab6);

//    QLabel *labelc5Tab6 = new QLabel(("Метрика знака. Координаты объекта ( 2я точка - направление знака )"), tab6);
//    QLabel *labelc6Tab6 = new QLabel(("Семантика знака. Надпись внутри знака "), tab6);
//    QLabel *labelc7Tab6 = new QLabel(("Семантика знака. Надпись возле знака"), tab6);




//    textTab6Edit1->setReadOnly(true);
//    textTab6Edit2->setReadOnly(true);
//    textTab6Edit3->setReadOnly(true);
//    textTab6Edit4->setReadOnly(true);
//    textTab6Edit5->setReadOnly(true);
//    textTab6Edit6->setReadOnly(true);
//    textTab6Edit7->setReadOnly(true);


//    // устанавливаю layouts
//    tab6Layout->addWidget(labelc1Tab6);
//    tab6Layout->addWidget(textTab6Edit1);
//    tab6Layout->addWidget(labelc2Tab6);
//    tab6Layout->addWidget(textTab6Edit2);
//    tab6Layout->addWidget(labelc3Tab6);
//    tab6Layout->addWidget(textTab6Edit3);
//    tab6Layout->addWidget(labelc4Tab6);
//    tab6Layout->addWidget(textTab6Edit4);
//    tab6Layout->addWidget(labelc5Tab6);
//    tab6Layout->addWidget(textTab6Edit5);
//    tab6Layout->addWidget(labelc6Tab6);
//    tab6Layout->addWidget(textTab6Edit6);
//    tab6Layout->addWidget(labelc7Tab6);
//    tab6Layout->addWidget(textTab6Edit7);

//    tab6Layout->addStretch(1);



//        QVBoxLayout *tab6Layout = new QVBoxLayout(tab6);
//        textTab6Edit1 = new QLineEdit(tab6);
//        textTab6Edit1->setObjectName("TextEdit1Tab6");
//        textTab6Edit2 = new QLineEdit(tab6);
//        textTab6Edit2->setObjectName("TextEdit2Tab6");
//        textTab6Edit3 = new QLineEdit(tab6);
//        textTab6Edit3->setObjectName("TextEdit3Tab6");
//        textTab6Edit4 = new QLineEdit(tab6);
//        textTab6Edit4->setObjectName("TextEdit4Tab6");
//        textTab6Edit5 = new QLineEdit(tab6);
//        textTab6Edit5->setObjectName("TextEdit5Tab6");
//        textTab6Edit6 = new QLineEdit(tab6);
//        textTab6Edit6->setObjectName("TextEdit6Tab6");
//        textTab6Edit7 = new QLineEdit(tab6);
//        textTab6Edit7->setObjectName("TextEdit7Tab6");
//        textTab6Edit8 = new QLineEdit(tab6);
//        textTab6Edit8->setObjectName("TextEdit8Tab6");
//        textTab6Edit9 = new QLineEdit(tab6);
//        textTab6Edit9->setObjectName("TextEdit9Tab6");

//        tab6->setLayout(tab6Layout);

//        QLabel *labelc1Tab6 = new QLabel(("Ключ знака ( уникальный идентификатор )"), tab6);
//        QLabel *labelc2Tab6 = new QLabel(("Код знака ( код серии знаков )"), tab6);
//        QLabel *labelc3Tab6 = new QLabel(("Тип знака (  )"), tab6);
//        QLabel *labelc4Tab6 = new QLabel(("Координаты x y ( 1я точка - расположение знака )"), tab6);
//        QLabel *labelc5Tab6 = new QLabel(("Координата x:"), tab6);
//        QLabel *labelc6Tab6 = new QLabel(("Координата y:"), tab6);
//        QLabel *labelc7Tab6 = new QLabel(("Координаты x y ( 2я точка - направление знака )"), tab6);
//        QLabel *labelc8Tab6 = new QLabel((" Надпись внутри знака "), tab6);
//        QLabel *labelc9Tab6 = new QLabel((" Надпись возле знака"), tab6);

//        textTab6Edit1->setReadOnly(true);
//        textTab6Edit2->setReadOnly(true);
//        textTab6Edit3->setReadOnly(true);
//        textTab6Edit4->setReadOnly(true);
//        textTab6Edit5->setReadOnly(true);
//        textTab6Edit6->setReadOnly(true);
//        textTab6Edit7->setReadOnly(true);
//        textTab6Edit8->setReadOnly(true);
//        textTab6Edit9->setReadOnly(true);

//        // устанавливаю layouts
//        tab6Layout->addWidget(labelc1Tab6);
//        tab6Layout->addWidget(textTab6Edit1);
//        tab6Layout->addWidget(labelc2Tab6);
//        tab6Layout->addWidget(textTab6Edit2);
//        tab6Layout->addWidget(labelc3Tab6);
//        tab6Layout->addWidget(textTab6Edit3);
//        tab6Layout->addWidget(labelc4Tab6);
//        tab6Layout->addWidget(textTab6Edit4);
//        tab6Layout->addWidget(labelc5Tab6);
//        tab6Layout->addWidget(textTab6Edit5);
//        tab6Layout->addWidget(labelc6Tab6);
//        tab6Layout->addWidget(textTab6Edit6);
//        tab6Layout->addWidget(labelc7Tab6);
//        tab6Layout->addWidget(textTab6Edit7);
//        tab6Layout->addWidget(labelc8Tab6);
//        tab6Layout->addWidget(textTab6Edit8);
//        tab6Layout->addWidget(labelc9Tab6);
//        tab6Layout->addWidget(textTab6Edit9);

//        tab6Layout->addStretch(1);


//        QVBoxLayout *tab6Layout = new QVBoxLayout(tab6);

//        QHBoxLayout *rowLayout1 = new QHBoxLayout;
//        QLabel *labelc1Tab6 = new QLabel(("Ключ знака ( уникальный идентификатор )"), tab6);
//        QLabel *labelc2Tab6 = new QLabel(("Код знака ( код серии знаков )"), tab6);
//        QLabel *labelc3Tab6 = new QLabel(("Тип знака (  )"), tab6);
//        QLabel *labelc4Tab6 = new QLabel(("Координаты x y ( 1я точка - расположение знака )"), tab6);

//        QLineEdit *textTab6Edit1 = new QLineEdit(tab6);
//        QLineEdit *textTab6Edit2 = new QLineEdit(tab6);
//        QLineEdit *textTab6Edit3 = new QLineEdit(tab6);

//        rowLayout1->addWidget(labelc1Tab6);
//        rowLayout1->addWidget(textTab6Edit1);
//        rowLayout1->addWidget(labelc2Tab6);
//        rowLayout1->addWidget(textTab6Edit2);
//        rowLayout1->addWidget(labelc3Tab6);
//        rowLayout1->addWidget(textTab6Edit3);
//        tab6Layout->addLayout(rowLayout1);

//        QHBoxLayout *rowLayout2 = new QHBoxLayout;
//        QLabel *labelc5Tab6 = new QLabel(("Координата x:"), tab6);
//        QLabel *labelc6Tab6 = new QLabel(("Координата y:"), tab6);
//        QLabel *labelc7Tab6 = new QLabel(("Координаты x y ( 2я точка - направление знака )"), tab6);

//        QLineEdit *textTab6Edit4 = new QLineEdit(tab6);
//        QLineEdit *textTab6Edit5 = new QLineEdit(tab6);
//        QLineEdit *textTab6Edit6 = new QLineEdit(tab6);

//        rowLayout2->addWidget(labelc4Tab6);
//        rowLayout2->addWidget(textTab6Edit4);
//        rowLayout2->addWidget(labelc5Tab6);
//        rowLayout2->addWidget(textTab6Edit5);
//        rowLayout2->addWidget(labelc6Tab6);
//        rowLayout2->addWidget(textTab6Edit6);
//        tab6Layout->addLayout(rowLayout2);

//        QLabel *labelc8Tab6 = new QLabel((" Надпись внутри знака "), tab6);
//        QLabel *labelc9Tab6 = new QLabel((" Надпись возле знака"), tab6);

//        QLineEdit *textTab6Edit8 = new QLineEdit(tab6);
//        QLineEdit *textTab6Edit9 = new QLineEdit(tab6);

//        tab6Layout->addWidget(labelc7Tab6);
//        tab6Layout->addWidget(textTab6Edit7);
//        tab6Layout->addWidget(labelc8Tab6);
//        tab6Layout->addWidget(textTab6Edit8);
//        tab6Layout->addWidget(labelc9Tab6);
//        tab6Layout->addWidget(textTab6Edit9);
//        tab6Layout->addStretch(1);

//        tab6->setLayout(tab6Layout);

/// Почти рабочий
//        QVBoxLayout *tab6Layout = new QVBoxLayout(tab6);
//        tab6->setLayout(tab6Layout);

//        QLabel *labelc1Tab6 = new QLabel(("Ключ знака ( уникальный идентификатор )"), tab6);
//        QLabel *labelc2Tab6 = new QLabel(("Код знака ( код серии знаков )"), tab6);
//        QLabel *labelc3Tab6 = new QLabel(("Тип знака (  )"), tab6);
//        QLabel *labelc4Tab6 = new QLabel(("Координаты x y ( 1я точка - расположение знака )"), tab6);
//        QLabel *labelc5Tab6 = new QLabel(("Координата x:"), tab6);
//        QLabel *labelc6Tab6 = new QLabel(("Координата y:"), tab6);
//        QLabel *labelc7Tab6 = new QLabel(("Координаты x y ( 2я точка - направление знака )"), tab6);
//        QLabel *labelc8Tab6 = new QLabel((" Надпись внутри знака "), tab6);
//        QLabel *labelc9Tab6 = new QLabel((" Надпись возле знака"), tab6);

//        textTab6Edit1 = new QLineEdit(tab6);
//        textTab6Edit1->setObjectName("TextEdit1Tab6");
//        textTab6Edit2 = new QLineEdit(tab6);
//        textTab6Edit2->setObjectName("TextEdit2Tab6");
//        textTab6Edit3 = new QLineEdit(tab6);
//        textTab6Edit3->setObjectName("TextEdit3Tab6");
////        textTab6Edit4 = new QLineEdit(tab6);
////        textTab6Edit4->setObjectName("TextEdit4Tab6");
//        textTab6Edit5 = new QLineEdit(tab6);
//        textTab6Edit5->setObjectName("TextEdit5Tab6");
//        textTab6Edit6 = new QLineEdit(tab6);
//        textTab6Edit6->setObjectName("TextEdit6Tab6");
//        textTab6Edit7 = new QLineEdit(tab6);
//        textTab6Edit7->setObjectName("TextEdit7Tab6");
//        textTab6Edit8 = new QLineEdit(tab6);
//        textTab6Edit8->setObjectName("TextEdit8Tab6");
//        textTab6Edit9 = new QLineEdit(tab6);
//        textTab6Edit9->setObjectName("TextEdit9Tab6");

//        textTab6Edit1->setReadOnly(true);
//        textTab6Edit2->setReadOnly(true);
//        textTab6Edit3->setReadOnly(true);
//        //textTab6Edit4->setReadOnly(true);
//        textTab6Edit5->setReadOnly(true);
//        textTab6Edit6->setReadOnly(true);
//        textTab6Edit7->setReadOnly(true);
//        textTab6Edit8->setReadOnly(true);
//        textTab6Edit9->setReadOnly(true);

//        QHBoxLayout *row1Layout = new QHBoxLayout();
//        row1Layout->addWidget(labelc5Tab6);
//        row1Layout->addWidget(textTab6Edit5);

//        QHBoxLayout *row2Layout = new QHBoxLayout();
//        row2Layout->addWidget(labelc6Tab6);
//        row2Layout->addWidget(textTab6Edit6);

//        tab6Layout->addWidget(labelc1Tab6);
//        tab6Layout->addWidget(textTab6Edit1);
//        tab6Layout->addWidget(labelc2Tab6);
//        tab6Layout->addWidget(textTab6Edit2);
//        tab6Layout->addWidget(labelc3Tab6);
//        tab6Layout->addWidget(textTab6Edit3);
//        tab6Layout->addWidget(labelc4Tab6);
//      //  tab6Layout->addWidget(textTab6Edit4);
//        tab6Layout->addLayout(row1Layout);
//        tab6Layout->addLayout(row2Layout);
//        tab6Layout->addWidget(labelc7Tab6);
//        tab6Layout->addWidget(textTab6Edit7);
//        tab6Layout->addWidget(labelc8Tab6);
//        tab6Layout->addWidget(textTab6Edit8);
//        tab6Layout->addWidget(labelc9Tab6);
//        tab6Layout->addWidget(textTab6Edit9);
//        tab6Layout->addStretch(1);



//        QGridLayout *tab6Layout = new QGridLayout(tab6);
//        tab6->setLayout(tab6Layout);

//        QLabel *labelc1Tab6 = new QLabel(("Ключ знака ( уникальный идентификатор )"), tab6);
//        QLabel *labelc2Tab6 = new QLabel(("Код знака ( код серии знаков )"), tab6);
//        QLabel *labelc3Tab6 = new QLabel(("Тип знака (  )"), tab6);
//        QLabel *labelc4Tab6 = new QLabel(("Координаты x y ( 1я точка - расположение знака )"), tab6);
//        QLabel *labelc5Tab6 = new QLabel(("Координата x:"), tab6);
//        QLabel *labelc6Tab6 = new QLabel(("Координата y:"), tab6);
//        QLabel *labelc7Tab6 = new QLabel(("Координаты x y ( 2я точка - направление знака )"), tab6);
//        QLabel *labelc8Tab6 = new QLabel((" Надпись внутри знака "), tab6);
//        QLabel *labelc9Tab6 = new QLabel((" Надпись возле знака"), tab6);

//        textTab6Edit1 = new QLineEdit(tab6);
//        textTab6Edit1->setObjectName("TextEdit1Tab6");
//        textTab6Edit2 = new QLineEdit(tab6);
//        textTab6Edit2->setObjectName("TextEdit2Tab6");
//        textTab6Edit3 = new QLineEdit(tab6);
//        textTab6Edit3->setObjectName("TextEdit3Tab6");
//        textTab6Edit5 = new QLineEdit(tab6);
//        textTab6Edit5->setObjectName("TextEdit5Tab6");
//        textTab6Edit6 = new QLineEdit(tab6);
//        textTab6Edit6->setObjectName("TextEdit6Tab6");
//        textTab6Edit7 = new QLineEdit(tab6);
//        textTab6Edit7->setObjectName("TextEdit7Tab6");
//        textTab6Edit8 = new QLineEdit(tab6);
//        textTab6Edit8->setObjectName("TextEdit8Tab6");
//        textTab6Edit9 = new QLineEdit(tab6);
//        textTab6Edit9->setObjectName("TextEdit9Tab6");

//        textTab6Edit1->setReadOnly(true);
//        textTab6Edit2->setReadOnly(true);
//        textTab6Edit3->setReadOnly(true);
//        textTab6Edit5->setReadOnly(true);
//        textTab6Edit6->setReadOnly(true);
//        textTab6Edit7->setReadOnly(true);
//        textTab6Edit8->setReadOnly(true);
//        textTab6Edit9->setReadOnly(true);

//        tab6Layout->addWidget(labelc1Tab6, 0, 0);
//        tab6Layout->addWidget(textTab6Edit1, 0, 1);
//        tab6Layout->addWidget(labelc2Tab6, 1, 0);
//        tab6Layout->addWidget(textTab6Edit2, 1, 1);
//        tab6Layout->addWidget(labelc3Tab6, 2, 0);
//        tab6Layout->addWidget(textTab6Edit3, 2, 1);
//        tab6Layout->addWidget(labelc4Tab6, 3, 0);
//        tab6Layout->addWidget(labelc5Tab6, 4, 0);
//        tab6Layout->addWidget(textTab6Edit5, 4, 1);
//        tab6Layout->addWidget(labelc6Tab6, 4, 2);
//        tab6Layout->addWidget(textTab6Edit6, 4, 3);
//        tab6Layout->addWidget(labelc7Tab6, 5, 0);
//        tab6Layout->addWidget(textTab6Edit7, 5, 1);
//        tab6Layout->addWidget(labelc8Tab6, 6, 0);
//        tab6Layout->addWidget(textTab6Edit8, 6, 1);
//        tab6Layout->addWidget(labelc9Tab6, 7, 0);
//        tab6Layout->addWidget(textTab6Edit9, 7, 1);
//        tab6Layout->setColumnStretch(2, 1);

//        tab6Layout->setColumnMinimumWidth(1, 100); // Ширина столбца 1

//        tab6Layout->setRowMinimumHeight(4, 30); // Высота строки 4

/// РАБОТАЕТ
//        QVBoxLayout *tab6Layout = new QVBoxLayout(tab6);
//        tab6->setLayout(tab6Layout);

//        QLabel *labelc1Tab6 = new QLabel(("Ключ знака ( уникальный идентификатор )"), tab6);
//        QLabel *labelc2Tab6 = new QLabel(("Код знака ( код серии знаков )"), tab6);
//        QLabel *labelc3Tab6 = new QLabel(("Тип знака (  )"), tab6);
//        QLabel *labelc4Tab6 = new QLabel((" 1я точка - расположение знака "), tab6);
//        QLabel *labelc5Tab6 = new QLabel(("X:"), tab6);
//        QLabel *labelc6Tab6 = new QLabel(("Y:"), tab6);

//        QLabel *labelc7Tab6 = new QLabel((" 2я точка - направление знака    "), tab6);
////        QLabel *labelc8Tab6 = new QLabel(("Координаты x : y"), tab6);
//        QLabel *labelc8Tab6 = new QLabel(("X:"), tab6);
//        QLabel *labelc9Tab6 = new QLabel(("Y:"), tab6);
//        QLabel *labelc10Tab6 = new QLabel((" Надпись внутри знака "), tab6);
//        QLabel *labelc11Tab6 = new QLabel(("Ключ:"), tab6);
//        QLabel *labelc12Tab6 = new QLabel(("Значение:"), tab6);
//        QLabel *labelc13Tab6 = new QLabel((" Надпись возле знака   "), tab6);
//        QLabel *labelc14Tab6 = new QLabel(("Ключ:"), tab6);
//        QLabel *labelc15Tab6 = new QLabel(("Значение:"), tab6);

//        textTab6Edit1 = new QLineEdit(tab6);
//        textTab6Edit1->setObjectName("TextEdit1Tab6");
//        textTab6Edit2 = new QLineEdit(tab6);
//        textTab6Edit2->setObjectName("TextEdit2Tab6");
//        textTab6Edit3 = new QLineEdit(tab6);
//        textTab6Edit3->setObjectName("TextEdit3Tab6");

//        textTab6Edit5 = new QLineEdit(tab6);
//        textTab6Edit5->setObjectName("TextEdit5Tab6");
//        textTab6Edit6 = new QLineEdit(tab6);
//        textTab6Edit6->setObjectName("TextEdit6Tab6");

//        textTab6Edit7 = new QLineEdit(tab6);
//        textTab6Edit7->setObjectName("TextEdit7Tab6");
//        textTab6Edit8 = new QLineEdit(tab6);
//        textTab6Edit8->setObjectName("TextEdit8Tab6");

//        textTab6Edit9 = new QLineEdit(tab6);
//        textTab6Edit9->setObjectName("TextEdit9Tab6");
//        textTab6Edit10 = new QLineEdit(tab6);
//        textTab6Edit10->setObjectName("TextEdit10Tab6");
//        textTab6Edit11 = new QLineEdit(tab6);
//        textTab6Edit11->setObjectName("TextEdit11Tab6");
//        textTab6Edit12 = new QLineEdit(tab6);
//        textTab6Edit12->setObjectName("TextEdit12Tab6");

//        textTab6Edit1->setReadOnly(true);
//        textTab6Edit2->setReadOnly(true);
//        textTab6Edit3->setReadOnly(true);
//        textTab6Edit5->setReadOnly(true);
//        textTab6Edit6->setReadOnly(true);
//        textTab6Edit7->setReadOnly(true);
//        textTab6Edit8->setReadOnly(true);
//        textTab6Edit9->setReadOnly(true);
//        textTab6Edit10->setReadOnly(true);
//        textTab6Edit11->setReadOnly(true);
//        textTab6Edit12->setReadOnly(true);

//     //  groupBox->setObjectName("groupBox");

//        QHBoxLayout *coordinatesLayout = new QHBoxLayout();
//        coordinatesLayout->addWidget(labelc4Tab6);

//        coordinatesLayout->addWidget(labelc5Tab6);
//        coordinatesLayout->addWidget(textTab6Edit5);
//        coordinatesLayout->addWidget(labelc6Tab6);
//        coordinatesLayout->addWidget(textTab6Edit6);

//        QHBoxLayout *coordinatesLayout2 = new QHBoxLayout();
//        coordinatesLayout2->addWidget(labelc7Tab6);

//        coordinatesLayout2->addWidget(labelc8Tab6);
//        coordinatesLayout2->addWidget(textTab6Edit7);
//        coordinatesLayout2->addWidget(labelc9Tab6);
//        coordinatesLayout2->addWidget(textTab6Edit8);

//        QGroupBox *groupBox = new QGroupBox("Метрика");
//        QVBoxLayout *groupBoxLayout =new QVBoxLayout();
//        groupBoxLayout->addLayout(coordinatesLayout);
//         groupBoxLayout->addLayout(coordinatesLayout2);

//         groupBox->setLayout(groupBoxLayout);



//         QHBoxLayout *coordinatesLayoutS = new QHBoxLayout();
//         coordinatesLayoutS->addWidget(labelc10Tab6);
//         coordinatesLayoutS->addWidget(labelc11Tab6);
//         coordinatesLayoutS->addWidget(textTab6Edit9);
//         coordinatesLayoutS->addWidget(labelc12Tab6);
//         coordinatesLayoutS->addWidget(textTab6Edit10);

//         QHBoxLayout *coordinatesLayoutS2 = new QHBoxLayout();
//         coordinatesLayoutS2->addWidget(labelc13Tab6);

//         coordinatesLayoutS2->addWidget(labelc14Tab6);
//         coordinatesLayoutS2->addWidget(textTab6Edit11);
//         coordinatesLayoutS2->addWidget(labelc15Tab6);
//         coordinatesLayoutS2->addWidget(textTab6Edit12);

//         QGroupBox *groupBox2 = new QGroupBox("Семантика");
//         QVBoxLayout *groupBoxLayoutS =new QVBoxLayout();
//         groupBoxLayoutS->addLayout(coordinatesLayoutS);
//          groupBoxLayoutS->addLayout(coordinatesLayoutS2);

//          groupBox2->setLayout(groupBoxLayoutS);
////        QVBoxLayout *coordinatesContainer = new QVBoxLayout();
////        QWidget *coordinatesWidget = new QWidget();
////        coordinatesWidget->setLayout(coordinatesLayout);
////        coordinatesContainer->addWidget(coordinatesWidget);

////        QVBoxLayout *coordinatesContainer2 = new QVBoxLayout();
////        QWidget *coordinatesWidget2 = new QWidget();
////        coordinatesWidget2->setLayout(coordinatesLayout2);
////        coordinatesContainer2->addWidget(coordinatesWidget2);



//        tab6Layout->addWidget(labelc1Tab6);
//        tab6Layout->addWidget(textTab6Edit1);
//        tab6Layout->addWidget(labelc2Tab6);
//        tab6Layout->addWidget(textTab6Edit2);
//        tab6Layout->addWidget(labelc3Tab6);
//        tab6Layout->addWidget(textTab6Edit3);
//      //  tab6Layout->addWidget(labelc4Tab6);
//       // tab6Layout->addWidget(labelc4Tab6);
//       // tab6Layout->addLayout(coordinatesLayout);
////        tab6Layout->addWidget(labelc7Tab6);
//        tab6Layout->addWidget(groupBox);
//       // tab6Layout->addWidget(textTab6Edit8);
//        //tab6Layout->addWidget(labelc8Tab6);
//    //     tab6Layout->addLayout(coordinatesLayout2);
//       // tab6Layout->addWidget(coordinatesContainer2);
//       tab6Layout->addWidget(groupBox2);
////        tab6Layout->addWidget(labelc10Tab6);
////        tab6Layout->addWidget(textTab6Edit9);
////        tab6Layout->addWidget(labelc11Tab6);
////        tab6Layout->addWidget(textTab6Edit10);
//        tab6Layout->addStretch(1);
    }


/// задаем модель данных
void MainWindow::setModel( VFVPModel &vfvpmodel )
{
    /// Учетный номер ВФВП
       vfvpmodel.charVfvp.vfvp_kod = "1820000000000004555";

       vfvpmodel.charVfvp.vfvp_org = "1";

       vfvpmodel.charVfvp.vfvp_dt  = QDateTime::currentDateTime();
       vfvpmodel.charVfvp.vfvp_name  = "101 ШД";
   //    vfvpmodel->charVfvp.vfvp_sname  =
       LSVFVP lsVfvp;

           lsVfvp.lsdescription = QString( "личный состав" );

           lsVfvp.lskolshtat    = QString( "300" );
           ///
           lsVfvp.lskolnal      = QString( "30" );

           lsVfvp.lsukompl      = QString( "1" );

           vfvpmodel.lsVfvpLst.append( lsVfvp );
//    VVTVFVP vvtVfvp; /// инициализируем модель данных ВВТ
//    /// наименование блока
//    vvtVfvp.description = QString( "ВВТ" );
//    vvtVfvp.kkoovt_kod  = QString( "5025200" );
//    vvtVfvp.kolshtat    = QString( "300" );
//    vvtVfvp.kolnal      = QString( "30" );
//    vvtVfvp.ukompl      = QString( "3" );

//    vfvpmodel.vvtVfsvLst.append( vvtVfvp );

//    vvtVfvp.description = QString( "ВВТ1" );
//    vvtVfvp.kkoovt_kod  = QString( "5025201" );
//    vvtVfvp.kolshtat    = QString( "500" );
//    vvtVfvp.kolnal      = QString( "50" );
//    vvtVfvp.ukompl      = QString( "5" );
//    vfvpmodel.vvtVfsvLst.append( vvtVfvp );

//    vvtVfvp.description = QString( "ВВТ2" );
//    vvtVfvp.kkoovt_kod  = QString( "5025203" );
//    vvtVfvp.kolshtat    = QString( "600" );
//    vvtVfvp.kolnal      = QString( "60" );
//    vvtVfvp.ukompl      = QString( "6" );
//    vfvpmodel.vvtVfsvLst.append( vvtVfvp );

//    POSVFVP posVfvp; /// инициализируем модель данных положения

//    posVfvp.description = QString( "" );

//    posVfvp.latitude    = QString( "" );

//    posVfvp.longitude   = QString( "" );

//    posVfvp.height      = QString( "" );
//    posVfvp.OK          = QString( "" );

//    vfvpmodel.posVfvpLst.append( posVfvp );

        POSVFVP posVfvp; /// инициализируем модель данных положения

//        posVfvp.description = QString( "pvfvp" );

//        posVfvp.latitude    = QString( "314014573" );

//        posVfvp.longitude   = QString( "911885365" );

//        posVfvp.height      = QString( "404" );

//        posVfvp.OK          = QString( "Позиция на высоте 404" );

//        vfvpmodel.posVfvpLst.append( posVfvp );


        posVfvp.description = QString( "ndvfvp" );

        posVfvp.latitude    = QString( "9629163444433" );

        posVfvp.longitude   = QString( "382539000003" );

        posVfvp.height      = QString( "4054" );

        posVfvp.OK          = QString( "Направление на высоте 404" );

        vfvpmodel.posVfvpLst.append( posVfvp );

//        posVfvp.description = QString( "pvfvp" );

//        posVfvp.latitude    = QString( "554014573" );

//        posVfvp.longitude   = QString( "991885365" );

//        posVfvp.height      = QString( "407" );

//        posVfvp.OK          = QString( "Позиция на высоте 407" );

//        vfvpmodel.posVfvpLst.append( posVfvp );


        posVfvp.description = QString( "ndvfvp" );

        posVfvp.latitude    = QString( "342916333" );

        posVfvp.longitude   = QString( "558253903" );

        posVfvp.height      = QString( "4027" );

        posVfvp.OK          = QString( "Направление на высоте 4017" );

        vfvpmodel.posVfvpLst.append( posVfvp );

//            VVTVFVP vvtVfvp; /// инициализируем модель данных ВВТ
//            /// наименование блока ВВТ
//            vvtVfvp.description = QString( "ВВТ" );
//            /// код по классификатору "Конкретные образцы оружия и военной техники"
//            vvtVfvp.kkoovt_kod  = QString( "5025200" ); /// М706(V-100) "КОММАНДО"
//            /// колличество по штату ВВТ
//            vvtVfvp.kolshtat    = QString( "300" );
//            /// колличество в наличии ВВТ
//            vvtVfvp.kolnal      = QString( "30" );
//            /// укомплектованность ВВТ ( ну Вы поняли => 10 )
//            vvtVfvp.ukompl      = QString( "3" );
//            /// добавляем модель данных ВВТ в коллекцию
//            vfvpmodel.vvtVfsvLst.append( vvtVfvp );

            /** пример файла данных ГИС векторный
             *****************************
             * .KEY V77708012            *
             * .COD 77708012 VEC         *
             * .MET 1                    *
             * 2                         *
             * 56.314014573 42.911885365 *
             * 56.962916333 44.038253903 *
             * .SEM 2                    *
             * 5400 10 дшд               *
             * 9216 КП                   *
             *****************************
            **/
 TXFDataWorker txfDataWorker8;
            /// инициализируем модель картографических данных
        txfDataWorker8.setKEY( "S11708015" );
        /// код знака ( код серии знаков )
        txfDataWorker8.setCOD( "77708015" );
        /// тип знака ( векторный / линейный / площадной ) => SQR - площадной
       txfDataWorker8.setCOD_TYPE( "SQR" );
        /// метрика знака
        /// координаты объекта ( 1я точка )
        txfDataWorker8.setMETValue( "56.314014573", "42.911885365" );
        /// координаты объекта ( 2я точка )
        txfDataWorker8.setMETValue( "56.962916333", "44.038253903" );

        txfDataWorker8.setSEMValue( "5400", "11 дшд" );
        txfDataWorker8.setSEMValue( "9216", "КП" );
        /// добавляем модель картографических данных в коллекцию
        vfvpmodel.txfDataLst.append( txfDataWorker8 );

TXFDataWorker txfDataWorker5;
            /// ключ знака ( уникальный идентификатор )
            txfDataWorker5.setKEY( "V22208012" );
            /// код знака ( код серии знаков )
            txfDataWorker5.setCOD( "22208012" );
            /// тип знака ( векторный / линейный / площадной ) => VEC - векторный
            txfDataWorker5.setCOD_TYPE( "VEC" );
            /// метрика знака
            /// координаты объекта ( 1я точка - расположение знака )
            txfDataWorker5.setMETValue( "6.314014573", "42.911885365" );
            /// координаты объекта ( 2я точка - направление знака )
            txfDataWorker5.setMETValue( "56.62916333", "44.038253903" );
            /// семантика знака
            /// надпись внутри знака
            txfDataWorker5.setSEMValue( "500", "10 дшд" );
            /// надпись возле знака
            txfDataWorker5.setSEMValue( "216", "КП" );
            /// добавляем модель картографических данных в коллекцию
            vfvpmodel.txfDataLst.append( txfDataWorker5 );

//TXFDataWorker txfDataWorker6;
//            /// ключ знака ( уникальный идентификатор )
//            txfDataWorker6.setKEY( "V77708012" );
//            /// код знака ( код серии знаков )
//            txfDataWorker6.setCOD( "77708012" );
//            /// тип знака ( векторный / линейный / площадной ) => VEC - векторный
//            txfDataWorker6.setCOD_TYPE( "VEC" );
//            /// метрика знака
//            /// координаты объекта ( 1я точка - расположение знака )
//            txfDataWorker6.setMETValue( "56.314014573", "42.911885365" );
//            /// координаты объекта ( 2я точка - направление знака )
//            txfDataWorker6.setMETValue( "56.962916333", "44.038253903" );
//            /// семантика знака
//            /// надпись внутри знака
//            txfDataWorker6.setSEMValue( "5400", "10 дшд" );
//            /// надпись возле знака
//            txfDataWorker6.setSEMValue( "9216", "КП" );
//            /// добавляем модель картографических данных в коллекцию
//            vfvpmodel.txfDataLst.append( txfDataWorker6 );
TXFDataWorker txfDataWorker7;

            txfDataWorker7.setKEY( "L77708015" );

            txfDataWorker7.setCOD( "55508015" );

           txfDataWorker7.setCOD_TYPE( "LIN" );

            txfDataWorker7.setMETValue( "56.314014575", "42.911885369" );

            txfDataWorker7.setMETValue( "5.962916334", "44.038253905" );

            txfDataWorker7.setMETValue( "5.962916354", "44.038253914" );

            txfDataWorker7.setSEMValue( "400", "15 шд" );
           // txfDataWorker.getSEMValue( "5401" ).isEmpty();

           txfDataWorker7.setSEMValue( "92", "" );

            vfvpmodel.txfDataLst.append( txfDataWorker7 );
//            qDebug() << __PRETTY_FUNCTION__ << "txf count" << vfvpmodel.txfDataLst.count();
}
void MainWindow::setModel1( VFVPModel &vfvpmodel )
            {
            /// Учетный номер ВФВП
               vfvpmodel.charVfvp.vfvp_kod = "18200000000000044";

               vfvpmodel.charVfvp.vfvp_org = "18200000000000040";

               vfvpmodel.charVfvp.vfvp_dt  = QDateTime::currentDateTime();
               vfvpmodel.charVfvp.vfvp_name  = "10 ШД";
           //    vfvpmodel->charVfvp.vfvp_sname  =
               LSVFVP lsVfvp;

                   lsVfvp.lsdescription = QString( "личный состав" );

                   lsVfvp.lskolshtat    = QString( "700" );
                   ///
                   lsVfvp.lskolnal      = QString( "50" );

                   lsVfvp.lsukompl      = QString( "5" );

                   vfvpmodel.lsVfvpLst.append( lsVfvp );
            VVTVFVP vvtVfvp; /// инициализируем модель данных ВВТ
            /// наименование блока
            vvtVfvp.description = QString( "ВВТ" );
            vvtVfvp.kkoovt_kod  = QString( "5025205" );
            vvtVfvp.kolshtat    = QString( "300" );
            vvtVfvp.kolnal      = QString( "30" );
            vvtVfvp.ukompl      = QString( "3" );
            vfvpmodel.vvtVfsvLst.append( vvtVfvp );

            vvtVfvp.description = QString( "ВВТ1" );
            vvtVfvp.kkoovt_kod  = QString( "5025204" );
            vvtVfvp.kolshtat    = QString( "700" );
            vvtVfvp.kolnal      = QString( "50" );
            vvtVfvp.ukompl      = QString( "5" );
            vfvpmodel.vvtVfsvLst.append( vvtVfvp );



        //    POSVFVP posVfvp; /// инициализируем модель данных положения

        //    posVfvp.description = QString( "" );

        //    posVfvp.latitude    = QString( "" );

        //    posVfvp.longitude   = QString( "" );

        //    posVfvp.height      = QString( "" );
        //    posVfvp.OK          = QString( "" );

        //    vfvpmodel.posVfvpLst.append( posVfvp );

                POSVFVP posVfvp; /// инициализируем модель данных положения

                posVfvp.description = QString( "pvfvp" );

                posVfvp.latitude    = QString( "314014873" );

                posVfvp.longitude   = QString( "911885465" );

                posVfvp.height      = QString( "204" );

                posVfvp.OK          = QString( "Позиция на высоте 804" );

                vfvpmodel.posVfvpLst.append( posVfvp );


                posVfvp.description = QString( "ndvfvp" );

                posVfvp.latitude    = QString( "962916333" );

                posVfvp.longitude   = QString( "38253903" );

                posVfvp.height      = QString( "404" );

                posVfvp.OK          = QString( "Направление на высоте 404" );

                vfvpmodel.posVfvpLst.append( posVfvp );

                posVfvp.description = QString( "pvfvp" );

                posVfvp.latitude    = QString( "554014573" );

                posVfvp.longitude   = QString( "991885265" );

                posVfvp.height      = QString( "507" );

                posVfvp.OK          = QString( "Позиция на высоте 807" );

                vfvpmodel.posVfvpLst.append( posVfvp );


                posVfvp.description = QString( "ndvfvp" );

                posVfvp.latitude    = QString( "342916333" );

                posVfvp.longitude   = QString( "558253903" );

                posVfvp.height      = QString( "807" );

                posVfvp.OK          = QString( "Направление на высоте 407" );

                vfvpmodel.posVfvpLst.append( posVfvp );

        //            VVTVFVP vvtVfvp; /// инициализируем модель данных ВВТ
        //            /// наименование блока ВВТ
        //            vvtVfvp.description = QString( "ВВТ" );
        //            /// код по классификатору "Конкретные образцы оружия и военной техники"
        //            vvtVfvp.kkoovt_kod  = QString( "5025200" ); /// М706(V-100) "КОММАНДО"
        //            /// колличество по штату ВВТ
        //            vvtVfvp.kolshtat    = QString( "300" );
        //            /// колличество в наличии ВВТ
        //            vvtVfvp.kolnal      = QString( "30" );
        //            /// укомплектованность ВВТ ( ну Вы поняли => 10 )
        //            vvtVfvp.ukompl      = QString( "3" );
        //            /// добавляем модель данных ВВТ в коллекцию
        //            vfvpmodel.vvtVfsvLst.append( vvtVfvp );

                    /** пример файла данных ГИС векторный
                     *****************************
                     * .KEY V77708012            *
                     * .COD 77708012 VEC         *
                     * .MET 1                    *
                     * 2                         *
                     * 56.314014573 42.911885365 *
                     * 56.962916333 44.038253903 *
                     * .SEM 2                    *
                     * 5400 10 дшд               *
                     * 9216 КП                   *
                     *****************************
//                    **/
//                TXFDataWorker txfDataWorker1;

//                /// ключ знака ( уникальный идентификатор )
//                txfDataWorker1.setKEY( "V33308012" );
//                /// код знака ( код серии знаков )
//                txfDataWorker1.setCOD( "33308012" );
//                /// тип знака ( векторный / линейный / площадной ) => VEC - векторный
//                txfDataWorker1.setCOD_TYPE( "VEC" );
//                /// метрика знака
//                /// координаты объекта ( 1я точка - расположение знака )
//                txfDataWorker1.setMETValue( "58.314014573", "77.911885365" );
//                /// координаты объекта ( 2я точка - направление знака )
//                txfDataWorker1.setMETValue( "55.962916333", "88.038253903" );
//                /// семантика знака
//                /// надпись внутри знака
//                txfDataWorker1.setSEMValue( "2800", "10 дшд" );
//                /// надпись возле знака
//                txfDataWorker1.setSEMValue( "8216", "КП" );
//                /// добавляем модель картографических данных в коллекцию
//                vfvpmodel.txfDataLst.append( txfDataWorker1 );
//                    /// инициализируем модель картографических данных
//                    TXFDataWorker txfDataWorker;
//                    /// ключ знака ( уникальный идентификатор )
//                    txfDataWorker.setKEY( "V55508012" );
//                    /// код знака ( код серии знаков )
//                    txfDataWorker.setCOD( "55508012" );
//                    /// тип знака ( векторный / линейный / площадной ) => VEC - векторный
//                    txfDataWorker.setCOD_TYPE( "VEC" );
//                    /// метрика знака
//                    /// координаты объекта ( 1я точка - расположение знака )
//                    txfDataWorker.setMETValue( "55.314014573", "42.911885365" );
//                    /// координаты объекта ( 2я точка - направление знака )
//                    txfDataWorker.setMETValue( "55.962916333", "44.038253903" );
//                    /// семантика знака
//                    /// надпись внутри знака
//                    txfDataWorker.setSEMValue( "5400", "10 дшд" );
//                    /// надпись возле знака
//                    txfDataWorker.setSEMValue( "9216", "КП" );
//                    /// добавляем модель картографических данных в коллекцию
//                    vfvpmodel.txfDataLst.append( txfDataWorker );
//                    TXFDataWorker txfDataWorker3;
//                    /// ключ знака ( уникальный идентификатор )
//                    txfDataWorker3.setKEY( "V00008012" );
//                    /// код знака ( код серии знаков )
//                    txfDataWorker3.setCOD( "00008012" );
//                    /// тип знака ( векторный / линейный / площадной ) => VEC - векторный
//                    txfDataWorker3.setCOD_TYPE( "VEC" );
//                    /// метрика знака
//                    /// координаты объекта ( 1я точка - расположение знака )
//                    txfDataWorker3.setMETValue( "00.314014573", "42.911885365" );
//                    /// координаты объекта ( 2я точка - направление знака )
//                    txfDataWorker3.setMETValue( "00.962916333", "44.038253903" );
//                    /// семантика знака
//                    /// надпись внутри знака
//                    txfDataWorker3.setSEMValue( "5400", "10 дшд" );
//                    /// надпись возле знака
//                    txfDataWorker3.setSEMValue( "1216", "КП" );
//                    /// добавляем модель картографических данных в коллекцию
//                    vfvpmodel.txfDataLst.append( txfDataWorker3 );


}
            void MainWindow::setModel2( VFVPModel &vfvpmodel )
            {
                /// Учетный номер ВФВП
                   vfvpmodel.charVfvp.vfvp_kod = "18200000000000055";

                   vfvpmodel.charVfvp.vfvp_org = "2";

                   vfvpmodel.charVfvp.vfvp_dt  = QDateTime::currentDateTime();
                   vfvpmodel.charVfvp.vfvp_name  = "15 ШД";
               //    vfvpmodel->charVfvp.vfvp_sname  =
                   LSVFVP lsVfvp;

                       lsVfvp.lsdescription = QString( "личный состав" );

                       lsVfvp.lskolshtat    = QString( "2200" );
                       ///
                       lsVfvp.lskolnal      = QString( "555" );

                       lsVfvp.lsukompl      = QString( "5" );

                       vfvpmodel.lsVfvpLst.append( lsVfvp );
                VVTVFVP vvtVfvp; /// инициализируем модель данных ВВТ
                /// наименование блока
                vvtVfvp.description = QString( "ВВТ" );
                vvtVfvp.kkoovt_kod  = QString( "5025200" );
                vvtVfvp.kolshtat    = QString( "900" );
                vvtVfvp.kolnal      = QString( "80" );
                vvtVfvp.ukompl      = QString( "4" );

                vfvpmodel.vvtVfsvLst.append( vvtVfvp );

                vvtVfvp.description = QString( "ВВТ1" );
                vvtVfvp.kkoovt_kod  = QString( "5025201" );
                vvtVfvp.kolshtat    = QString( "700" );
                vvtVfvp.kolnal      = QString( "50" );
                vvtVfvp.ukompl      = QString( "8" );
                vfvpmodel.vvtVfsvLst.append( vvtVfvp );

            //    vvtVfvp.description = QString( "ВВТ2" );
            //    vvtVfvp.kkoovt_kod  = QString( "5025203" );
            //    vvtVfvp.kolshtat    = QString( "600" );
            //    vvtVfvp.kolnal      = QString( "60" );
            //    vvtVfvp.ukompl      = QString( "6" );
            //    vfvpmodel.vvtVfsvLst.append( vvtVfvp );

            //    POSVFVP posVfvp; /// инициализируем модель данных положения

            //    posVfvp.description = QString( "" );

            //    posVfvp.latitude    = QString( "" );

            //    posVfvp.longitude   = QString( "" );

            //    posVfvp.height      = QString( "" );
            //    posVfvp.OK          = QString( "" );

            //    vfvpmodel.posVfvpLst.append( posVfvp );

                    POSVFVP posVfvp; /// инициализируем модель данных положения

                    posVfvp.description = QString( "pvfvp" );

                    posVfvp.latitude    = QString( "314014573" );

                    posVfvp.longitude   = QString( "911885365" );

                    posVfvp.height      = QString( "404" );

                    posVfvp.OK          = QString( "Позиция на высоте 404" );

                    vfvpmodel.posVfvpLst.append( posVfvp );


//                    posVfvp.description = QString( "ndvfvp" );

//                    posVfvp.latitude    = QString( "9629163444433" );

//                    posVfvp.longitude   = QString( "382539000003" );

//                    posVfvp.height      = QString( "4054" );

//                    posVfvp.OK          = QString( "Направление на высоте 404" );

//                    vfvpmodel.posVfvpLst.append( posVfvp );

                    posVfvp.description = QString( "pvfvp" );

                    posVfvp.latitude    = QString( "554014573" );

                    posVfvp.longitude   = QString( "991885365" );

                    posVfvp.height      = QString( "407" );

                    posVfvp.OK          = QString( "Позиция на высоте 407" );

                    vfvpmodel.posVfvpLst.append( posVfvp );


//                    posVfvp.description = QString( "ndvfvp" );

//                    posVfvp.latitude    = QString( "342916333" );

//                    posVfvp.longitude   = QString( "558253903" );

//                    posVfvp.height      = QString( "4027" );

//                    posVfvp.OK          = QString( "Направление на высоте 4017" );

//                    vfvpmodel.posVfvpLst.append( posVfvp );

            //            VVTVFVP vvtVfvp; /// инициализируем модель данных ВВТ
            //            /// наименование блока ВВТ
            //            vvtVfvp.description = QString( "ВВТ" );
            //            /// код по классификатору "Конкретные образцы оружия и военной техники"
            //            vvtVfvp.kkoovt_kod  = QString( "5025200" ); /// М706(V-100) "КОММАНДО"
            //            /// колличество по штату ВВТ
            //            vvtVfvp.kolshtat    = QString( "300" );
            //            /// колличество в наличии ВВТ
            //            vvtVfvp.kolnal      = QString( "30" );
            //            /// укомплектованность ВВТ ( ну Вы поняли => 10 )
            //            vvtVfvp.ukompl      = QString( "3" );
            //            /// добавляем модель данных ВВТ в коллекцию
            //            vfvpmodel.vvtVfsvLst.append( vvtVfvp );

                        /** пример файла данных ГИС векторный
                         *****************************
                         * .KEY V77708012            *
                         * .COD 77708012 VEC         *
                         * .MET 1                    *
                         * 2                         *
                         * 56.314014573 42.911885365 *
                         * 56.962916333 44.038253903 *
                         * .SEM 2                    *
                         * 5400 10 дшд               *
                         * 9216 КП                   *
                         *****************************
                        **/
             TXFDataWorker txfDataWorker8;
                        /// инициализируем модель картографических данных
                    txfDataWorker8.setKEY( "S11708015" );
                    /// код знака ( код серии знаков )
                    txfDataWorker8.setCOD( "77708015" );
                    /// тип знака ( векторный / линейный / площадной ) => SQR - площадной
                   txfDataWorker8.setCOD_TYPE( "SQR" );
                    /// метрика знака
                    /// координаты объекта ( 1я точка )
                    txfDataWorker8.setMETValue( "56.314014573", "42.911885365" );
                    /// координаты объекта ( 2я точка )
                    txfDataWorker8.setMETValue( "56.962916333", "44.038253903" );

                    txfDataWorker8.setSEMValue( "5400", "11 дшд" );
                    txfDataWorker8.setSEMValue( "9216", "КП" );
                    /// добавляем модель картографических данных в коллекцию
                    vfvpmodel.txfDataLst.append( txfDataWorker8 );

            TXFDataWorker txfDataWorker5;
                        /// ключ знака ( уникальный идентификатор )
                        txfDataWorker5.setKEY( "V22208012" );
                        /// код знака ( код серии знаков )
                        txfDataWorker5.setCOD( "22208012" );
                        /// тип знака ( векторный / линейный / площадной ) => VEC - векторный
                        txfDataWorker5.setCOD_TYPE( "VEC" );
                        /// метрика знака
                        /// координаты объекта ( 1я точка - расположение знака )
                        txfDataWorker5.setMETValue( "6.314014573", "42.911885365" );
                        /// координаты объекта ( 2я точка - направление знака )
                        txfDataWorker5.setMETValue( "56.62916333", "44.038253903" );
                        /// семантика знака
                        /// надпись внутри знака
                        txfDataWorker5.setSEMValue( "500", "10 дшд" );
                        /// надпись возле знака
                        txfDataWorker5.setSEMValue( "216", "КП" );
                        /// добавляем модель картографических данных в коллекцию
                        vfvpmodel.txfDataLst.append( txfDataWorker5 );

            TXFDataWorker txfDataWorker6;
                        /// ключ знака ( уникальный идентификатор )
                        txfDataWorker6.setKEY( "V77708012" );
                        /// код знака ( код серии знаков )
                        txfDataWorker6.setCOD( "77708012" );
                        /// тип знака ( векторный / линейный / площадной ) => VEC - векторный
                        txfDataWorker6.setCOD_TYPE( "VEC" );
                        /// метрика знака
                        /// координаты объекта ( 1я точка - расположение знака )
                        txfDataWorker6.setMETValue( "56.314014573", "42.911885365" );
                        /// координаты объекта ( 2я точка - направление знака )
                        txfDataWorker6.setMETValue( "56.962916333", "44.038253903" );
                        /// семантика знака
                        /// надпись внутри знака
                        txfDataWorker6.setSEMValue( "5400", "10 дшд" );
                        /// надпись возле знака
                        txfDataWorker6.setSEMValue( "9216", "КП" );
                        /// добавляем модель картографических данных в коллекцию
                        vfvpmodel.txfDataLst.append( txfDataWorker6 );
            TXFDataWorker txfDataWorker7;

                        txfDataWorker7.setKEY( "L77708015" );

                        txfDataWorker7.setCOD( "55508015" );

                       txfDataWorker7.setCOD_TYPE( "LIN" );

                        txfDataWorker7.setMETValue( "56.314014575", "42.911885369" );

                        txfDataWorker7.setMETValue( "5.962916334", "44.038253905" );

                        txfDataWorker7.setMETValue( "5.962916354", "44.038253914" );

                        txfDataWorker7.setSEMValue( "400", "15 шд" );
                       // txfDataWorker.getSEMValue( "5401" ).isEmpty();

                       txfDataWorker7.setSEMValue( "92", "" );

                        vfvpmodel.txfDataLst.append( txfDataWorker7 );
            //            qDebug() << __PRETTY_FUNCTION__ << "txf count" << vfvpmodel.txfDataLst.count();
            }


void MainWindow::setModel3( VFVPModel &vfvpmodel )
                        {
    /// Учетный номер ВФВП
    vfvpmodel.charVfvp.vfvp_kod = "18200000000000040";

    vfvpmodel.charVfvp.vfvp_org = "18200000000000055";

    vfvpmodel.charVfvp.vfvp_dt  = QDateTime::currentDateTime();
    vfvpmodel.charVfvp.vfvp_name  = "1755 ШД";
    //    vfvpmodel->charVfvp.vfvp_sname  =

    //                            VVTVFVP vvtVfvp; /// инициализируем модель данных ВВТ
    //                            /// наименование блока
    //                            vvtVfvp.description = QString( "ВВТ" );
    //                            vvtVfvp.kkoovt_kod  = QString( "5025200" );
    //                            vvtVfvp.kolshtat    = QString( "300" );
    //                            vvtVfvp.kolnal      = QString( "30" );
    //                            vvtVfvp.ukompl      = QString( "3" );

//                            vfvpmodel.vvtVfsvLst.append( vvtVfvp );

                        //    vvtVfvp.description = QString( "ВВТ1" );
                        //    vvtVfvp.kkoovt_kod  = QString( "5025201" );
                        //    vvtVfvp.kolshtat    = QString( "500" );
                        //    vvtVfvp.kolnal      = QString( "50" );
                        //    vvtVfvp.ukompl      = QString( "5" );
                        //    vfvpmodel.vvtVfsvLst.append( vvtVfvp );

                        //    vvtVfvp.description = QString( "ВВТ2" );
                        //    vvtVfvp.kkoovt_kod  = QString( "5025203" );
                        //    vvtVfvp.kolshtat    = QString( "600" );
                        //    vvtVfvp.kolnal      = QString( "60" );
                        //    vvtVfvp.ukompl      = QString( "6" );
                        //    vfvpmodel.vvtVfsvLst.append( vvtVfvp );

                        //    POSVFVP posVfvp; /// инициализируем модель данных положения

                        //    posVfvp.description = QString( "" );

                        //    posVfvp.latitude    = QString( "" );

                        //    posVfvp.longitude   = QString( "" );

                        //    posVfvp.height      = QString( "" );
                        //    posVfvp.OK          = QString( "" );

                        //    vfvpmodel.posVfvpLst.append( posVfvp );

                                POSVFVP posVfvp; /// инициализируем модель данных положения

                                posVfvp.description = QString( "pvfvp" );

                                posVfvp.latitude    = QString( "314014573" );

                                posVfvp.longitude   = QString( "911885365" );

                                posVfvp.height      = QString( "404" );

                                posVfvp.OK          = QString( "Позиция на высоте 404" );

                                vfvpmodel.posVfvpLst.append( posVfvp );


                                posVfvp.description = QString( "ndvfvp" );

                                posVfvp.latitude    = QString( "9629163444433" );

                                posVfvp.longitude   = QString( "382539000003" );

                                posVfvp.height      = QString( "4054" );

                                posVfvp.OK          = QString( "Направление на высоте 404" );

                                vfvpmodel.posVfvpLst.append( posVfvp );

                                posVfvp.description = QString( "pvfvp" );

                                posVfvp.latitude    = QString( "554014573" );

                                posVfvp.longitude   = QString( "991885365" );

                                posVfvp.height      = QString( "407" );

                                posVfvp.OK          = QString( "Позиция на высоте 407" );

                                vfvpmodel.posVfvpLst.append( posVfvp );


                                posVfvp.description = QString( "ndvfvp" );

                                posVfvp.latitude    = QString( "342916333" );

                                posVfvp.longitude   = QString( "558253903" );

                                posVfvp.height      = QString( "4027" );

                                posVfvp.OK          = QString( "Направление на высоте 4017" );

                                vfvpmodel.posVfvpLst.append( posVfvp );


//                         TXFDataWorker txfDataWorker8;
//                                    /// инициализируем модель картографических данных
//                                txfDataWorker8.setKEY( "S11708015" );
//                                /// код знака ( код серии знаков )
//                                txfDataWorker8.setCOD( "77708015" );
//                                /// тип знака ( векторный / линейный / площадной ) => SQR - площадной
//                               txfDataWorker8.setCOD_TYPE( "SQR" );
//                                /// метрика знака
//                                /// координаты объекта ( 1я точка )
//                                txfDataWorker8.setMETValue( "56.314014573", "42.911885365" );
//                                /// координаты объекта ( 2я точка )
//                                txfDataWorker8.setMETValue( "56.962916333", "44.038253903" );

//                                txfDataWorker8.setSEMValue( "5400", "11 дшд" );
//                                txfDataWorker8.setSEMValue( "9216", "КП" );
//                                /// добавляем модель картографических данных в коллекцию
//                                vfvpmodel.txfDataLst.append( txfDataWorker8 );

//                        TXFDataWorker txfDataWorker5;
//                                    /// ключ знака ( уникальный идентификатор )
//                                    txfDataWorker5.setKEY( "V22208012" );
//                                    /// код знака ( код серии знаков )
//                                    txfDataWorker5.setCOD( "22208012" );
//                                    /// тип знака ( векторный / линейный / площадной ) => VEC - векторный
//                                    txfDataWorker5.setCOD_TYPE( "VEC" );
//                                    /// метрика знака
//                                    /// координаты объекта ( 1я точка - расположение знака )
//                                    txfDataWorker5.setMETValue( "6.314014573", "42.911885365" );
//                                    /// координаты объекта ( 2я точка - направление знака )
//                                    txfDataWorker5.setMETValue( "56.62916333", "44.038253903" );
//                                    /// семантика знака
//                                    /// надпись внутри знака
//                                    txfDataWorker5.setSEMValue( "500", "10 дшд" );
//                                    /// надпись возле знака
//                                    txfDataWorker5.setSEMValue( "216", "КП" );
//                                    /// добавляем модель картографических данных в коллекцию
//                                    vfvpmodel.txfDataLst.append( txfDataWorker5 );

//                        TXFDataWorker txfDataWorker6;
//                                    /// ключ знака ( уникальный идентификатор )
//                                    txfDataWorker6.setKEY( "V77708012" );
//                                    /// код знака ( код серии знаков )
//                                    txfDataWorker6.setCOD( "77708012" );
//                                    /// тип знака ( векторный / линейный / площадной ) => VEC - векторный
//                                    txfDataWorker6.setCOD_TYPE( "VEC" );
//                                    /// метрика знака
//                                    /// координаты объекта ( 1я точка - расположение знака )
//                                    txfDataWorker6.setMETValue( "56.314014573", "42.911885365" );
//                                    /// координаты объекта ( 2я точка - направление знака )
//                                    txfDataWorker6.setMETValue( "56.962916333", "44.038253903" );
//                                    /// семантика знака
//                                    /// надпись внутри знака
//                                    txfDataWorker6.setSEMValue( "5400", "10 дшд" );
//                                    /// надпись возле знака
//                                    txfDataWorker6.setSEMValue( "9216", "КП" );
//                                    /// добавляем модель картографических данных в коллекцию
//                                    vfvpmodel.txfDataLst.append( txfDataWorker6 );
//                        TXFDataWorker txfDataWorker7;

//                                    txfDataWorker7.setKEY( "L77708015" );

//                                    txfDataWorker7.setCOD( "55508015" );

//                                   txfDataWorker7.setCOD_TYPE( "LIN" );

//                                    txfDataWorker7.setMETValue( "56.314014575", "42.911885369" );

//                                    txfDataWorker7.setMETValue( "5.962916334", "44.038253905" );

//                                    txfDataWorker7.setMETValue( "5.962916354", "44.038253914" );

//                                    txfDataWorker7.setSEMValue( "400", "15 шд" );
//                                   // txfDataWorker.getSEMValue( "5401" ).isEmpty();

//                                   txfDataWorker7.setSEMValue( "92", "" );

//                                    vfvpmodel.txfDataLst.append( txfDataWorker7 );
                        //            qDebug() << __PRETTY_FUNCTION__ << "txf count" << vfvpmodel.txfDataLst.count();
                        }

 void MainWindow::setModel4( VFVPModel &vfvpmodel )
                                    {
                                        /// Учетный номер ВФВП
                                           vfvpmodel.charVfvp.vfvp_kod = "18200000000000555";

                                           vfvpmodel.charVfvp.vfvp_org = "3";

                                           vfvpmodel.charVfvp.vfvp_dt  = QDateTime::currentDateTime();
                                           vfvpmodel.charVfvp.vfvp_name  = "1 ШД";
                                       //    vfvpmodel->charVfvp.vfvp_sname  =

                                        VVTVFVP vvtVfvp; /// инициализируем модель данных ВВТ
                                        /// наименование блока
                                        vvtVfvp.description = QString( "ВВТ" );
                                        vvtVfvp.kkoovt_kod  = QString( "5025200" );
                                        vvtVfvp.kolshtat    = QString( "300" );
                                        vvtVfvp.kolnal      = QString( "30" );
                                        vvtVfvp.ukompl      = QString( "3" );

                                        vfvpmodel.vvtVfsvLst.append( vvtVfvp );

                                    //    vvtVfvp.description = QString( "ВВТ1" );
                                    //    vvtVfvp.kkoovt_kod  = QString( "5025201" );
                                    //    vvtVfvp.kolshtat    = QString( "500" );
                                    //    vvtVfvp.kolnal      = QString( "50" );
                                    //    vvtVfvp.ukompl      = QString( "5" );
                                    //    vfvpmodel.vvtVfsvLst.append( vvtVfvp );

                                        vvtVfvp.description = QString( "ВВТ2" );
                                        vvtVfvp.kkoovt_kod  = QString( "5025203" );
                                        vvtVfvp.kolshtat    = QString( "600" );
                                        vvtVfvp.kolnal      = QString( "60" );
                                        vvtVfvp.ukompl      = QString( "6" );
                                        vfvpmodel.vvtVfsvLst.append( vvtVfvp );

                                    //    POSVFVP posVfvp; /// инициализируем модель данных положения

                                    //    posVfvp.description = QString( "" );

                                    //    posVfvp.latitude    = QString( "" );

                                    //    posVfvp.longitude   = QString( "" );

                                    //    posVfvp.height      = QString( "" );
                                    //    posVfvp.OK          = QString( "" );

                                    //    vfvpmodel.posVfvpLst.append( posVfvp );

                                            POSVFVP posVfvp; /// инициализируем модель данных положения

                                            posVfvp.description = QString( "pvfvp" );

                                            posVfvp.latitude    = QString( "314014573" );

                                            posVfvp.longitude   = QString( "911885365" );

                                            posVfvp.height      = QString( "404" );

                                            posVfvp.OK          = QString( "Позиция на высоте 404" );

                                            vfvpmodel.posVfvpLst.append( posVfvp );


                                            posVfvp.description = QString( "ndvfvp" );

                                            posVfvp.latitude    = QString( "9629163444433" );

                                            posVfvp.longitude   = QString( "382539000003" );

                                            posVfvp.height      = QString( "4054" );

                                            posVfvp.OK          = QString( "Направление на высоте 404" );

                                            vfvpmodel.posVfvpLst.append( posVfvp );

                                            posVfvp.description = QString( "pvfvp" );

                                            posVfvp.latitude    = QString( "554014573" );

                                            posVfvp.longitude   = QString( "991885365" );

                                            posVfvp.height      = QString( "407" );

                                            posVfvp.OK          = QString( "Позиция на высоте 407" );

                                            vfvpmodel.posVfvpLst.append( posVfvp );


                                            posVfvp.description = QString( "ndvfvp" );

                                            posVfvp.latitude    = QString( "342916333" );

                                            posVfvp.longitude   = QString( "558253903" );

                                            posVfvp.height      = QString( "4027" );

                                            posVfvp.OK          = QString( "Направление на высоте 4017" );

                                            vfvpmodel.posVfvpLst.append( posVfvp );


                                     TXFDataWorker txfDataWorker8;
                                                /// инициализируем модель картографических данных
                                            txfDataWorker8.setKEY( "S11708015" );
                                            /// код знака ( код серии знаков )
                                            txfDataWorker8.setCOD( "77708015" );
                                            /// тип знака ( векторный / линейный / площадной ) => SQR - площадной
                                           txfDataWorker8.setCOD_TYPE( "SQR" );
                                            /// метрика знака
                                            /// координаты объекта ( 1я точка )
                                            txfDataWorker8.setMETValue( "56.314014573", "42.911885365" );
                                            /// координаты объекта ( 2я точка )
                                            txfDataWorker8.setMETValue( "56.962916333", "44.038253903" );

                                            txfDataWorker8.setSEMValue( "5400", "11 дшд" );
                                            txfDataWorker8.setSEMValue( "9216", "КП" );
                                            /// добавляем модель картографических данных в коллекцию
                                            vfvpmodel.txfDataLst.append( txfDataWorker8 );

                                    TXFDataWorker txfDataWorker5;
                                                /// ключ знака ( уникальный идентификатор )
                                                txfDataWorker5.setKEY( "V22208012" );
                                                /// код знака ( код серии знаков )
                                                txfDataWorker5.setCOD( "22208012" );
                                                /// тип знака ( векторный / линейный / площадной ) => VEC - векторный
                                                txfDataWorker5.setCOD_TYPE( "VEC" );
                                                /// метрика знака
                                                /// координаты объекта ( 1я точка - расположение знака )
                                                txfDataWorker5.setMETValue( "6.314014573", "42.911885365" );
                                                /// координаты объекта ( 2я точка - направление знака )
                                                txfDataWorker5.setMETValue( "56.62916333", "44.038253903" );
                                                /// семантика знака
                                                /// надпись внутри знака
                                                txfDataWorker5.setSEMValue( "500", "10 дшд" );
                                                /// надпись возле знака
                                                txfDataWorker5.setSEMValue( "216", "КП" );
                                                /// добавляем модель картографических данных в коллекцию
                                                vfvpmodel.txfDataLst.append( txfDataWorker5 );

                                    TXFDataWorker txfDataWorker6;
                                                /// ключ знака ( уникальный идентификатор )
                                                txfDataWorker6.setKEY( "V77708012" );
                                                /// код знака ( код серии знаков )
                                                txfDataWorker6.setCOD( "77708012" );
                                                /// тип знака ( векторный / линейный / площадной ) => VEC - векторный
                                                txfDataWorker6.setCOD_TYPE( "VEC" );
                                                /// метрика знака
                                                /// координаты объекта ( 1я точка - расположение знака )
                                                txfDataWorker6.setMETValue( "56.314014573", "42.911885365" );
                                                /// координаты объекта ( 2я точка - направление знака )
                                                txfDataWorker6.setMETValue( "56.962916333", "44.038253903" );
                                                /// семантика знака
                                                /// надпись внутри знака
                                                txfDataWorker6.setSEMValue( "5400", "10 дшд" );
                                                /// надпись возле знака
                                                txfDataWorker6.setSEMValue( "9216", "КП" );
                                                /// добавляем модель картографических данных в коллекцию
                                                vfvpmodel.txfDataLst.append( txfDataWorker6 );
                                    TXFDataWorker txfDataWorker7;

                                                txfDataWorker7.setKEY( "L77708015" );

                                                txfDataWorker7.setCOD( "55508015" );

                                               txfDataWorker7.setCOD_TYPE( "LIN" );

                                                txfDataWorker7.setMETValue( "56.314014575", "42.911885369" );

                                                txfDataWorker7.setMETValue( "5.962916334", "44.038253905" );

                                                txfDataWorker7.setMETValue( "5.962916354", "44.038253914" );

                                                txfDataWorker7.setSEMValue( "400", "15 шд" );
                                               // txfDataWorker.getSEMValue( "5401" ).isEmpty();

                                               txfDataWorker7.setSEMValue( "92", "" );

                                                vfvpmodel.txfDataLst.append( txfDataWorker7 );
                                    //            qDebug() << __PRETTY_FUNCTION__ << "txf count" << vfvpmodel.txfDataLst.count();
                                    }


//void MainWindow::onTreeViewItemClicked(const QModelIndex &modelIndex)
//{   qDebug() << "Модель данных";

//    QString vfvpKod = modelIndex.data(Qt::UserRole).toString();
//    VFVPModel* vModelPtr = vfvpMap.value(vfvpKod);
//    if (vModelPtr != nullptr) {
//        vfvpmodel = *vModelPtr;
//    } else {
//        // Обработка случая, когда ключ не найден в мапе
//        QMessageBox::warning(this, tr("Внимание!"), tr("Объект для данного ключа не найден! %1").arg(vfvpKod));
//    }
//    qDebug() << vfvpKod;

//    /// ВВТ [ vvtvfvp ]
//    qDebug() << "ВВТ [ vvtvfvp ]:";
//    qDebug() << "description => " << vfvpmodel.vvtVfsvLst.value( 0 ).description;
//    qDebug() << "kkoovt_kod  => " << vfvpmodel.vvtVfsvLst.value( 0 ).kkoovt_kod;
//    qDebug() << "kolshtat    => " << vfvpmodel.vvtVfsvLst.value( 0 ).kolshtat;
//    qDebug() << "kolnal      => " << vfvpmodel.vvtVfsvLst.value( 0 ).kolnal;
//    qDebug() << "ukompl      => " << vfvpmodel.vvtVfsvLst.value( 0 ).ukompl;

//         qDebug() << __PRETTY_FUNCTION__ << modelIndex.data(Qt::UserRole).toString();

//                 /// ВВТ [ vvtvfvp ] => modelView
//            textTab5Edit1->setText( vfvpmodel.vvtVfsvLst.value( 0 ).description );
//            textTab5Edit2->setText( vfvpmodel.vvtVfsvLst.value( 0 ).kkoovt_kod );
//            textTab5Edit3->setText( vfvpmodel.vvtVfsvLst.value( 0 ).kolshtat );
//            textTab5Edit4->setText( vfvpmodel.vvtVfsvLst.value( 0 ).kolnal );
//            textTab5Edit5->setText( vfvpmodel.vvtVfsvLst.value( 0 ).ukompl );

//                    }

//все внутри таба
//void MainWindow::onTreeViewItemClicked(const QModelIndex &modelIndex)
//{
//    QString vfvpKod = modelIndex.data(Qt::UserRole).toString();
//    VFVPModel* vModelPtr = vfvpMap.value(vfvpKod);
//    if (vModelPtr != nullptr) {
//        vfvpmodel = *vModelPtr;
//    } else {
//        QMessageBox::warning(this, tr("Внимание!"), tr("Объект для данного ключа не найден! %1").arg(vfvpKod));
//    }


//    // Проверяем, были ли уже созданы вкладки
//        if (!tabsCreated) {
//            QVBoxLayout* tab5Layout = new QVBoxLayout(tab5);  // Создаем QVBoxLayout для размещения вкладок в tab5

//    // Создаем вкладки и заполняем данными из модели
//    for (int i = 0; i < vfvpmodel.vvtVfsvLst.size(); i++) {
//        VVTVFVP vvtVfvp = vfvpmodel.vvtVfsvLst.at(i);

//        QWidget* innerTab = new QWidget(tab5);
//        QVBoxLayout* innerTabLayout = new QVBoxLayout(innerTab);

//        QLabel* labelc1 = new QLabel("Наименование блока", innerTab);
//        QLabel* labelc2 = new QLabel("Код по классификатору", innerTab);
//        QLabel* labelc3 = new QLabel("Количество по штату", innerTab);
//        QLabel* labelc4 = new QLabel("Количество в наличии", innerTab);
//        QLabel* labelc5 = new QLabel("Комплектность", innerTab);

//        QLineEdit* textEdit1 = new QLineEdit(innerTab);
//        QLineEdit* textEdit2 = new QLineEdit(innerTab);
//        QLineEdit* textEdit3 = new QLineEdit(innerTab);
//        QLineEdit* textEdit4 = new QLineEdit(innerTab);
//        QLineEdit* textEdit5 = new QLineEdit(innerTab);

//        textEdit1->setObjectName(QString("TextEdit1Tab5_%1").arg(i));
//        textEdit2->setObjectName(QString("TextEdit2Tab5_%1").arg(i));
//        textEdit3->setObjectName(QString("TextEdit3Tab5_%1").arg(i));
//        textEdit4->setObjectName(QString("TextEdit4Tab5_%1").arg(i));
//        textEdit5->setObjectName(QString("TextEdit5Tab5_%1").arg(i));

//        textEdit1->setReadOnly(true);
//        textEdit2->setReadOnly(true);
//        textEdit3->setReadOnly(true);
//        textEdit4->setReadOnly(true);
//        textEdit5->setReadOnly(true);

//        textEdit1->setText(vvtVfvp.description);
//        textEdit2->setText(vvtVfvp.kkoovt_kod);
//        textEdit3->setText(vvtVfvp.kolshtat);
//        textEdit4->setText(vvtVfvp.kolnal);
//        textEdit5->setText(vvtVfvp.ukompl);

//        innerTabLayout->addWidget(labelc1);
//        innerTabLayout->addWidget(textEdit1);
//        innerTabLayout->addWidget(labelc2);
//        innerTabLayout->addWidget(textEdit2);
//        innerTabLayout->addWidget(labelc3);
//        innerTabLayout->addWidget(textEdit3);
//        innerTabLayout->addWidget(labelc4);
//        innerTabLayout->addWidget(textEdit4);
//        innerTabLayout->addWidget(labelc5);
//        innerTabLayout->addWidget(textEdit5);

//        innerTabLayout->addStretch(1);

//        innerTab->setLayout(innerTabLayout);

//        // Добавляем новую вкладку в QVBoxLayout внутри tab5
//        tab5Layout->addWidget(innerTab);

//        // Присваиваем имя вкладке на основе значения kkoovt_kod
//        tabWidget->setTabText(tabWidget->indexOf(innerTab), vvtVfvp.kkoovt_kod);
//    }

//    // Устанавливаем QVBoxLayout внутри tab5
//    tab5->setLayout(tab5Layout);

//    // Устанавливаем флаг, что вкладки были созданы
//    tabsCreated = true;
//        }
//}

// со скролом
//void MainWindow::onTreeViewItemClicked(const QModelIndex& modelIndex)
//{
//    QString vfvpKod = modelIndex.data(Qt::UserRole).toString();
//    VFVPModel* vModelPtr = vfvpMap.value(vfvpKod);
//    if (vModelPtr != nullptr) {
//        vfvpmodel = *vModelPtr;
//    } else {
//        QMessageBox::warning(this, tr("Внимание!"), tr("Объект для данного ключа не найден! %1").arg(vfvpKod));
//    }

//    // Проверяем, были ли уже созданы вкладки
//    if (!tabsCreated) {
//        QVBoxLayout* tab5Layout = new QVBoxLayout(tab5); // Создаем QVBoxLayout для размещения вкладок в tab5
//        QScrollArea* scrollArea = new QScrollArea(tab5); // Создаем виджет прокрутки
//        scrollArea->setWidgetResizable(true);
//        QWidget* scrollContentWidget = new QWidget(); // Создаем виджет для содержимого, который будет размещаться в виджете прокрутки
//        QVBoxLayout* scrollLayout = new QVBoxLayout(scrollContentWidget); // Создаем QVBoxLayout для размещения вкладок внутри виджета прокрутки
//        scrollContentWidget->setLayout(scrollLayout);

//        // Создаем вкладки и заполняем данными из модели
//        for (int i = 0; i < vfvpmodel.vvtVfsvLst.size(); i++) {
//            VVTVFVP vvtVfvp = vfvpmodel.vvtVfsvLst.at(i);

//            QWidget* innerTab = new QWidget(scrollContentWidget);
//            QVBoxLayout* innerTabLayout = new QVBoxLayout(innerTab);
//            QLabel* labelc1 = new QLabel("Наименование блока", scrollContentWidget);

//                   QLabel* labelc2 = new QLabel("Код по классификатору", scrollContentWidget);
//                   QLabel* labelc3 = new QLabel("Количество по штату", scrollContentWidget);
//                   QLabel* labelc4 = new QLabel("Количество в наличии", scrollContentWidget);
//                   QLabel* labelc5 = new QLabel("Комплектность", scrollContentWidget);

//                   QLineEdit* textEdit1 = new QLineEdit(scrollContentWidget);
//               //    textEdit1->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Preferred);

//                   QLineEdit* textEdit2 = new QLineEdit(scrollContentWidget);
//                 //  textEdit1->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Preferred);

//                   QLineEdit* textEdit3 = new QLineEdit(scrollContentWidget);
//               //    textEdit1->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Preferred);

//                   QLineEdit* textEdit4 = new QLineEdit(scrollContentWidget);
//                //   textEdit1->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Preferred);

//                   QLineEdit* textEdit5 = new QLineEdit(scrollContentWidget);
//                 //  textEdit1->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Preferred);


//                   textEdit1->setObjectName(QString("TextEdit1Tab5_%1").arg(i));
//                   textEdit2->setObjectName(QString("TextEdit2Tab5_%1").arg(i));
//                   textEdit3->setObjectName(QString("TextEdit3Tab5_%1").arg(i));
//                   textEdit4->setObjectName(QString("TextEdit4Tab5_%1").arg(i));
//                   textEdit5->setObjectName(QString("TextEdit5Tab5_%1").arg(i));

//                   textEdit1->setReadOnly(true);
//                   textEdit2->setReadOnly(true);
//                   textEdit3->setReadOnly(true);
//                   textEdit4->setReadOnly(true);
//                   textEdit5->setReadOnly(true);

//                   textEdit1->setText(vvtVfvp.description);
//                   textEdit2->setText(vvtVfvp.kkoovt_kod);
//                   textEdit3->setText(vvtVfvp.kolshtat);
//                   textEdit4->setText(vvtVfvp.kolnal);
//                   textEdit5->setText(vvtVfvp.ukompl);


//            // Создание QLabel и QLineEdit, а также установка их свойств и текста

//            innerTabLayout->addWidget(labelc1);
//            innerTabLayout->addWidget(textEdit1);
//            innerTabLayout->addWidget(labelc2);
//            innerTabLayout->addWidget(textEdit2);
//            innerTabLayout->addWidget(labelc3);
//            innerTabLayout->addWidget(textEdit3);
//            innerTabLayout->addWidget(labelc4);
//            innerTabLayout->addWidget(textEdit4);
//            innerTabLayout->addWidget(labelc5);
//            innerTabLayout->addWidget(textEdit5);
//            QSpacerItem* spacerItem = new QSpacerItem(0, 0, QSizePolicy::Expanding, QSizePolicy::Minimum);
//                innerTabLayout->addSpacerItem(spacerItem);

//          //  innerTabLayout->addStretch(1);

//            innerTab->setLayout(innerTabLayout);

//            // Добавляем новую вкладку в QVBoxLayout внутри виджета прокрутки
//            scrollLayout->addWidget(innerTab);

//            // Присваиваем имя вкладке на основе значения kkoovt_kod
//            tabWidget->setTabText(tabWidget->indexOf(innerTab), vvtVfvp.kkoovt_kod);
//        }

//       // scrollLayout->addStretch(1);
//        scrollArea->setWidget(scrollContentWidget);
//        tab5Layout->addWidget(scrollArea);

//        // Устанавливаем QVBoxLayout внутри tab5
//        tab5->setLayout(tab5Layout);

//        // Устанавливаем QVBoxLayout внутри tab5
//                tab5->setLayout(tab5Layout);

//                // Создаем вертикальную полосу прокрутки и добавляем ее к виджету прокрутки
//                scrollArea->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOn);

//                // Устанавливаем виджет прокрутки внутри tab5
//                tab5Layout->addWidget(scrollArea);

//                // Устанавливаем флаг, что вкладки были созданы
//                tabsCreated = true;
//            }
//        }
/// компактный вариант со скролом (списком)
// void MainWindow::onTreeViewItemClicked(const QModelIndex& modelIndex)
//{
//    QString vfvpKod = modelIndex.data(Qt::UserRole).toString();
//    VFVPModel* vModelPtr = vfvpMap.value(vfvpKod);
//    if (vModelPtr != nullptr) {
//        vfvpmodel = *vModelPtr;
//    } else {
//        QMessageBox::warning(this, tr("Внимание!"), tr("Объект для данного ключа не найден! %1").arg(vfvpKod));
//    }

//
//        if (!tabsCreated) {


//    QVBoxLayout* tab5Layout = new QVBoxLayout(tab5);
//    QScrollArea* scrollArea = new QScrollArea(tab5);
//    scrollArea->setWidgetResizable(true);
//    QWidget* scrollContentWidget = new QWidget();
//    QVBoxLayout* scrollLayout = new QVBoxLayout(scrollContentWidget);

//    QList<QPair<QString, QString>> descriptionsAndCodes;

//    for (int i = 0; i < vfvpmodel.vvtVfsvLst.size(); i++) {
//        VVTVFVP vvtVfvp = vfvpmodel.vvtVfsvLst.at(i);
//        descriptionsAndCodes.append(qMakePair(vvtVfvp.description, vvtVfvp.kkoovt_kod));

//        QWidget* innerTab = new QWidget(scrollContentWidget);
//        QVBoxLayout* innerTabLayout = new QVBoxLayout(innerTab);

//        QList<QPair<QString, QString>> labelsAndEdits = {
//            qMakePair(QString("Наименование блока"), vvtVfvp.description),
//            qMakePair(QString("Код по классификатору"), vvtVfvp.kkoovt_kod),
//            qMakePair(QString("Количество по штату"), vvtVfvp.kolshtat),
//            qMakePair(QString("Количество в наличии"), vvtVfvp.kolnal),
//            qMakePair(QString("Комплектность"), vvtVfvp.ukompl)
//        };

//        for (const auto& pair : labelsAndEdits) {
//            QLabel* label = new QLabel(pair.first, innerTab);
//            QLineEdit* edit = new QLineEdit(pair.second, innerTab);
//            edit->setReadOnly(true);

//            innerTabLayout->addWidget(label);
//            innerTabLayout->addWidget(edit);
//        }

//        innerTab->setLayout(innerTabLayout);
//        scrollLayout->addWidget(innerTab);
//        tabWidget->setTabText(tabWidget->indexOf(innerTab), vvtVfvp.kkoovt_kod);
//    }

//    scrollArea->setWidget(scrollContentWidget);
//    tab5Layout->addWidget(scrollArea);
//    tab5->setLayout(tab5Layout);
//   tabsCreated = true;
//}
//}
/// вариант с обновлением и скролом
//void MainWindow::onTreeViewItemClicked(const QModelIndex& modelIndex)
//{
//    QString vfvpKod = modelIndex.data(Qt::UserRole).toString();
//    VFVPModel* vModelPtr = vfvpMap.value(vfvpKod);
//    if (vModelPtr != nullptr) {
//        vfvpmodel = *vModelPtr;
//    } else {
//        QMessageBox::warning(this, tr("Внимание!"), tr("Объект для данного ключа не найден! %1").arg(vfvpKod));
//    }

//    if (!tabsCreated) {
//        // Создаем вкладки
//        QVBoxLayout* tab5Layout = new QVBoxLayout(tab5);
//        QScrollArea* scrollArea = new QScrollArea(tab5);
//        scrollArea->setWidgetResizable(true);
//        QWidget* scrollContentWidget = new QWidget();
//        QVBoxLayout* scrollLayout = new QVBoxLayout(scrollContentWidget);

//        QList<QPair<QString, QString>> descriptionsAndCodes;

//        for (int i = 0; i < vfvpmodel.vvtVfsvLst.size(); i++) {
//            VVTVFVP vvtVfvp = vfvpmodel.vvtVfsvLst.at(i);
//            descriptionsAndCodes.append(qMakePair(vvtVfvp.description, vvtVfvp.kkoovt_kod));

//            QWidget* innerTab = new QWidget(scrollContentWidget);
//            QVBoxLayout* innerTabLayout = new QVBoxLayout(innerTab);

//            QList<QPair<QString, QString>> labelsAndEdits = {
//                qMakePair(QString("Наименование блока"), vvtVfvp.description),
//                qMakePair(QString("Код по классификатору"), vvtVfvp.kkoovt_kod),
//                qMakePair(QString("Количество по штату"), vvtVfvp.kolshtat),
//                qMakePair(QString("Количество в наличии"), vvtVfvp.kolnal),
//                qMakePair(QString("Комплектность"), vvtVfvp.ukompl)
//            };

//            for (const auto& pair : labelsAndEdits) {
//                QLabel* label = new QLabel(pair.first, innerTab);
//                QLineEdit* edit = new QLineEdit(pair.second, innerTab);
//                edit->setReadOnly(true);

//                innerTabLayout->addWidget(label);
//                innerTabLayout->addWidget(edit);
//            }

//            innerTab->setLayout(innerTabLayout);
//            scrollLayout->addWidget(innerTab);
//            tabWidget->setTabText(tabWidget->indexOf(innerTab), vvtVfvp.kkoovt_kod);
//        }

//        scrollArea->setWidget(scrollContentWidget);
//        tab5Layout->addWidget(scrollArea);
//        tab5->setLayout(tab5Layout);
//        tabsCreated = true;
//    } else {
//        qDebug() << "Удаляю вкладки";
//        // Удаляем существующие вкладки
//        QVBoxLayout* tab5Layout = qobject_cast<QVBoxLayout*>(tab5->layout());
//        QScrollArea* scrollArea = qobject_cast<QScrollArea*>(tab5Layout->itemAt(0)->widget());
//        QWidget* scrollContentWidget = scrollArea->widget();
//        QVBoxLayout* scrollLayout = qobject_cast<QVBoxLayout*>(scrollContentWidget->layout());

//        while (scrollLayout->count() > 0) {
//            QWidget* innerTab = scrollLayout->itemAt(0)->widget();
//            scrollLayout->removeWidget(innerTab);
//            delete innerTab;
//        }
// qDebug() << "Создаем новые вкладки";
//        // Создаем новые вкладки
//        QList<QPair<QString, QString>> descriptionsAndCodes;

//        for (int i = 0; i < vfvpmodel.vvtVfsvLst.size(); i++) {
//            VVTVFVP vvtVfvp = vfvpmodel.vvtVfsvLst.at(i);
//            descriptionsAndCodes.append(qMakePair(vvtVfvp.description, vvtVfvp.kkoovt_kod));

//            QWidget* innerTab = new QWidget(scrollContentWidget);
//            QVBoxLayout* innerTabLayout = new QVBoxLayout(innerTab);

//            QList<QPair<QString, QString>> labelsAndEdits = {
//                qMakePair(QString("Наименование блока"), vvtVfvp.description),
//                qMakePair(QString("Код по классификатору"), vvtVfvp.kkoovt_kod),
//                qMakePair(QString("Количество по штату"), vvtVfvp.kolshtat),
//                qMakePair(QString("Количество в наличии"), vvtVfvp.kolnal),
//                qMakePair(QString("Комплектность"), vvtVfvp.ukompl)

//            };
//qDebug() << "Создаем новые вкладки";
//            for (const auto& pair : labelsAndEdits) {
//                QLabel* label = new QLabel(pair.first, innerTab);
//                QLineEdit* edit = new QLineEdit(pair.second, innerTab);
//                edit->setReadOnly(true);

//                innerTabLayout->addWidget(label);
//                innerTabLayout->addWidget(edit);
//            }

//            innerTab->setLayout(innerTabLayout);
//            scrollLayout->addWidget(innerTab);
//            tabWidget->setTabText(tabWidget->indexOf(innerTab), vvtVfvp.kkoovt_kod);
//        }
//qDebug() << "Создаем новые вкладки";
//        scrollContentWidget->setLayout(scrollLayout);
//        scrollArea->setWidget(scrollContentWidget);
//    }
//}


///Простой вариант с динамическими вкладками
//void MainWindow::onTreeViewItemClicked(const QModelIndex &modelIndex)
//{
//    QString vfvpKod = modelIndex.data(Qt::UserRole).toString();
//    VFVPModel* vModelPtr = vfvpMap.value(vfvpKod);
//    if (vModelPtr != nullptr) {
//        vfvpmodel = *vModelPtr;
//    } else {
//        QMessageBox::warning(this, tr("Внимание!"), tr("Объект для данного ключа не найден! %1").arg(vfvpKod));
//    }


//    // Проверяем, были ли уже созданы вкладки
//    if (!tabsCreated) {
//           // Создаем QTabWidget для вкладок внутри tab5
//           QTabWidget* innerTabWidget = new QTabWidget(tab5);
//           QGridLayout* tab5Layout = new QGridLayout(tab5);
//           tab5Layout->addWidget(innerTabWidget, 0, 0, 1, 1);
//           tab5->setLayout(tab5Layout);

//           // Создаем вкладки и добавляем их в innerTabWidget
//           for (int i = 0; i < vfvpmodel.vvtVfsvLst.size(); i++) {
//        VVTVFVP vvtVfvp = vfvpmodel.vvtVfsvLst.at(i);

//        QWidget* innerTab = new QWidget(innerTabWidget);
//        QVBoxLayout* innerTabLayout = new QVBoxLayout(innerTab);

//        QLabel* labelc1 = new QLabel("Наименование блока", innerTab);
//        QLabel* labelc2 = new QLabel("Код по классификатору", innerTab);
//        QLabel* labelc3 = new QLabel("Количество по штату", innerTab);
//        QLabel* labelc4 = new QLabel("Количество в наличии", innerTab);
//        QLabel* labelc5 = new QLabel("Комплектность", innerTab);

//        QLineEdit* textEdit1 = new QLineEdit(innerTab);
//        QLineEdit* textEdit2 = new QLineEdit(innerTab);
//        QLineEdit* textEdit3 = new QLineEdit(innerTab);
//        QLineEdit* textEdit4 = new QLineEdit(innerTab);
//        QLineEdit* textEdit5 = new QLineEdit(innerTab);

//        textEdit1->setObjectName(QString("TextEdit1Tab5_%1").arg(i));
//        textEdit2->setObjectName(QString("TextEdit2Tab5_%1").arg(i));
//        textEdit3->setObjectName(QString("TextEdit3Tab5_%1").arg(i));
//        textEdit4->setObjectName(QString("TextEdit4Tab5_%1").arg(i));
//        textEdit5->setObjectName(QString("TextEdit5Tab5_%1").arg(i));

//        textEdit1->setReadOnly(true);
//        textEdit2->setReadOnly(true);
//        textEdit3->setReadOnly(true);
//        textEdit4->setReadOnly(true);
//        textEdit5->setReadOnly(true);

//        textEdit1->setText(vvtVfvp.description);
//        textEdit2->setText(vvtVfvp.kkoovt_kod);
//        textEdit3->setText(vvtVfvp.kolshtat);
//        textEdit4->setText(vvtVfvp.kolnal);
//        textEdit5->setText(vvtVfvp.ukompl);

//        innerTabLayout->addWidget(labelc1);
//        innerTabLayout->addWidget(textEdit1);
//        innerTabLayout->addWidget(labelc2);
//        innerTabLayout->addWidget(textEdit2);
//        innerTabLayout->addWidget(labelc3);
//        innerTabLayout->addWidget(textEdit3);
//        innerTabLayout->addWidget(labelc4);
//        innerTabLayout->addWidget(textEdit4);
//        innerTabLayout->addWidget(labelc5);
//        innerTabLayout->addWidget(textEdit5);
//        innerTabLayout->addStretch(1);
//        innerTab->setLayout(innerTabLayout);

//        // Добавляем внутреннюю вкладку innerTab в innerTabWidget
//                  innerTabWidget->addTab(innerTab, vvtVfvp.kkoovt_kod);
//              }

//              // Устанавливаем флаг, что вкладки были созданы
//              tabsCreated = true;
//          }
//      }
// компактный вариант с вкладками внутри !!!
//void MainWindow::onTreeViewItemClicked(const QModelIndex &modelIndex)
//{
//    QString vfvpKod = modelIndex.data(Qt::UserRole).toString();
//    VFVPModel* vModelPtr = vfvpMap.value(vfvpKod);
//    if (vModelPtr != nullptr) {
//        vfvpmodel = *vModelPtr;
//    } else {
//        QMessageBox::warning(this, tr("Внимание!"), tr("Объект для данного ключа не найден! %1").arg(vfvpKod));
//    }

//    // Проверяем, были ли уже созданы вкладки
//if (!tabsCreated) {
//    // Создаем QTabWidget для вкладок внутри tab5
//    QTabWidget* innerTabWidget = new QTabWidget(tab5);
//    tab5->setLayout(new QGridLayout(tab5));
//    tab5->layout()->addWidget(innerTabWidget);

//    // Создаем вкладки и добавляем их в innerTabWidget
//        for (int i = 0; i < vfvpmodel.vvtVfsvLst.size(); i++) {
//            VVTVFVP vvtVfvp = vfvpmodel.vvtVfsvLst.at(i);

//            QWidget* innerTab = new QWidget(innerTabWidget);
//            QVBoxLayout* innerTabLayout = new QVBoxLayout(innerTab);


//        QList<QPair<QString, QString>> labelDataList = {
//            {"Наименование блока", vvtVfvp.description},
//            {"Код по классификатору", vvtVfvp.kkoovt_kod},
//            {"Количество по штату", vvtVfvp.kolshtat},
//            {"Количество в наличии", vvtVfvp.kolnal},
//            {"Комплектность", vvtVfvp.ukompl}
//        };

//        for (const auto& labelData : labelDataList) {
//            QLabel* label = new QLabel(labelData.first, innerTab);
//            QLineEdit* lineEdit = new QLineEdit(innerTab);
//            lineEdit->setObjectName(QString("TextEdit%1Tab5_%2").arg(labelData.first).arg(i));
//            lineEdit->setReadOnly(true);
//            lineEdit->setText(labelData.second);

//            innerTabLayout->addWidget(label);
//            innerTabLayout->addWidget(lineEdit);
//        }

//        innerTabLayout->addStretch(1);
//        innerTab->setLayout(innerTabLayout);

//        // Добавляем внутреннюю вкладку innerTab в innerTabWidget
//        innerTabWidget->addTab(innerTab, vvtVfvp.kkoovt_kod);
//    }

//    // Устанавливаем флаг, что вкладки были созданы
//    tabsCreated = true;
//}
//}
/// код с проверкой и удалением (обновлением) вкладок РАБОТАЕТ!!!

void MainWindow::onTreeViewItemClicked(const QModelIndex &modelIndex)
{
    QString vfvpKod = modelIndex.data(Qt::UserRole).toString();
    VFVPModel* vModelPtr = vfvpMap.value(vfvpKod);
    if (vModelPtr != nullptr) {
        vfvpmodel = *vModelPtr;
    } else {
        QMessageBox::warning(this, tr("Внимание!"), tr("Объект для данного ключа не найден! %1").arg(vfvpKod));
    }
 //int lastActiveTabIndex = tabWidget->currentIndex();
 int lastActiveTabIndex = tabWidget->currentIndex();
      //   activeTabMap.insert(treeView->currentIndex(), lastActiveTabIndex);
//// РПроверить
//    // Очищаем существующие вкладки в tab6
//     while (tabWidget->count() > 1) {
//         delete tabWidget->widget(1);
//     }

//     if (!vfvpmodel.txfDataLst.isEmpty()) {
//         int numOfTabs = vfvpmodel.txfDataLst.size();

//         if (numOfTabs > 1) {
//// if{ (txfDataWorker.setCOD_TYPE == "VEC")
//             // Создаем динамические вкладки
//             for (int i = 0; i < numOfTabs; i++) {
//                 TXFDataWorker txfDataWorker(vfvpmodel.txfDataLst.at(i));
//                 QString tabTitle = "Знак " + QString::number(i + 1);
//                 QWidget* dynamicTab = createDynamicTab(tabTitle, txfDataWorker);/// тут поменять функцию на лин
// else { /// напечатать как есть или подставить нужную функцию
//                 tabWidget->addTab(dynamicTab, tabTitle);
//             }
//         } else {
//             // Отображаем поля и лейблы в главной вкладке tab6
//             TXFDataWorker txfDataWorker(vfvpmodel.txfDataLst.at(0));
//             updateTab6Fields(txfDataWorker);
//         }
//     }
// }

// QWidget* MainWindow::createDynamicTab(const QString& tabTitle, const TXFDataWorker& txfDataWorker)
// {
//     QWidget* dynamicTab = new QWidget(tabWidget);
//     QVBoxLayout* dynamicTabLayout = new QVBoxLayout(dynamicTab);
//     dynamicTab->setLayout(dynamicTabLayout);

//     // Создаем и настраиваем QLabel и QLineEdit для каждого поля
//     QLabel* labelc1Tab6 = new QLabel(("Ключ знака ( уникальный идентификатор )"), dynamicTab);
//     QLabel* labelc2Tab6 = new QLabel(("Код знака ( код серии знаков )"), dynamicTab);
//     QLabel* labelc3Tab6 = new QLabel(("Тип знака (  )"), dynamicTab);
//     QLabel* labelc4Tab6 = new QLabel(("  точка - расположение знака "), dynamicTab);
//     QLabel* labelc5Tab6 = new QLabel(("X:"), dynamicTab);
//     QLabel* labelc6Tab6 = new QLabel(("Y:"), dynamicTab);

//     QLabel* labelc7Tab6 = new QLabel((" точка - вектора знака    "), dynamicTab);
//     QLabel* labelc8Tab6 = new QLabel(("X:"), dynamicTab);
//     QLabel* labelc9Tab6 = new QLabel(("Y:"), dynamicTab);
//     QLabel* labelc10Tab6 = new QLabel((" Надпись внутри знака "), dynamicTab);
//     QLabel* labelc11Tab6 = new QLabel((" Текст внутри знака  "), dynamicTab);

//     QLineEdit* editc1Tab6 = new QLineEdit(dynamicTab);
//     QLineEdit* editc2Tab6 = new QLineEdit(dynamicTab);
//     QLineEdit* editc3Tab6 = new QLineEdit(dynamicTab);
//     QLineEdit* editc4Tab6 = new QLineEdit(dynamicTab);
//     QLineEdit* editc5Tab6 = new QLineEdit(dynamicTab);
//     QLineEdit* editc6Tab6 = new QLineEdit(dynamicTab);
//     QLineEdit* editc7Tab6 = new QLineEdit(dynamicTab);
//     QLineEdit* editc8Tab6 = new QLineEdit(dynamicTab);
//     QLineEdit* editc9Tab6 = new QLineEdit(dynamicTab);
//     QLineEdit* editc10Tab6 = new QLineEdit(dynamicTab);
//     QLineEdit* editc11Tab6 = new QLineEdit(dynamicTab);

//     // Устанавливаем значения полей на основе данных txfDataWorker
//     editc1Tab6->setText(txfDataWorker.getKEY());
//     editc2Tab6->setText(txfDataWorker.getCOD());
//     editc3Tab6->setText(txfDataWorker.getCOD_TYPE());

// //тут как у меня+ добавить проверку на лин ...
//     editc4Tab6->setText(txfDataWorker.getPOINT1());
//     editc5Tab6->setText(txfDataWorker.getXPOINT1());
//     editc6Tab6->setText(txfDataWorker.getYPOINT1());
//     editc7Tab6->setText(txfDataWorker.getPOINT2());
//     editc8Tab6->setText(txfDataWorker.getXPOINT2());
//     editc9Tab6->setText(txfDataWorker.getYPOINT2());
//     editc10Tab6->setText(txfDataWorker.getTEXTIN());
//     editc11Tab6->setText(txfDataWorker.getTEXTOUT());

//     // Добавляем QLabel и QLineEdit на форму
//     dynamicTabLayout->addWidget(labelc1Tab6);
//     dynamicTabLayout->addWidget(editc1Tab6);
//     dynamicTabLayout->addWidget(labelc2Tab6);
//     dynamicTabLayout->addWidget(editc2Tab6);
//     dynamicTabLayout->addWidget(labelc3Tab6);
//     dynamicTabLayout->addWidget(editc3Tab6);
//     dynamicTabLayout->addWidget(labelc4Tab6);
//     dynamicTabLayout->addWidget(editc4Tab6);
//     dynamicTabLayout->addWidget(labelc5Tab6);
//     dynamicTabLayout->addWidget(editc5Tab6);
//     dynamicTabLayout->addWidget(labelc6Tab6);
//     dynamicTabLayout->addWidget(editc6Tab6);
//     dynamicTabLayout->addWidget(labelc7Tab6);
//     dynamicTabLayout->addWidget(editc7Tab6);
//     dynamicTabLayout->addWidget(labelc8Tab6);
//     dynamicTabLayout->addWidget(editc8Tab6);
//     dynamicTabLayout->addWidget(labelc9Tab6);
//     dynamicTabLayout->addWidget(editc9Tab6);
//     dynamicTabLayout->addWidget(labelc10Tab6);
//     dynamicTabLayout->addWidget(editc10Tab6);
//     dynamicTabLayout->addWidget(labelc11Tab6);
//     dynamicTabLayout->addWidget(editc11Tab6);

//     dynamicTabLayout->addStretch(1);
//     return dynamicTab;



//}
    ////////////////////////////////////////////////////////
//     onTreeViewItemClickedTab5();
   // onTreeViewItemClickedTab2();


//}
//void MainWindow::onTreeViewItemClickedTab5()
//{
    // Проверяем, были ли уже созданы вкладки



//void MainWindow::onTreeViewItemClickedTab2()

//{
//// Проверяем, были ли уже созданы вкладки
//    if (!tabsCreated) {
//        // Создаем QTabWidget для вкладок внутри tab2
//        innerTabWidget = new QTabWidget(tab2);
//        tab2->setLayout(new QVBoxLayout(tab2));
//        tab2->layout()->addWidget(innerTabWidget);

//        // Создаем вкладки и добавляем их в innerTabWidget
//        int positionCount = 0;
//        for (const POSVFVP& posVfvp : vfvpmodel.posVfvpLst) {
//            if (posVfvp.description == "pvfvp") {
//                QWidget* innerTab = new QWidget(innerTabWidget);
//                QVBoxLayout* innerTabLayout = new QVBoxLayout(innerTab);
//                QList<QPair<QString, QString>> labelDataList = {
//                                {"Наименование блока", posVfvp.description},
//                                {"Широта", posVfvp.latitude},
//                                {"Долгота", posVfvp.longitude},
//                                {"Высота", posVfvp.height},
//                                {"Пояснение", posVfvp.OK}
//                            };

//                QLabel* label = new QLabel(QString("Положение %1").arg(++positionCount), innerTab);
//                innerTabLayout->addWidget(label);
//                innerTabLayout->addStretch(1);
//                innerTab->setLayout(innerTabLayout);

//                // Добавляем внутреннюю вкладку innerTab в innerTabWidget
//                innerTabWidget->addTab(innerTab, QString("Положение %1").arg(positionCount));
//            }
//        }

//        // Устанавливаем флаг, что вкладки были созданы
//        tabsCreated = true;
//    }
//    else {
//        // Удаляем существующие вкладки
//        while (innerTabWidget->count() > 0) {
//            QWidget* tab = innerTabWidget->widget(0);
//            innerTabWidget->removeTab(0);
//            delete tab;
//        }

//        // Создаем новые вкладки и добавляем их в innerTabWidget (код здесь повторяет предыдущий блок)
//        int positionCount = 0;
//        for (const POSVFVP& posVfvp : vfvpmodel.posVfvpLst) {
//            if (posVfvp.description == "pvfvp") {
//                QWidget* innerTab = new QWidget(innerTabWidget);
//                QVBoxLayout* innerTabLayout = new QVBoxLayout(innerTab);

//                QLabel* label = new QLabel(QString("Положение %1").arg(++positionCount), innerTab);
//                innerTabLayout->addWidget(label);
//                innerTabLayout->addStretch(1);
//                innerTab->setLayout(innerTabLayout);

//                // Добавляем внутреннюю вкладку innerTab в innerTabWidget
//                innerTabWidget->addTab(innerTab, QString("Положение %1").arg(positionCount));
//            }
//        }
//    }
//}
//     if (!tabsCreatedTab6) {

// QVBoxLayout *tab6Layout = new QVBoxLayout(tab6);
// tab6->setLayout(tab6Layout);

// QLabel *labelc1Tab6 = new QLabel(("Ключ знака ( уникальный идентификатор )"), tab6);
// QLabel *labelc2Tab6 = new QLabel(("Код знака ( код серии знаков )"), tab6);
// QLabel *labelc3Tab6 = new QLabel(("Тип знака (  )"), tab6);
// QLabel *labelc4Tab6 = new QLabel((" 1я точка - расположение знака "), tab6);
// QLabel *labelc5Tab6 = new QLabel(("X:"), tab6);
// QLabel *labelc6Tab6 = new QLabel(("Y:"), tab6);

// QLabel *labelc7Tab6 = new QLabel((" 2я точка - направление знака    "), tab6);
// QLabel *labelc8Tab6 = new QLabel(("X:"), tab6);
// QLabel *labelc9Tab6 = new QLabel(("Y:"), tab6);
// QLabel *labelc10Tab6 = new QLabel((" Надпись внутри знака "), tab6);
// QLabel *labelc11Tab6 = new QLabel(("Ключ:"), tab6);
// QLabel *labelc12Tab6 = new QLabel(("Значение:"), tab6);
// QLabel *labelc13Tab6 = new QLabel((" Надпись возле знака   "), tab6);
// QLabel *labelc14Tab6 = new QLabel(("Ключ:"), tab6);
// QLabel *labelc15Tab6 = new QLabel(("Значение:"), tab6);

// textTab6Edit1 = new QLineEdit(tab6);
// textTab6Edit1->setObjectName("TextEdit1Tab6");
// textTab6Edit2 = new QLineEdit(tab6);
// textTab6Edit2->setObjectName("TextEdit2Tab6");
// textTab6Edit3 = new QLineEdit(tab6);
// textTab6Edit3->setObjectName("TextEdit3Tab6");

// textTab6Edit4 = new QLineEdit(tab6);
// textTab6Edit4->setObjectName("TextEdit5Tab6");
// textTab6Edit5 = new QLineEdit(tab6);
// textTab6Edit5->setObjectName("TextEdit6Tab6");

// textTab6Edit6 = new QLineEdit(tab6);
// textTab6Edit6->setObjectName("TextEdit7Tab6");
// textTab6Edit7 = new QLineEdit(tab6);
// textTab6Edit7->setObjectName("TextEdit8Tab6");

// textTab6Edit8 = new QLineEdit(tab6);
// textTab6Edit8->setObjectName("TextEdit9Tab6");
// textTab6Edit9 = new QLineEdit(tab6);
// textTab6Edit9->setObjectName("TextEdit10Tab6");
// textTab6Edit10 = new QLineEdit(tab6);
// textTab6Edit10->setObjectName("TextEdit11Tab6");
// textTab6Edit11 = new QLineEdit(tab6);
// textTab6Edit11->setObjectName("TextEdit12Tab6");

// textTab6Edit1->setReadOnly(true);
// textTab6Edit2->setReadOnly(true);
// textTab6Edit3->setReadOnly(true);
// textTab6Edit4->setReadOnly(true);
// textTab6Edit5->setReadOnly(true);
// textTab6Edit6->setReadOnly(true);
// textTab6Edit7->setReadOnly(true);
// textTab6Edit8->setReadOnly(true);
// textTab6Edit9->setReadOnly(true);
// textTab6Edit10->setReadOnly(true);
// textTab6Edit11->setReadOnly(true);

// QHBoxLayout *coordinatesLayout = new QHBoxLayout();
// coordinatesLayout->addWidget(labelc4Tab6);

// coordinatesLayout->addWidget(labelc5Tab6);
// coordinatesLayout->addWidget(textTab6Edit4);
// coordinatesLayout->addWidget(labelc6Tab6);
// coordinatesLayout->addWidget(textTab6Edit5);

// QHBoxLayout *coordinatesLayout2 = new QHBoxLayout();
// coordinatesLayout2->addWidget(labelc7Tab6);

// coordinatesLayout2->addWidget(labelc8Tab6);
// coordinatesLayout2->addWidget(textTab6Edit6);
// coordinatesLayout2->addWidget(labelc9Tab6);
// coordinatesLayout2->addWidget(textTab6Edit7);

// QGroupBox *groupBox = new QGroupBox("Метрика");
// QVBoxLayout *groupBoxLayout =new QVBoxLayout();
// groupBoxLayout->addLayout(coordinatesLayout);
//  groupBoxLayout->addLayout(coordinatesLayout2);

//  groupBox->setLayout(groupBoxLayout);

//  QHBoxLayout *coordinatesLayoutS = new QHBoxLayout();
//  coordinatesLayoutS->addWidget(labelc10Tab6);
//  coordinatesLayoutS->addWidget(labelc11Tab6);
//  coordinatesLayoutS->addWidget(textTab6Edit8);
//  coordinatesLayoutS->addWidget(labelc12Tab6);
//  coordinatesLayoutS->addWidget(textTab6Edit9);

//  QHBoxLayout *coordinatesLayoutS2 = new QHBoxLayout();
//  coordinatesLayoutS2->addWidget(labelc13Tab6);

//  coordinatesLayoutS2->addWidget(labelc14Tab6);
//  coordinatesLayoutS2->addWidget(textTab6Edit10);
//  coordinatesLayoutS2->addWidget(labelc15Tab6);
//  coordinatesLayoutS2->addWidget(textTab6Edit11);

//  QGroupBox *groupBox2 = new QGroupBox("Семантика");
//  QVBoxLayout *groupBoxLayoutS =new QVBoxLayout();
//  groupBoxLayoutS->addLayout(coordinatesLayoutS);
//  groupBoxLayoutS->addLayout(coordinatesLayoutS2);
//  groupBox2->setLayout(groupBoxLayoutS);
//  tab6Layout->addWidget(labelc1Tab6);
//  tab6Layout->addWidget(textTab6Edit1);
//  tab6Layout->addWidget(labelc2Tab6);
//  tab6Layout->addWidget(textTab6Edit2);
//  tab6Layout->addWidget(labelc3Tab6);
//  tab6Layout->addWidget(textTab6Edit3);
//  tab6Layout->addWidget(groupBox);
//  tab6Layout->addWidget(groupBox2);
//  tab6Layout->addStretch(1);
//  tabsCreatedTab6 = true;
//     }
//    /// картографические данные [ kdou ] => modelView
//     if ( !vfvpmodel.txfDataLst.isEmpty() ) {
//       // tabWidget->insertTab(tabIndex, tab6, "Картографические данные [ kdou ]");
//      TXFDataWorker txfDataWorker( vfvpmodel.txfDataLst.at( 0 ) );
//      textTab6Edit1->setText( txfDataWorker.getKEY() );
//      textTab6Edit2->setText( txfDataWorker.getCOD() );
//      textTab6Edit3->setText( txfDataWorker.getCOD_TYPE() );
//      textTab6Edit4->setText( txfDataWorker.getMET().at( 0 ).first);
//      textTab6Edit5->setText( txfDataWorker.getMET().at( 0 ).second);
//      textTab6Edit6->setText( txfDataWorker.getMET().at( 1 ).first);
//      textTab6Edit7->setText( txfDataWorker.getMET().at( 1 ).second);
//      QString semKeyGui( txfDataWorker.getSEMList().at( 0 ) );
//      QString semValue = ( txfDataWorker.getSEMValue( semKeyGui ));
//      textTab6Edit8->setText("SEM 1-> " + semKeyGui);
//      textTab6Edit9->setText("SEM 1-> " + semValue);
//      QString semKey( txfDataWorker.getSEMList().at( 1 ) );
//      QString semValue1 = ( txfDataWorker.getSEMValue( semKey ));
//      textTab6Edit10->setText("SEM 2-> " + semKey );
//      textTab6Edit11->setText("SEM 2-> " + semValue1);
//}
/// С УСЛОВИЕМ
///
 //if (!tabsCreatedTab6) {
    // Удалите существующие динамические вкладки, если они есть
//    while (innerTab6Widget->count() > 1) {
//        QWidget *tab = innerTab6Widget->widget(1);
//        innerTab6Widget->removeTab(1);
//        delete tab;
//    }
//if (!tabsCreatedTab6) {
//    innerTab6Widget = new QTabWidget(tab6);
//    tab6->setLayout(new QVBoxLayout(tab6));
//    tab6->layout()->addWidget(innerTab6Widget);
//    // Создайте динамические вкладки на основе значений txfDataWorker.setCOD_TYPE()
//    int positionCount = 0;
//    for (int i = 0; i < vfvpmodel.txfDataLst.size(); ++i) {
//        TXFDataWorker& txfDataWorker = vfvpmodel.txfDataLst[i];
//    //for ( TXFDataWorker& txfDataWorker : vfvpmodel.txfDataLst) {
//        if (txfDataWorker.mCOD_TYPE_ == "VEC") {

//            // Создайте новую динамическую вкладку
//            QWidget *innerTab6 = new QWidget(innerTab6Widget);
//            innerTab6Widget->addTab(innerTab6, QString("Знак %1").arg(txfDataWorker.mCOD_TYPE_ , ++positionCount));

//            QVBoxLayout *tab6Layout = new QVBoxLayout(innerTab6);
//            innerTab6->setLayout(tab6Layout);


//QLabel *labelc1Tab6 = new QLabel(("Ключ знака ( уникальный идентификатор )"), innerTab6);
// QLabel *labelc2Tab6 = new QLabel(("Код знака ( код серии знаков )"), innerTab6);
// QLabel *labelc3Tab6 = new QLabel(("Тип знака (  )"), innerTab6);
// QLabel *labelc4Tab6 = new QLabel((" 1я точка - расположение знака "), innerTab6);
// QLabel *labelc5Tab6 = new QLabel(("X:"), innerTab6);
// QLabel *labelc6Tab6 = new QLabel(("Y:"), innerTab6);

// QLabel *labelc7Tab6 = new QLabel((" 2я точка - направление знака    "), innerTab6);
// QLabel *labelc8Tab6 = new QLabel(("X:"), innerTab6);
// QLabel *labelc9Tab6 = new QLabel(("Y:"), innerTab6);
// QLabel *labelc10Tab6 = new QLabel((" Надпись внутри знака "), innerTab6);
// QLabel *labelc11Tab6 = new QLabel(("Ключ:"), innerTab6);
// QLabel *labelc12Tab6 = new QLabel(("Значение:"), innerTab6);
// QLabel *labelc13Tab6 = new QLabel((" Надпись возле знака   "), innerTab6);
// QLabel *labelc14Tab6 = new QLabel(("Ключ:"), innerTab6);
// QLabel *labelc15Tab6 = new QLabel(("Значение:"), innerTab6);

// QLineEdit* textTab6Edit1 = new QLineEdit(innerTab6);
// textTab6Edit1->setObjectName("TextEdit1Tab6");
// QLineEdit* textTab6Edit2 = new QLineEdit(innerTab6);
// textTab6Edit2->setObjectName("TextEdit2Tab6");
// QLineEdit* textTab6Edit3 = new QLineEdit(innerTab6);
// textTab6Edit3->setObjectName("TextEdit3Tab6");

// QLineEdit* textTab6Edit4 = new QLineEdit(innerTab6);
// textTab6Edit4->setObjectName("TextEdit5Tab6");
// QLineEdit* textTab6Edit5 = new QLineEdit(innerTab6);
// textTab6Edit5->setObjectName("TextEdit6Tab6");

// QLineEdit* textTab6Edit6 = new QLineEdit(innerTab6);
// textTab6Edit6->setObjectName("TextEdit7Tab6");
// QLineEdit* textTab6Edit7 = new QLineEdit(innerTab6);
// textTab6Edit7->setObjectName("TextEdit8Tab6");

// QLineEdit* textTab6Edit8 = new QLineEdit(innerTab6);
// textTab6Edit8->setObjectName("TextEdit9Tab6");
// QLineEdit* textTab6Edit9 = new QLineEdit(innerTab6);
// textTab6Edit9->setObjectName("TextEdit10Tab6");
// QLineEdit* textTab6Edit10 = new QLineEdit(innerTab6);
// textTab6Edit10->setObjectName("TextEdit11Tab6");
// QLineEdit* textTab6Edit11 = new QLineEdit(innerTab6);
// textTab6Edit11->setObjectName("TextEdit12Tab6");

// textTab6Edit1->setReadOnly(true);
// textTab6Edit2->setReadOnly(true);
// textTab6Edit3->setReadOnly(true);
// textTab6Edit4->setReadOnly(true);
// textTab6Edit5->setReadOnly(true);
// textTab6Edit6->setReadOnly(true);
// textTab6Edit7->setReadOnly(true);
// textTab6Edit8->setReadOnly(true);
// textTab6Edit9->setReadOnly(true);
// textTab6Edit10->setReadOnly(true);
// textTab6Edit11->setReadOnly(true);

// QHBoxLayout *coordinatesLayout = new QHBoxLayout();
// coordinatesLayout->addWidget(labelc4Tab6);

// coordinatesLayout->addWidget(labelc5Tab6);
// coordinatesLayout->addWidget(textTab6Edit4);
// coordinatesLayout->addWidget(labelc6Tab6);
// coordinatesLayout->addWidget(textTab6Edit5);

// QHBoxLayout *coordinatesLayout2 = new QHBoxLayout();
// coordinatesLayout2->addWidget(labelc7Tab6);

// coordinatesLayout2->addWidget(labelc8Tab6);
// coordinatesLayout2->addWidget(textTab6Edit6);
// coordinatesLayout2->addWidget(labelc9Tab6);
// coordinatesLayout2->addWidget(textTab6Edit7);

// QGroupBox *groupBox = new QGroupBox("Метрика");
// QVBoxLayout *groupBoxLayout =new QVBoxLayout();
// groupBoxLayout->addLayout(coordinatesLayout);
//  groupBoxLayout->addLayout(coordinatesLayout2);

//  groupBox->setLayout(groupBoxLayout);

//  QHBoxLayout *coordinatesLayoutS = new QHBoxLayout();
//  coordinatesLayoutS->addWidget(labelc10Tab6);
//  coordinatesLayoutS->addWidget(labelc11Tab6);
//  coordinatesLayoutS->addWidget(textTab6Edit8);
//  coordinatesLayoutS->addWidget(labelc12Tab6);
//  coordinatesLayoutS->addWidget(textTab6Edit9);

//  QHBoxLayout *coordinatesLayoutS2 = new QHBoxLayout();
//  coordinatesLayoutS2->addWidget(labelc13Tab6);

//  coordinatesLayoutS2->addWidget(labelc14Tab6);
//  coordinatesLayoutS2->addWidget(textTab6Edit10);
//  coordinatesLayoutS2->addWidget(labelc15Tab6);
//  coordinatesLayoutS2->addWidget(textTab6Edit11);

//  QGroupBox *groupBox2 = new QGroupBox("Семантика");
//  QVBoxLayout *groupBoxLayoutS =new QVBoxLayout();
//  groupBoxLayoutS->addLayout(coordinatesLayoutS);
//  groupBoxLayoutS->addLayout(coordinatesLayoutS2);
//  groupBox2->setLayout(groupBoxLayoutS);

//  if ( !vfvpmodel.txfDataLst.isEmpty() ) {

//   TXFDataWorker txfDataWorker( vfvpmodel.txfDataLst.at( i ) );
//   textTab6Edit1->setText( txfDataWorker.getKEY() );
//   textTab6Edit2->setText( txfDataWorker.getCOD() );
//   textTab6Edit3->setText( txfDataWorker.getCOD_TYPE() );
//   textTab6Edit4->setText( txfDataWorker.getMET().at( 0 ).first);
//   textTab6Edit5->setText( txfDataWorker.getMET().at( 0 ).second);
//   textTab6Edit6->setText( txfDataWorker.getMET().at( 1 ).first);
//   textTab6Edit7->setText( txfDataWorker.getMET().at( 1 ).second);
//   QString semKeyGui( txfDataWorker.getSEMList().at( 0 ) );
//   QString semValue = ( txfDataWorker.getSEMValue( semKeyGui ));
//   textTab6Edit8->setText("SEM 1-> " + semKeyGui);
//   textTab6Edit9->setText("SEM 1-> " + semValue);
//   QString semKey( txfDataWorker.getSEMList().at( 1 ) );
//   QString semValue1 = ( txfDataWorker.getSEMValue( semKey ));
//   textTab6Edit10->setText("SEM 2-> " + semKey );
//   textTab6Edit11->setText("SEM 2-> " + semValue1);
//   tab6Layout->addWidget(labelc1Tab6);
//   tab6Layout->addWidget(textTab6Edit1);
//   tab6Layout->addWidget(labelc2Tab6);
//   tab6Layout->addWidget(textTab6Edit2);
//   tab6Layout->addWidget(labelc3Tab6);
//   tab6Layout->addWidget(textTab6Edit3);
//   tab6Layout->addWidget(groupBox);
//   tab6Layout->addWidget(groupBox2);
//   tab6Layout->addStretch(1);
//}
//         }
//    }
//  tabsCreatedTab6 = true;
//     }
//         else {
//             // Удаляем существующие вкладки
//             while (innerTab6Widget->count() > 0) {
//                 QWidget* tabTab6 = innerTab6Widget->widget(0);
//                 innerTab6Widget->removeTab(0);
//                 delete tabTab6;
//             }

//            // for ( TXFDataWorker& txfDataWorker : vfvpmodel.txfDataLst) {
//                 //if (txfDataWorker.setCOD_TYPE() == setCOD_TYPE("VEC")) {
//             int positionCount = 0;
//             for (int i = 0; i < vfvpmodel.txfDataLst.size(); ++i) {
//                 TXFDataWorker& txfDataWorker = vfvpmodel.txfDataLst[i];
//                  if (txfDataWorker.mCOD_TYPE_ == "VEC") {

//                     // Создайте новую динамическую вкладку
//                     QWidget *innerTab6 = new QWidget(innerTab6Widget);
//                     innerTab6Widget->addTab(innerTab6, QString("Знак %1").arg( txfDataWorker.mCOD_TYPE_, ++positionCount));

//                     QVBoxLayout *tab6Layout = new QVBoxLayout(innerTab6);
//                     innerTab6->setLayout(tab6Layout);


//         QLabel *labelc1Tab6 = new QLabel(("Ключ знака ( уникальный идентификатор )"), innerTab6);
//          QLabel *labelc2Tab6 = new QLabel(("Код знака ( код серии знаков )"), innerTab6);
//          QLabel *labelc3Tab6 = new QLabel(("Тип знака (  )"), innerTab6);
//          QLabel *labelc4Tab6 = new QLabel((" 1я точка - расположение знака "), innerTab6);
//          QLabel *labelc5Tab6 = new QLabel(("X:"), innerTab6);
//          QLabel *labelc6Tab6 = new QLabel(("Y:"), innerTab6);

//          QLabel *labelc7Tab6 = new QLabel((" 2я точка - направление знака    "), innerTab6);
//          QLabel *labelc8Tab6 = new QLabel(("X:"), innerTab6);
//          QLabel *labelc9Tab6 = new QLabel(("Y:"), innerTab6);
//          QLabel *labelc10Tab6 = new QLabel((" Надпись внутри знака "), innerTab6);
//          QLabel *labelc11Tab6 = new QLabel(("Ключ:"), innerTab6);
//          QLabel *labelc12Tab6 = new QLabel(("Значение:"), innerTab6);
//          QLabel *labelc13Tab6 = new QLabel((" Надпись возле знака   "), innerTab6);
//          QLabel *labelc14Tab6 = new QLabel(("Ключ:"), innerTab6);
//          QLabel *labelc15Tab6 = new QLabel(("Значение:"), innerTab6);

//          QLineEdit* textTab6Edit1 = new QLineEdit(innerTab6);
//          textTab6Edit1->setObjectName("TextEdit1Tab6");
//          QLineEdit* textTab6Edit2 = new QLineEdit(innerTab6);
//          textTab6Edit2->setObjectName("TextEdit2Tab6");
//          QLineEdit* textTab6Edit3 = new QLineEdit(innerTab6);
//          textTab6Edit3->setObjectName("TextEdit3Tab6");

//          QLineEdit* textTab6Edit4 = new QLineEdit(innerTab6);
//          textTab6Edit4->setObjectName("TextEdit5Tab6");
//          QLineEdit* textTab6Edit5 = new QLineEdit(innerTab6);
//          textTab6Edit5->setObjectName("TextEdit6Tab6");

//          QLineEdit* textTab6Edit6 = new QLineEdit(innerTab6);
//          textTab6Edit6->setObjectName("TextEdit7Tab6");
//          QLineEdit* textTab6Edit7 = new QLineEdit(innerTab6);
//          textTab6Edit7->setObjectName("TextEdit8Tab6");

//          QLineEdit* textTab6Edit8 = new QLineEdit(innerTab6);
//          textTab6Edit8->setObjectName("TextEdit9Tab6");
//          QLineEdit* textTab6Edit9 = new QLineEdit(innerTab6);
//          textTab6Edit9->setObjectName("TextEdit10Tab6");
//          QLineEdit* textTab6Edit10 = new QLineEdit(innerTab6);
//          textTab6Edit10->setObjectName("TextEdit11Tab6");
//          QLineEdit* textTab6Edit11 = new QLineEdit(innerTab6);
//          textTab6Edit11->setObjectName("TextEdit12Tab6");

//          textTab6Edit1->setReadOnly(true);
//          textTab6Edit2->setReadOnly(true);
//          textTab6Edit3->setReadOnly(true);
//          textTab6Edit4->setReadOnly(true);
//          textTab6Edit5->setReadOnly(true);
//          textTab6Edit6->setReadOnly(true);
//          textTab6Edit7->setReadOnly(true);
//          textTab6Edit8->setReadOnly(true);
//          textTab6Edit9->setReadOnly(true);
//          textTab6Edit10->setReadOnly(true);
//          textTab6Edit11->setReadOnly(true);

//          QHBoxLayout *coordinatesLayout = new QHBoxLayout();
//          coordinatesLayout->addWidget(labelc4Tab6);

//          coordinatesLayout->addWidget(labelc5Tab6);
//          coordinatesLayout->addWidget(textTab6Edit4);
//          coordinatesLayout->addWidget(labelc6Tab6);
//          coordinatesLayout->addWidget(textTab6Edit5);

//          QHBoxLayout *coordinatesLayout2 = new QHBoxLayout();
//          coordinatesLayout2->addWidget(labelc7Tab6);

//          coordinatesLayout2->addWidget(labelc8Tab6);
//          coordinatesLayout2->addWidget(textTab6Edit6);
//          coordinatesLayout2->addWidget(labelc9Tab6);
//          coordinatesLayout2->addWidget(textTab6Edit7);

//          QGroupBox *groupBox = new QGroupBox("Метрика");
//          QVBoxLayout *groupBoxLayout =new QVBoxLayout();
//          groupBoxLayout->addLayout(coordinatesLayout);
//           groupBoxLayout->addLayout(coordinatesLayout2);

//           groupBox->setLayout(groupBoxLayout);

//           QHBoxLayout *coordinatesLayoutS = new QHBoxLayout();
//           coordinatesLayoutS->addWidget(labelc10Tab6);
//           coordinatesLayoutS->addWidget(labelc11Tab6);
//           coordinatesLayoutS->addWidget(textTab6Edit8);
//           coordinatesLayoutS->addWidget(labelc12Tab6);
//           coordinatesLayoutS->addWidget(textTab6Edit9);

//           QHBoxLayout *coordinatesLayoutS2 = new QHBoxLayout();
//           coordinatesLayoutS2->addWidget(labelc13Tab6);

//           coordinatesLayoutS2->addWidget(labelc14Tab6);
//           coordinatesLayoutS2->addWidget(textTab6Edit10);
//           coordinatesLayoutS2->addWidget(labelc15Tab6);
//           coordinatesLayoutS2->addWidget(textTab6Edit11);

//           QGroupBox *groupBox2 = new QGroupBox("Семантика");
//           QVBoxLayout *groupBoxLayoutS =new QVBoxLayout();
//           groupBoxLayoutS->addLayout(coordinatesLayoutS);
//           groupBoxLayoutS->addLayout(coordinatesLayoutS2);
//           groupBox2->setLayout(groupBoxLayoutS);

//           if ( !vfvpmodel.txfDataLst.isEmpty() ) {

//            TXFDataWorker txfDataWorker( vfvpmodel.txfDataLst.at( i ) );
//            textTab6Edit1->setText( txfDataWorker.getKEY() );
//            textTab6Edit2->setText( txfDataWorker.getCOD() );
//            textTab6Edit3->setText( txfDataWorker.getCOD_TYPE() );
//            textTab6Edit4->setText( txfDataWorker.getMET().at( 0 ).first);
//            textTab6Edit5->setText( txfDataWorker.getMET().at( 0 ).second);
//            textTab6Edit6->setText( txfDataWorker.getMET().at( 1 ).first);
//            textTab6Edit7->setText( txfDataWorker.getMET().at( 1 ).second);
//            QString semKeyGui( txfDataWorker.getSEMList().at( 0 ) );
//            QString semValue = ( txfDataWorker.getSEMValue( semKeyGui ));
//            textTab6Edit8->setText("SEM 1-> " + semKeyGui);
//            textTab6Edit9->setText("SEM 1-> " + semValue);
//            QString semKey( txfDataWorker.getSEMList().at( 1 ) );
//            QString semValue1 = ( txfDataWorker.getSEMValue( semKey ));
//            textTab6Edit10->setText("SEM 2-> " + semKey );
//            textTab6Edit11->setText("SEM 2-> " + semValue1);
//            tab6Layout->addWidget(labelc1Tab6);
//            tab6Layout->addWidget(textTab6Edit1);
//            tab6Layout->addWidget(labelc2Tab6);
//            tab6Layout->addWidget(textTab6Edit2);
//            tab6Layout->addWidget(labelc3Tab6);
//            tab6Layout->addWidget(textTab6Edit3);
//            tab6Layout->addWidget(groupBox);
//            tab6Layout->addWidget(groupBox2);
//            tab6Layout->addStretch(1);
//      }
//                  }
//             }


//}vfvpmodel.txfDataLst
//    if (!vfvpmodel.txfDataLst.isEmpty()) {
//           //tabWidget->setTabVisible(tabIndex4, true);
//       // tabWidget->addTab(tab5, ("ВВТ [ vvtvfvp ]"));
//            tabWidget->insertTab(tabIndex5, tab6, "Картографические данные [ kdou ]");
//    }
//         if (vfvpmodel.txfDataLst.isEmpty()) {
//           //  tabWidget->setTabVisible(tabIndex4, false);
//           //  tabWidget->removeTab(4);
//             tabIndex5 = tabWidget->indexOf(tab6);
//             tabWidget->removeTab(tabIndex5);
//        //    delete tabWidget;
//         }
    // Проверяем, были ли уже созданы вкладки
//              for (const POSVFVP& posVfvp : vfvpmodel.posVfvpLst){

//                if (posVfvp.description == "pvfvp") {
//                    if (!vfvpmodel.posVfvpLst.isEmpty()) {
//                        tabWidget->addTab( tab2, "Положение воинского формирования [ pvfvp ]");
//                       //  tabIndex2 = 0;
//                                    }
//    }
//            }

//    if (!vfvpmodel.posVfvpLst.isEmpty()) {
//           //tabWidget->setTabVisible(tabIndex4, true);
//       // tabWidget->addTab(tab5, ("ВВТ [ vvtvfvp ]"));
//            //tabWidget->addTab(tabIndex4, tab5, "ВВТ [ vvtvfvp ]");
//             tabWidget->addTab( tab5, "Положение  формирования [ pvfvp ]");
//             tabIndex2 = 0;

    if (!tabsCreated) {
        // Создаем QTabWidget для вкладок внутри tab2
        innerTabWidget = new QTabWidget(tab2);
        tab2->setLayout(new QVBoxLayout(tab2));
        tab2->layout()->addWidget(innerTabWidget);

        // Создаем вкладки и добавляем их в innerTabWidget
        int positionCount = 0;
        for (const POSVFVP& posVfvp : vfvpmodel.posVfvpLst) {
            if (posVfvp.description == "pvfvp") {
                if (vfvpmodel.posVfvpLst.isEmpty()) {
                    tabWidget->removeTab(tabIndex2);
                   tabIndex2 = 0;
                }
                if (!vfvpmodel.posVfvpLst.isEmpty()) {
                    //указываем индекс, на котором нужно вставить вкладку tab2.
                    // tabIndex2 = tabWidget->addTab(tab2, "Положение ");

          //tabWidget->addTab( tab2, "Положение воинского формирования [ pvfvp ]");
            tabIndex2 = 0;
                    //вставить вкладку на нужную позицию
            tabWidget->insertTab(tabIndex2, tab2, "Положение воинского формирования [ pvfvp ]");
                   // tabWidget->insertTab(tabIndex2, tab2, "Положение ");
                      //  tabIndex2 = tabWidget->indexOf(tab2);
           // tabWidget->setCurrentIndex(0);
//            lastActiveTabIndex = tabWidget->currentIndex();
//            tabWidget->setCurrentIndex(lastActiveTabIndex);


                  // tabWidget->setCurrentIndex(0);
//                   lastActiveTabIndex = tabWidget->currentIndex();
//                   tabWidget->setCurrentIndex(lastActiveTabIndex);


                                   }
                QWidget* innerTab = new QWidget(innerTabWidget);
                QVBoxLayout* innerTabLayout = new QVBoxLayout(innerTab);

                QList<QPair<QString, QString>> labelDataList = {
                    {"Наименование блока", posVfvp.description},
                    {"Широта", posVfvp.latitude},
                    {"Долгота", posVfvp.longitude},
                    {"Высота", posVfvp.height},
                    {"Пояснение", posVfvp.OK}
                };

                QLabel* titleLabel = new QLabel(QString("Положение %1").arg(++positionCount), innerTab);
                innerTabLayout->addWidget(titleLabel);

                for (const auto& labelData : labelDataList) {
                    QLabel* label = new QLabel(labelData.first, innerTab);
                    QLineEdit* lineEdit = new QLineEdit(innerTab);
                    lineEdit->setObjectName(QString("TextEdit%1Tab2_%2").arg(labelData.first).arg(positionCount));
                    lineEdit->setReadOnly(true);
                    lineEdit->setText(labelData.second);

                    innerTabLayout->addWidget(label);
                    innerTabLayout->addWidget(lineEdit);
                }

                innerTabLayout->addStretch(1);
                innerTab->setLayout(innerTabLayout);

                // Добавляем внутреннюю вкладку innerTab в innerTabWidget
                innerTabWidget->addTab(innerTab, QString("Положение %1").arg(positionCount));
            }
        }

        // Устанавливаем флаг, что вкладки были созданы
        tabsCreated = true;
    }

    else {

        // Удаляем существующие вкладки
        while (innerTabWidget->count() > 0) {
            QWidget* tab = innerTabWidget->widget(0);
            innerTabWidget->removeTab(0);
            delete tab;
//            for (const POSVFVP& posVfvp : vfvpmodel.posVfvpLst){

//            if (posVfvp.description == "pvfvp") {
////                if (vfvpmodel.posVfvpLst.isEmpty()) {
          //  tabIndex2 = 0;
            tabIndex2 = tabWidget->indexOf(tab2);
            tabWidget->removeTab(tabIndex2);
            tabIndex2 = 0;
           // tabWidget->setCurrentIndex(0);
//            lastActiveTabIndex = tabWidget->currentIndex();
//            tabWidget->setCurrentIndex(lastActiveTabIndex);

//               }
//}
////        }
}
        // Удаляем существующую вкладку Положение
         //  tabWidget->removeTab(tabIndex2);
           //delete tab2;

//           // Создаем новую вкладку Положение
//           tab2 = new QWidget(tabWidget);
//           tabWidget->insertTab(tabIndex2, tab2, "Положение ");

//        if (!vfvpmodel.posVfvpLst.isEmpty()) {
//               //tabWidget->setTabVisible(tabIndex4, true);
//           // tabWidget->addTab(tab5, ("ВВТ [ vvtvfvp ]"));
//                //tabWidget->addTab(tabIndex4, tab5, "ВВТ [ vvtvfvp ]");
//                 tabWidget->addTab( tab5, "Положение воинск формирования [ pvfvp ]");
//                 tabIndex2 = 0;
//        }
        // Создаем новые вкладки и добавляем их в innerTabWidget (код здесь повторяет предыдущий блок)
        int positionCount = 0;
        for (const POSVFVP& posVfvp : vfvpmodel.posVfvpLst) {
            if (posVfvp.description == "pvfvp") {
                if (vfvpmodel.posVfvpLst.isEmpty()) {
                    tabIndex2 = tabWidget->indexOf(tab2);
                    tabWidget->removeTab(tabIndex2);
                   tabIndex2 = 0;
                  // tabWidget->setCurrentIndex(0);
//                   lastActiveTabIndex = tabWidget->currentIndex();
//                   tabWidget->setCurrentIndex(lastActiveTabIndex);
                                   }
                if (!vfvpmodel.posVfvpLst.isEmpty()) {
                     //tabIndex2 = tabWidget->addTab(tab2, "Положение ");


                  //  tabWidget->addTab( tab2, "Положение воинского формирования [ pvfvp ]");
                 tabIndex2 = 0;
                   tabWidget->insertTab(tabIndex2, tab2, "Положение воинского формирования [ pvfvp ]");
                   // tabWidget->insertTab(tabIndex2, tab2, "Положение ");
                       // tabIndex2 = tabWidget->indexOf(tab2);
                 //  tabWidget->setCurrentIndex(0);
//                   lastActiveTabIndex = tabWidget->currentIndex();
//                   tabWidget->setCurrentIndex(lastActiveTabIndex);

                }

                QWidget* innerTab = new QWidget(innerTabWidget);
                QVBoxLayout* innerTabLayout = new QVBoxLayout(innerTab);

                QList<QPair<QString, QString>> labelDataList = {
                    {"Наименование блока", posVfvp.description},
                    {"Широта", posVfvp.latitude},
                    {"Долгота", posVfvp.longitude},
                    {"Высота", posVfvp.height},
                    {"Пояснение", posVfvp.OK}
                };

                QLabel* titleLabel = new QLabel(QString("Положение %1").arg(++positionCount), innerTab);
                innerTabLayout->addWidget(titleLabel);

                for (const auto& labelData : labelDataList) {
                    QLabel* label = new QLabel(labelData.first, innerTab);
                    QLineEdit* lineEdit = new QLineEdit(innerTab);
                    lineEdit->setObjectName(QString("TextEdit%1Tab2_%2").arg(labelData.first).arg(positionCount));
                    lineEdit->setReadOnly(true);
                    lineEdit->setText(labelData.second);

                    innerTabLayout->addWidget(label);
                    innerTabLayout->addWidget(lineEdit);
                }

                innerTabLayout->addStretch(1);
                innerTab->setLayout(innerTabLayout);

                // Добавляем внутреннюю вкладку innerTab в innerTabWidget
                innerTabWidget->addTab(innerTab, QString("Положение %1").arg(positionCount));
            }
        }
        //tabWidget->setCurrentIndex(lastActiveTabIndex);
        //int activeTabIndex = activeTabMap.value(treeView->currentIndex());
                    tabWidget->setCurrentIndex(activeTabIndex);
    }
//    for ( POSVFVP& posVfvp : vfvpmodel.posVfvpLst)
//        if (posVfvp.description == "ndvfvp") {
//    if (!vfvpmodel.posVfvpLst.isEmpty()) {

//             tabWidget->addTab( tab5, "Направление действий ВФ [ ndvfvp ]");
//             tabIndex4 = 2;
//int lastActiveTabIndex1 = tabWidget->currentIndex();
    // Проверяем, были ли уже созданы вкладки
    if (!tabsCreatedTab3) {
        // Создаем QTabWidget для вкладок внутри tab3
        innerTab3Widget = new QTabWidget(tab3);
        tab3->setLayout(new QVBoxLayout(tab3));
        tab3->layout()->addWidget(innerTab3Widget);

        // Создаем вкладки и добавляем их в innerTabWidget
        int positionCount = 0;
        for (const POSVFVP& posVfvp : vfvpmodel.posVfvpLst) {
            if (posVfvp.description == "ndvfvp") {
                if (!vfvpmodel.posVfvpLst.isEmpty()) {
                    //tabIndex3 = tabWidget->addTab(tab3, "Направление ");
                    tabIndex3 = 1;
                   /// tabWidget->addTab(tab3, "Направление действий воинского формирования [ ndvfvp ]");
                    tabWidget->insertTab(tabIndex3, tab3, "Направление действий воинского формирования [ ndvfvp ]");

                 //  tabWidget->setCurrentIndex(0);
//                   lastActiveTabIndex = tabWidget->currentIndex();
//                   tabWidget->setCurrentIndex(lastActiveTabIndex);
                   // tabWidget->insertTab(tabIndex3, tab3, "Направление ");
                      // tabIndex3 = tabWidget->indexOf(tab3);
             }
                if (vfvpmodel.posVfvpLst.isEmpty()) {
                    tabIndex3 = tabWidget->indexOf(tab3);
                    tabWidget->removeTab(tabIndex3);
                    tabIndex3 = 1;
                   // tabWidget->setCurrentIndex(0);
//                    lastActiveTabIndex = tabWidget->currentIndex();
//                    tabWidget->setCurrentIndex(lastActiveTabIndex);

                                   }
                QWidget* innerTab3 = new QWidget(innerTab3Widget);
                QVBoxLayout* innerTab3Layout = new QVBoxLayout(innerTab3);

                QList<QPair<QString, QString>> labelDataListTab3 = {
                    {"Наименование блока", posVfvp.description},
                    {"Широта", posVfvp.latitude},
                    {"Долгота", posVfvp.longitude},
                    {"Высота", posVfvp.height},
                    {"Пояснение", posVfvp.OK}
                };

                QLabel* titleLabelTab3 = new QLabel(QString("Направление %1").arg(++positionCount), innerTab3);
                innerTab3Layout->addWidget(titleLabelTab3);

                for (const auto& labelData : labelDataListTab3) {
                    QLabel* label = new QLabel(labelData.first, innerTab3);
                    QLineEdit* lineEditTab3 = new QLineEdit(innerTab3);
                    lineEditTab3->setObjectName(QString("TextEdit%1Tab3_%2").arg(labelData.first).arg(positionCount));
                    lineEditTab3->setReadOnly(true);
                    lineEditTab3->setText(labelData.second);

                    innerTab3Layout->addWidget(label);
                    innerTab3Layout->addWidget(lineEditTab3);
                }

                innerTab3Layout->addStretch(1);
                innerTab3->setLayout(innerTab3Layout);

                // Добавляем внутреннюю вкладку innerTab в innerTabWidget
                innerTab3Widget->addTab(innerTab3, QString("Направление %1").arg(positionCount));
            }
        }

        // Устанавливаем флаг, что вкладки были созданы
        tabsCreatedTab3 = true;
    }
    else {
               // Удаляем существующие вкладки
        while (innerTab3Widget->count() > 0) {
            QWidget* tabTab3 = innerTab3Widget->widget(0);
            innerTab3Widget->removeTab(0);
            delete tabTab3;
//            for (const POSVFVP& posVfvp : vfvpmodel.posVfvpLst){

//            if (posVfvp.description == "ndvfvp") {
//              if (vfvpmodel.posVfvpLst.isEmpty()) {

//            tabIndex3 = tabWidget->indexOf(tab2);
            tabIndex3 = tabWidget->indexOf(tab3);
            tabWidget->removeTab(tabIndex3);
            tabIndex3 = 1;
           // tabWidget->setCurrentIndex(0);
//            lastActiveTabIndex = tabWidget->currentIndex();
//            tabWidget->setCurrentIndex(lastActiveTabIndex);
//                }
//}
//       }
                      //  tabIndex3 = tabWidget->indexOf(tab3);
//                        tabWidget->removeTab(tabIndex3);
//                        tabIndex3 = 1;

        }
//        if (!vfvpmodel.posVfvpLst.isEmpty()) {
//               //tabWidget->setTabVisible(tabIndex4, true);

//                 tabWidget->addTab( tab5, "Направление действий ВФ [ ndvfvp ]");
//                 tabIndex4 = 2;
//        }
        // Создаем новые вкладки и добавляем их в innerTabWidget (код здесь повторяет предыдущий блок)
        int positionCount = 0;
        for (const POSVFVP& posVfvp : vfvpmodel.posVfvpLst) {
            if (posVfvp.description == "ndvfvp") {
               if (!vfvpmodel.posVfvpLst.isEmpty()) {
                     tabIndex3 = 1;
 //tabIndex3 = tabWidget->addTab(tab3, "Направление ");
                   ///  tabWidget->addTab(tab3, "Направление действий воинского формирования [ ndvfvp ]");
                     tabWidget->insertTab(tabIndex3, tab3, "Направление действий воинского формирования [ ndvfvp ]");
                  // tabIndex3 = 1;
                 //  tabWidget->setCurrentIndex(0);
//                   lastActiveTabIndex = tabWidget->currentIndex();
//                   tabWidget->setCurrentIndex(lastActiveTabIndex);
                  // tabWidget->insertTab(tabIndex3, tab3, "Направление ");
                     // tabIndex3 = tabWidget->indexOf(tab3);
                                  }
                   if (vfvpmodel.posVfvpLst.isEmpty()) {
                       tabIndex3 = tabWidget->indexOf(tab3);
                       tabWidget->removeTab(tabIndex3);
                       tabIndex3 = 1;
                     //  tabWidget->setCurrentIndex(0);
//                       lastActiveTabIndex = tabWidget->currentIndex();
//                       tabWidget->setCurrentIndex(lastActiveTabIndex);

                                      }

                QWidget* innerTab3 = new QWidget(innerTab3Widget);
                QVBoxLayout* innerTab3Layout = new QVBoxLayout(innerTab3);

                QList<QPair<QString, QString>> labelDataListTab3 = {
                    {"Наименование блока", posVfvp.description},
                    {"Широта", posVfvp.latitude},
                    {"Долгота", posVfvp.longitude},
                    {"Высота", posVfvp.height},
                    {"Пояснение", posVfvp.OK}
                };

                QLabel* titleLabel = new QLabel(QString("Направление %1").arg(++positionCount), innerTab3);
                innerTab3Layout->addWidget(titleLabel);

                for (const auto& labelDataTab3 : labelDataListTab3) {
                    QLabel* label = new QLabel(labelDataTab3.first, innerTab3);
                    QLineEdit* lineEditTab3 = new QLineEdit(innerTab3);
                    lineEditTab3->setObjectName(QString("TextEdit%1Tab3_%2").arg(labelDataTab3.first).arg(positionCount));
                    lineEditTab3->setReadOnly(true);
                    lineEditTab3->setText(labelDataTab3.second);

                    innerTab3Layout->addWidget(label);
                    innerTab3Layout->addWidget(lineEditTab3);
                }

                innerTab3Layout->addStretch(1);
                innerTab3->setLayout(innerTab3Layout);

                // Добавляем внутреннюю вкладку innerTab в innerTabWidget
                innerTab3Widget->addTab(innerTab3, QString("Направление %1").arg(positionCount));
            }
        }
//tabWidget->setCurrentIndex(lastActiveTabIndex1);
//int activeTabIndex = activeTabMap.value(treeView->currentIndex());
            tabWidget->setCurrentIndex(activeTabIndex);
    }
//int lastActiveTabIndex2 = tabWidget->currentIndex();
//    if (vfvpmodel.vvtVfsvLst.isEmpty()) {
//      //  tabWidget->setTabVisible(tabIndex4, false);
//      //  tabWidget->removeTab(4);
//        tabIndex4 = tabWidget->indexOf(tab5);
//        tabWidget->removeTab(tabIndex4);
//        tabIndex4 = 2;
//    }

    // Создание layout для вкладки tab4
    QVBoxLayout* tab4Layout = new QVBoxLayout(tab4);
qDebug() << "НАЧАЛО Таб4 " << tabsCreatedTab4;
    if (!tabsCreatedTab4) {
         qDebug() << "!tabsCreatedTab4 Таб4 " << tabsCreatedTab4;
        if (!vfvpmodel.lsVfvpLst.isEmpty()) {
            tabIndex4 = 2;
            tabWidget->insertTab(tabIndex4, tab4, "Ли[ lsvfvp ]");
        }
        if (vfvpmodel.lsVfvpLst.isEmpty()) {
            tabIndex4 = tabWidget->indexOf(tab4);
            tabWidget->removeTab(tabIndex4);
            tabIndex4 = 2;
        }

        for (const LSVFVP& lsVfvp : vfvpmodel.lsVfvpLst) {
            QList<QPair<QString, QString>> labelDataList = {
                {"Колличество ", lsVfvp.lskolshtat},
                {"Колличество в ", lsVfvp.lskolnal},
                {"омпле", lsVfvp.lsukompl}
            };

            for (const auto& labelData : labelDataList) {
                QLabel* label = new QLabel(labelData.first, tab4);
                QLineEdit* lineEdit = new QLineEdit(tab4);
                lineEdit->setObjectName(QString("TextEdit%1Tab4").arg(labelData.first));
                lineEdit->setReadOnly(true);
                lineEdit->setText(labelData.second);

                tab4Layout->addWidget(label);
                tab4Layout->addWidget(lineEdit);
            }
        }

        // Добавление элемента растяжения
        tab4Layout->addStretch(1);
        tab4->setLayout(tab4Layout);

        // Устанавливаем флаг, что вкладка была создана
        tabsCreatedTab4 = true;
    }

    else {
         qDebug() << "НАЧАЛО Таб4 перед else " << tabsCreatedTab4;
        tabIndex8 = tabWidget->indexOf(tab4);

        // Удаление текущего layout из tab4, если он существует
        if (tab4->layout()) {
            QLayout* currentLayout = tab4->layout();
            QLayoutItem* item;
            while ((item = currentLayout->takeAt(0)) != nullptr) {
                delete item->widget();
                delete item;
            }
            delete currentLayout;
        }

        tabIndex4 = tabWidget->indexOf(tab4);

        if (!vfvpmodel.lsVfvpLst.isEmpty()) {
            tabWidget->addTab(tab4, ("Ли [ lsvfvp ]"));
            tabIndex4 = tabWidget->indexOf(tab4);

            for (const LSVFVP& lsVfvp : vfvpmodel.lsVfvpLst) {
                QVBoxLayout* newLayout = new QVBoxLayout(tab4);

                QList<QPair<QString, QString>> labelDataList = {
                    {"Колличество ", lsVfvp.lskolshtat},
                    {"Колличество в ", lsVfvp.lskolnal},
                    {"омпле", lsVfvp.lsukompl}
                };

                for (const auto& labelData : labelDataList) {
                    QLabel* label = new QLabel(labelData.first, tab4);
                    QLineEdit* lineEdit = new QLineEdit(tab4);
                    lineEdit->setObjectName(QString("TextEdit%1Tab4").arg(labelData.first));
                    lineEdit->setReadOnly(true);
                    lineEdit->setText(labelData.second);

                    newLayout->addWidget(label);
                    newLayout->addWidget(lineEdit);
                }

                newLayout->addStretch(1);
                tab4->setLayout(newLayout);
            }
        }
        else {
            tabIndex4 = tabWidget->indexOf(tab4);
            tabWidget->removeTab(tabIndex4);
            tabIndex4 = 2;
        }
        tabWidget->setCurrentIndex(lastActiveTabIndex);
    }



qDebug() << "КОНЕЦ Таб4 " << tabsCreatedTab4;




   if (!tabsCreatedTab5) {
       if (!vfvpmodel.vvtVfsvLst.isEmpty()) {
              //tabWidget->setTabVisible(tabIndex4, true);
          // tabWidget->addTab(tab5, ("ВВТ [ vvtvfvp ]"));
               //tabWidget->addTab(tabIndex4, tab5, "ВВТ [ vvtvfvp ]");

   //             tabWidget->addTab( tab5, "ВВТ [ vvtvfvp ]");
                tabIndex5 = 3;
           tabWidget->insertTab(tabIndex5, tab5, "ВВТ [ vvtvfvp ]");
          // tabWidget->addTab( tab5, "ВВТ [ vvtvfvp ]");

       //}

            //    delete tabWidget;
            }

       // Создаем QTabWidget для вкладок внутри tab5
        innerTab5Widget = new QTabWidget(tab5);
       tab5->setLayout(new QGridLayout(tab5));
       tab5->layout()->addWidget(innerTab5Widget);

       // Создаем вкладки и добавляем их в innerTabWidget
       for (int i = 0; i < vfvpmodel.vvtVfsvLst.size(); i++) {
           VVTVFVP vvtVfvp = vfvpmodel.vvtVfsvLst.at(i);

           QWidget* innerTab5 = new QWidget(innerTab5Widget);
           QVBoxLayout* innerTab5Layout = new QVBoxLayout(innerTab5);

           QList<QPair<QString, QString>> labelDataListTab5 = {
               {"Наименование блока", vvtVfvp.description},
               {"Код по классификатору", vvtVfvp.kkoovt_kod},
               {"Количество по штату", vvtVfvp.kolshtat},
               {"Количество в наличии", vvtVfvp.kolnal},
               {"Комплектность", vvtVfvp.ukompl}
           };

           for (const auto& labelDataTab5 : labelDataListTab5) {
               QLabel* labelTab5 = new QLabel(labelDataTab5.first, innerTab5);
               QLineEdit* lineEditTab5 = new QLineEdit(innerTab5);
               lineEditTab5->setObjectName(QString("TextEdit%1Tab5_%2").arg(labelDataTab5.first).arg(i));
               lineEditTab5->setReadOnly(true);
               lineEditTab5->setText(labelDataTab5.second);

               innerTab5Layout->addWidget(labelTab5);
               innerTab5Layout->addWidget(lineEditTab5);
           }

           innerTab5Layout->addStretch(1);
           innerTab5->setLayout(innerTab5Layout);

           // Добавляем внутреннюю вкладку innerTab в innerTabWidget
           innerTab5Widget->addTab(innerTab5, vvtVfvp.kkoovt_kod);
       }

       // Устанавливаем флаг, что вкладки были созданы
       tabsCreatedTab5 = true;

   }

   else {
       // Удаляем существующие вкладки
       while (innerTab5Widget->count() > 0) {
           QWidget* tabTab5 = innerTab5Widget->widget(0);
           innerTab5Widget->removeTab(0);
           delete tabTab5;
           if (vfvpmodel.vvtVfsvLst.isEmpty()) {
              // tabWidget->setTabVisible(tabIndex4, false);
              // tabWidget->removeTab(4);
               tabIndex5 = tabWidget->indexOf(tab5);
               tabWidget->removeTab(tabIndex5);
              tabIndex5 = 3;
              //delete tabWidget;
           }

       }
//       if (!vfvpmodel.vvtVfsvLst.isEmpty()) {
//              //tabWidget->setTabVisible(tabIndex4, true);
//          // tabWidget->addTab(tab5, ("ВВТ [ vvtvfvp ]"));
//               tabWidget->insertTab(tabIndex4, tab5, "ВВТ [ vvtvfvp ]");
//                tabIndex4 = 2;
//       }
       if (!vfvpmodel.vvtVfsvLst.isEmpty()) {
              //tabWidget->setTabVisible(tabIndex4, true);
          // tabWidget->addTab(tab5, ("ВВТ [ vvtvfvp ]"));
               //tabWidget->addTab(tabIndex4, tab5, "ВВТ [ vvtvfvp ]");
   //             tabWidget->addTab( tab5, "ВВТ [ vvtvfvp ]");
                tabIndex5 = 3;
           tabWidget->insertTab(tabIndex4, tab5, "ВВТ [ vvtvfvp ]");


       // Создаем новые вкладки и добавляем их в innerTabWidget (код здесь повторяет предыдущий блок)
       for (int i = 0; i < vfvpmodel.vvtVfsvLst.size(); i++) {
           VVTVFVP vvtVfvp = vfvpmodel.vvtVfsvLst.at(i);

           QWidget* innerTab5 = new QWidget(innerTab5Widget);
           QVBoxLayout* innerTab5Layout = new QVBoxLayout(innerTab5);

           QList<QPair<QString, QString>> labelDataListTab5 = {
               {"Наименование блока", vvtVfvp.description},
               {"Код по классификатору", vvtVfvp.kkoovt_kod},
               {"Количество по штату", vvtVfvp.kolshtat},
               {"Количество в наличии", vvtVfvp.kolnal},
               {"Комплектность", vvtVfvp.ukompl}
           };

           for (const auto& labelDataTab5 : labelDataListTab5) {
               QLabel* labelTab5 = new QLabel(labelDataTab5.first, innerTab5);
               QLineEdit* lineEditTab5 = new QLineEdit(innerTab5);
               lineEditTab5->setObjectName(QString("TextEdit%1Tab5_%2").arg(labelDataTab5.first).arg(i));
               lineEditTab5->setReadOnly(true);
               lineEditTab5->setText(labelDataTab5.second);

               innerTab5Layout->addWidget(labelTab5);
               innerTab5Layout->addWidget(lineEditTab5);
           }

           innerTab5Layout->addStretch(1);
           innerTab5->setLayout(innerTab5Layout);

           // Добавляем внутреннюю вкладку innerTab в innerTabWidget
           innerTab5Widget->addTab(innerTab5, vvtVfvp.kkoovt_kod);
       }
       }
       // tabWidget->setCurrentIndex(lastActiveTabIndex2);
        //int activeTabIndex = activeTabMap.value(treeView->currentIndex());
                    tabWidget->setCurrentIndex(activeTabIndex);
   }

//int lastActiveTabIndex3 = tabWidget->currentIndex();
    if (!vfvpmodel.txfDataLst.isEmpty()) {
    //tabWidget->addTab(tabIndex5, tab6, "Картографические данные [ kdou ]");
   //  tabWidget->addTab( tab6, "Картографические данные [ kdou ]");
    tabIndex8 = 4;
    tabWidget->insertTab(tabIndex5, tab6, "Картографические данные [ kdou ]");
    }
    if (!tabsCreatedTab6) {
        innerTab6Widget = new QTabWidget(tab6);
        tab6->setLayout(new QVBoxLayout(tab6));
        tab6->layout()->addWidget(innerTab6Widget);

        createInnerTab6Widget();

        tabsCreatedTab6 = true;
    }
    /// освобождаем память
    else {
        while (innerTab6Widget->count() > 0) {
            QWidget* tabTab6 = innerTab6Widget->widget(0);
            innerTab6Widget->removeTab(0);
            delete tabTab6;
            if (vfvpmodel.txfDataLst.isEmpty()) {
            tabIndex8 = tabWidget->indexOf(tab6);
            tabWidget->removeTab(tabIndex8);
            tabIndex8 = 4;
            }
        }

        createInnerTab6Widget();
       // tabWidget->setCurrentIndex(lastActiveTabIndex3);
    //    int activeTabIndex = activeTabMap.value(treeView->currentIndex());
                    tabWidget->setCurrentIndex(activeTabIndex);
    }
    //        if (!vfvpModel.lsVfvpVec.isEmpty()) {
    //            tabIndex3 = 3;
    //            tabWidget->insertTab(tabIndex3, tab4, "Личный состав [ lsvfvp ]");
    //        }

    ////////////////////////////////
    ///        QLayoutItem* item;

//    if (!tabsCreatedTab4) {

////                if (vfvpmodel.lsVfvpLst.isEmpty()) {
////                tabIndex8 = tabWidget->indexOf(tab4);
////                tabWidget->removeTab(tabIndex8);
////                tabIndex8 = 4;
////                }
//                for (const LSVFVP& lsVfvp : vfvpmodel.lsVfvpLst) {
//// QWidget* tab4 = new QWidget(tabWidget);
//                    if (!vfvpmodel.lsVfvpLst.isEmpty()) {
//                        tabIndex8 = 4;
//                        tabWidget->insertTab(tabIndex8, tab4, "Личный состав [ lsvfvp ]");
//                    }
//                    tab4Layout = new QVBoxLayout(tab4);

//    QList<QPair<QString, QString>> labelDataListls = {
//            {"Колличество по штату личного состава", lsVfvp.lskolshtat},
//             {"Колличество в наличии личного состава", lsVfvp.lskolnal},
//              {"Укомплектованность личного состава", lsVfvp.lsukompl}
//    };
//                    for (const auto& labelDatals : labelDataListls) {
//                        QLabel* label = new QLabel(labelDatals.first, tab4);
//                        QLineEdit* lineEditls = new QLineEdit(tab4);
//                        lineEditls->setObjectName(QString("TextEdit%1Tab4").arg(labelDatals.first));
//                        lineEditls->setReadOnly(true);
//                        lineEditls->setText(labelDatals.second);

//                        tab4Layout->addWidget(label);
//                        tab4Layout->addWidget(lineEditls);
//                    }
//                    // Добавление QLineEdit и QLabel в соответствующие контейнеры
//                                    lineEditList.append(lineEdit);
//                                    labelList.append(label);
//                    tab4Layout->addStretch(1);
//                    tab4->setLayout(tab4Layout);

//                    // Устанавливаем флаг, что вкладки были созданы
//                    tabsCreatedTab4 = true;
//                }
//    }

//   else {
//        // Очистка полей QLineEdit и QLabel
//            for (QLineEdit* lineEditls : lineEditList) {
//                delete lineEditls;
//            }
//            lineEditList.clear();

//            for (QLabel* label : labelList) {
//                delete label;
//            }
//            labelList.clear();


////        QLayoutItem* item;
////         tabIndex8 = tabWidget->indexOf(tab4);
////        while ((item = tab4Layout->takeAt(0)) != nullptr){

////            delete item->widget();
////            delete item;
////            tabIndex8 = 4;
//            //tab4Layout->addStretch(1);
////        QLayout* currentLayout = tab4->layout();
////            delete currentLayout;

////            // Удаление элементов из предыдущего layout
////            QLayoutItem* item;
////            while ((item = currentLayout->takeAt(0)) != nullptr){
////                delete item->widget();
////                delete item;
//        }

////if (vfvpmodel.lsVfvpLst.isEmpty()) {
////            tabIndex8 = tabWidget->indexOf(tab4);
////            tabWidget->removeTab(tabIndex8);
////            tabIndex8 = 4;
////}


//            for (const LSVFVP& lsVfvp : vfvpmodel.lsVfvpLst) {
//               // QWidget* tab4 = new QWidget(tabWidget);
//                if (!vfvpmodel.lsVfvpLst.isEmpty()) {
//                    tabWidget->addTab(tab4, ("Личный состав [ lsvfvp ]"));
//                    tabIndex8 = 4;
//                    tabWidget->insertTab(tabIndex8, tab4, "Личный состав [ lsvfvp ]");
//                }
//               tab4Layout = new QVBoxLayout(tab4);
//                // QVBoxLayout* newLayout = new QVBoxLayout(tab4);

//                QList<QPair<QString, QString>> labelDataListls = {
//                        {"Колличество по штату личного состава", lsVfvp.lskolshtat},
//                         {"Колличество в наличии личного состава", lsVfvp.lskolnal},
//                          {"Укомплектованность личного состава", lsVfvp.lsukompl}
//                };
//                                for (const auto& labelDatals : labelDataListls) {
//                                    QLabel* label = new QLabel(labelDatals.first, tab4);
//                                    QLineEdit* lineEditls = new QLineEdit(tab4);
//                                    lineEditls->setObjectName(QString("TextEdit%1Tab4").arg(labelDatals.first));
//                                    lineEditls->setReadOnly(true);
//                                    lineEditls->setText(labelDatals.second);

//                                    tab4Layout->addWidget(label);
//                                    tab4Layout->addWidget(lineEditls);
//                                }

//                tab4Layout->addStretch(1);
//               tab4->setLayout(tab4Layout);
//            }
////                                    newLayout->addWidget(label);
////                                               newLayout->addWidget(lineEditls);
////                                           }

////                                           newLayout->addStretch(1);
////                                           tab4->setLayout(newLayout);
////                                       }


//                tabWidget->setCurrentIndex(lastActiveTabIndex);
//            }
//////////////
//    // Создание полей QLineEdit и QLabel
//    QList<QLineEdit*> lineEditList;
//    QList<QLabel*> labelList;

//    // Создание layout для вкладки tab4
//    QVBoxLayout* tab4Layout = new QVBoxLayout(tab4);

//    if (!tabsCreatedTab4) {
//        if (!vfvpmodel.lsVfvpLst.isEmpty()) {
//            tabIndex8 = 2;
//            tabWidget->insertTab(tabIndex8, tab4, "Ли[ lsvfvp ]");
//        }
//        if (vfvpmodel.lsVfvpLst.isEmpty()) {
//            tabIndex8 = tabWidget->indexOf(tab4);
//            tabWidget->removeTab(tabIndex8);
//            tabIndex8 = 2;
//        }

//        for (const LSVFVP& lsVfvp : vfvpmodel.lsVfvpLst) {
//            QList<QPair<QString, QString>> labelDataList = {
//                {"Колличество ", lsVfvp.lskolshtat},
//                {"Колличество в ", lsVfvp.lskolnal},
//                {"омпле", lsVfvp.lsukompl}
//            };

//            for (const auto& labelData : labelDataList) {
//                QLabel* label = new QLabel(labelData.first, tab4);
//                QLineEdit* lineEdit = new QLineEdit(tab4);
//                lineEdit->setObjectName(QString("TextEdit%1Tab4").arg(labelData.first));
//                lineEdit->setReadOnly(true);
//                lineEdit->setText(labelData.second);

//                tab4Layout->addWidget(label);
//                tab4Layout->addWidget(lineEdit);

//                // Добавление QLineEdit и QLabel в соответствующие контейнеры
//                lineEditList.append(lineEdit);
//                labelList.append(label);
//            }
//        }

//        // Добавление элемента растяжения
//        tab4Layout->addStretch(1);
//        tab4->setLayout(tab4Layout);

//        // Устанавливаем флаг, что вкладка была создана
//        tabsCreatedTab4 = true;
//    }
//    else {
//        // Удаление текущего layout из tab4
//        QLayout* currentLayout = tab4->layout();
//        if (currentLayout) {
//            delete currentLayout;
//        }

//        // Удаление полей QLineEdit и QLabel
//        for (QLineEdit* lineEdit : lineEditList) {
//            delete lineEdit;
//        }
//        lineEditList.clear();

//        for (QLabel* label : labelList) {
//            delete label;
//        }
//        labelList.clear();

//        tabIndex8 = tabWidget->indexOf(tab4);

//        QLayoutItem* item;
//        while ((item = tab4Layout->takeAt(0)) != nullptr) {
//            delete item->widget();
//            delete item;
//        }

//        if (!vfvpmodel.lsVfvpLst.isEmpty()) {
//            tabWidget->addTab(tab4, "Ли [ lsvfvp ]");
//            tabIndex8 = tabWidget->indexOf(tab4);

//            for (const LSVFVP& lsVfvp : vfvpmodel.lsVfvpLst) {
//                QVBoxLayout* newLayout = new QVBoxLayout(tab4);

//                QList<QPair<QString, QString>> labelDataList = {
//                    {"Колличество ", lsVfvp.lskolshtat},
//                    {"Колличество в ", lsVfvp.lskolnal},
//                    {"омпле", lsVfvp.lsukompl}
//                };

//                for (const auto& labelData : labelDataList) {
//                    QLabel* label = new QLabel(labelData.first, tab4);
//                    QLineEdit* lineEdit = new QLineEdit(tab4);
//                    lineEdit->setObjectName(QString("TextEdit%1Tab4").arg(labelData.first));
//                    lineEdit->setReadOnly(true);
//                    lineEdit->setText(labelData.second);

//                    newLayout->addWidget(label);
//                    newLayout->addWidget(lineEdit);

//                    // Добавление QLineEdit и QLabel в соответствующие контейнеры
//                    lineEditList.append(lineEdit);
//                    labelList.append(label);
//                }

//                newLayout->addStretch(1);
//                tab4->setLayout(newLayout);
//            }
//        }
//        else {
//            tabWidget->removeTab(tabIndex8);
//        }
//    }

//    tabWidget->setCurrentIndex(lastActiveTabIndex);

    ////Работает
    // Создание layout для вкладки tab4
//    QVBoxLayout* tab4Layout = new QVBoxLayout(tab4);

//    if (!tabsCreatedTab4) {
//        if (!vfvpmodel.lsVfvpLst.isEmpty()) {
//            tabIndex8 = 4;
//            tabWidget->insertTab(tabIndex8, tab4, "Ли[ lsvfvp ]");
//        }
//        if (vfvpmodel.lsVfvpLst.isEmpty()) {
//            tabIndex8 = tabWidget->indexOf(tab4);
//            tabWidget->removeTab(tabIndex8);
//            tabIndex8 = 4;
//        }

//        for (const LSVFVP& lsVfvp : vfvpmodel.lsVfvpLst) {
//            QList<QPair<QString, QString>> labelDataList = {
//                {"Колличество ", lsVfvp.lskolshtat},
//                {"Колличество в ", lsVfvp.lskolnal},
//                {"омпле", lsVfvp.lsukompl}
//            };

//            for (const auto& labelData : labelDataList) {
//                QLabel* label = new QLabel(labelData.first, tab4);
//                QLineEdit* lineEdit = new QLineEdit(tab4);
//                lineEdit->setObjectName(QString("TextEdit%1Tab4").arg(labelData.first));
//                lineEdit->setReadOnly(true);
//                lineEdit->setText(labelData.second);

//                tab4Layout->addWidget(label);
//                tab4Layout->addWidget(lineEdit);
//            }
//        }

//        // Добавление элемента растяжения
//        tab4Layout->addStretch(1);
//        tab4->setLayout(tab4Layout);

//        // Устанавливаем флаг, что вкладка была создана
//        tabsCreatedTab4 = true;
//    }
//    else {
//        // Удаление текущего layout из tab4
//        QLayout* currentLayout = tab4->layout();
//        if (currentLayout) {
//            // Удаление виджетов из layout
//            QLayoutItem* item;
//            while ((item = currentLayout->takeAt(0)) != nullptr) {
//                QWidget* widget = item->widget();
//                delete item;
//                delete widget;
//            }
//            delete currentLayout;
//        }

//        tabIndex8 = tabWidget->indexOf(tab4);

//        if (!vfvpmodel.lsVfvpLst.isEmpty()) {
//            tabWidget->addTab(tab4, "Ли [ lsvfvp ]");
//            tabIndex8 = tabWidget->indexOf(tab4);

//            for (const LSVFVP& lsVfvp : vfvpmodel.lsVfvpLst) {
//                QVBoxLayout* newLayout = new QVBoxLayout(tab4);

//                QList<QPair<QString, QString>> labelDataList = {
//                    {"Колличество ", lsVfvp.lskolshtat},
//                    {"Колличество в ", lsVfvp.lskolnal},
//                    {"омпле", lsVfvp.lsukompl}
//                };

//                for (const auto& labelData : labelDataList) {
//                    QLabel* label = new QLabel(labelData.first, tab4);
//                    QLineEdit* lineEdit = new QLineEdit(tab4);
//                    lineEdit->setObjectName(QString("TextEdit%1Tab4").arg(labelData.first));
//                    lineEdit->setReadOnly(true);
//                    lineEdit->setText(labelData.second);

//                    newLayout->addWidget(label);
//                    newLayout->addWidget(lineEdit);
//                }

//                // Добавление элемента растяжения
//                newLayout->addStretch(1);
//                tab4->setLayout(newLayout);
//            }
//        }
//        else {
//            tabWidget->removeTab(tabIndex8);
//        }
//    }

//    tabWidget->setCurrentIndex(lastActiveTabIndex);

//    // Создание layout для вкладки tab4
//    QVBoxLayout* tab4Layout = new QVBoxLayout(tab4);
//qDebug() << "НАЧАЛО Таб4 " << tabsCreatedTab4;
//    if (!tabsCreatedTab4) {
//         qDebug() << "!tabsCreatedTab4 Таб4 " << tabsCreatedTab4;
//        if (!vfvpmodel.lsVfvpLst.isEmpty()) {
//            tabIndex8 = 4;
//            tabWidget->insertTab(tabIndex8, tab4, "Ли[ lsvfvp ]");
//        }
//        if (vfvpmodel.lsVfvpLst.isEmpty()) {
//            tabIndex8 = tabWidget->indexOf(tab4);
//            tabWidget->removeTab(tabIndex8);
//            tabIndex8 = 4;
//        }

//        for (const LSVFVP& lsVfvp : vfvpmodel.lsVfvpLst) {
//            QList<QPair<QString, QString>> labelDataList = {
//                {"Колличество ", lsVfvp.lskolshtat},
//                {"Колличество в ", lsVfvp.lskolnal},
//                {"омпле", lsVfvp.lsukompl}
//            };

//            for (const auto& labelData : labelDataList) {
//                QLabel* label = new QLabel(labelData.first, tab4);
//                QLineEdit* lineEdit = new QLineEdit(tab4);
//                lineEdit->setObjectName(QString("TextEdit%1Tab4").arg(labelData.first));
//                lineEdit->setReadOnly(true);
//                lineEdit->setText(labelData.second);

//                tab4Layout->addWidget(label);
//                tab4Layout->addWidget(lineEdit);
//            }
//        }

//        // Добавление элемента растяжения
//        tab4Layout->addStretch(1);
//        tab4->setLayout(tab4Layout);

//        // Устанавливаем флаг, что вкладка была создана
//        tabsCreatedTab4 = true;
//    }

//    else {
//         qDebug() << "НАЧАЛО Таб4 перед else " << tabsCreatedTab4;
//        tabIndex8 = tabWidget->indexOf(tab4);

//        // Удаление текущего layout из tab4, если он существует
//        if (tab4->layout()) {
//            QLayout* currentLayout = tab4->layout();
//            QLayoutItem* item;
//            while ((item = currentLayout->takeAt(0)) != nullptr) {
//                delete item->widget();
//                delete item;
//            }
//            delete currentLayout;
//        }

//        tabIndex8 = tabWidget->indexOf(tab4);

//        if (!vfvpmodel.lsVfvpLst.isEmpty()) {
//            tabWidget->addTab(tab4, ("Ли [ lsvfvp ]"));
//            tabIndex8 = tabWidget->indexOf(tab4);

//            for (const LSVFVP& lsVfvp : vfvpmodel.lsVfvpLst) {
//                QVBoxLayout* newLayout = new QVBoxLayout(tab4);

//                QList<QPair<QString, QString>> labelDataList = {
//                    {"Колличество ", lsVfvp.lskolshtat},
//                    {"Колличество в ", lsVfvp.lskolnal},
//                    {"омпле", lsVfvp.lsukompl}
//                };

//                for (const auto& labelData : labelDataList) {
//                    QLabel* label = new QLabel(labelData.first, tab4);
//                    QLineEdit* lineEdit = new QLineEdit(tab4);
//                    lineEdit->setObjectName(QString("TextEdit%1Tab4").arg(labelData.first));
//                    lineEdit->setReadOnly(true);
//                    lineEdit->setText(labelData.second);

//                    newLayout->addWidget(label);
//                    newLayout->addWidget(lineEdit);
//                }

//                newLayout->addStretch(1);
//                tab4->setLayout(newLayout);
//            }
//        }
//        else {
//            tabWidget->removeTab(tabIndex8);
//        }
//    }

//    tabWidget->setCurrentIndex(lastActiveTabIndex);

//qDebug() << "КОНЕЦ Таб4 " << tabsCreatedTab4;
//}
///проверить
//        if (!tabsCreatedTab6) {
//            QVBoxLayout *tab6Layout = new QVBoxLayout(tab6);
//            tab6->setLayout(tab6Layout);

//            QVBoxLayout *groupBoxLayout = new QVBoxLayout();
//            QHBoxLayout *coordinatesLayout = new QHBoxLayout();
//            QHBoxLayout *coordinatesLayout2 = new QHBoxLayout();

//            QStringList labels = {
//                "Ключ знака ( уникальный идентификатор )",
//                "Код знака ( код серии знаков )",
//                "Тип знака (  )",
//                " 1я точка - расположение знака ",
//                "X:", "Y:",
//                " 2я точка - направление знака    ",
//                "X:", "Y:",
//                " Надпись внутри знака ",
//                "Ключ:", "Значение:",
//                " Надпись возле знака   ",
//                "Ключ:", "Значение:"
//            };

//            QVector<QLineEdit*> textEdits;

//            for (const QString &label : labels) {
//                QLabel *newLabel = new QLabel(label, tab6);
//                tab6Layout->addWidget(newLabel);

//                if (label.startsWith("X:") || label.startsWith("Y:")) {
//                    QLineEdit *lineEdit = new QLineEdit(tab6);
//                    lineEdit->setObjectName("TextEdit" + QString::number(textEdits.size() + 1) + "Tab6");
//                    lineEdit->setReadOnly(true);
//                    textEdits.append(lineEdit);

//                    if (label.startsWith("X:")) {
//                        coordinatesLayout->addWidget(newLabel);
//                        coordinatesLayout->addWidget(lineEdit);
//                    } else {
//                        coordinatesLayout2->addWidget(newLabel);
//                        coordinatesLayout2->addWidget(lineEdit);
//                    }
//                } else {
//                    QLineEdit *lineEdit = createReadOnlyLineEdit(tab6, "TextEdit" + QString::number(textEdits.size() + 1) + "Tab6");
//                    textEdits.append(lineEdit);
//                    tab6Layout->addWidget(lineEdit);
//                }
//            }

//            QGroupBox *groupBox = createGroupBoxWithLayout("Метрика", groupBoxLayout);
//            groupBoxLayout->addLayout(coordinatesLayout);
//            groupBoxLayout->addLayout(coordinatesLayout2);
//            tab6Layout->addWidget(groupBox);

//            QGroupBox *groupBox2 = createGroupBoxWithLayout("Семантика", groupBoxLayout);
//            QHBoxLayout *coordinatesLayoutS = new QHBoxLayout();
//            QHBoxLayout *coordinatesLayoutS2 = new QHBoxLayout();

//            labels = {
//                " Надпись внутри знака ",
//                "Ключ:", "Значение:",
//                " Надпись возле знака   ",
//                "Ключ:", "Значение:"
//            };

//            for (const QString &label : labels) {
//                QLabel *newLabel = new QLabel(label, tab6);
//                groupBox2->layout()->addWidget(newLabel);

//                if (label.startsWith(" Ключ:") || label.startsWith(" Значение:")) {
//                    QLineEdit *lineEdit = new QLineEdit(tab6);
//                    lineEdit->setObjectName("TextEdit" + QString::number(textEdits.size() + 1) + "Tab6");
//                    lineEdit->setReadOnly(true);
//                    textEdits.append(lineEdit);

//                    if (label.startsWith(" Ключ:")) {
//                        coordinatesLayoutS->addWidget(newLabel);
//                        coordinatesLayoutS->addWidget(lineEdit);
//                    } else {
//                        coordinatesLayoutS2->addWidget(newLabel);
//                        coordinatesLayoutS2->addWidget(lineEdit);
//                    }
//                }
//            }

//            groupBoxLayout->addLayout(coordinatesLayoutS);
//            groupBoxLayout->addLayout(coordinatesLayoutS2);
//            tab6Layout->addWidget(groupBox2);
//            tab6Layout->addStretch(1);
//            tabsCreatedTab6 = true;
//        }

//        if (!vfvpmodel.txfDataLst.isEmpty()) {
//            TXFDataWorker txfDataWorker(vfvpmodel.txfDataLst.at(0));
//            QVector<QPair<QString, QString>> metData = txfDataWorker.getMET();

//            if (metData.size() >= 2) {
//                textEdits[4]->setText(metData[0].first);
//                textEdits[5]->setText(metData[0].second);
//                textEdits[6]->setText(metData[1].first);
//                textEdits[7]->setText(metData[1].second);
//            }

//            QVector<QString> semList = txfDataWorker.getSEMList();

//            if (semList.size() >= 2) {
//                QString semKeyGui = semList[0];
//                QString semValue = txfDataWorker.getSEMValue(semKeyGui);
//                textEdits[8]->setText("SEM 1-> " + semKeyGui);
//                textEdits[9]->setText("SEM 1-> " + semValue);

//                QString semKey = semList[1];
//                QString semValue1 = txfDataWorker.getSEMValue(semKey);
//                textEdits[10]->setText("SEM 2-> " + semKey);
//                textEdits[11]->setText("SEM 2-> " + semValue1);
//            }
//        }






//    }
//}
   /// картографические данные [ kdou ] => modelView


// }

//        }
//    }
//}

    /// компактнее






//    if (!vfvpmodel.vvtVfsvLst.isEmpty()) {
//        tabWidget->insertTab(tabIndex, tab5, "ВВТ [ vvtvfvp ]");
    /// Проверяем и создаем вкладки для tab5. ВВТ [ vvtvfvp ] => modelView










  /// картографические данные [ kdou ] ( txf ) => modelView
  //textTab6Edit1->setText( txfDataWorker.createTxfData().toStdString().c_str() );
//}
   //  tabWidget->setCurrentIndex(0);
}

void MainWindow::createInnerTab6Widget() {

    int positionCount = 0;
    for (int i = 0; i < vfvpmodel.txfDataLst.size(); ++i) {
    TXFDataWorker& txfDataWorker = vfvpmodel.txfDataLst[i];
    if (txfDataWorker.getCOD_TYPE() == "VEC") {
    QWidget *innerTab6 = new QWidget(innerTab6Widget);
    innerTab6Widget->addTab(innerTab6, QString("Знак %1").arg(txfDataWorker.mCOD_TYPE_ , ++positionCount));
    QVBoxLayout *tab6Layout = new QVBoxLayout(innerTab6);
    innerTab6->setLayout(tab6Layout);

    QLabel *labelc1Tab6 = new QLabel(("Ключ знака ( уникальный идентификатор )"), innerTab6);
     QLabel *labelc2Tab6 = new QLabel(("Код знака ( код серии знаков )"), innerTab6);
     QLabel *labelc3Tab6 = new QLabel(("Тип знака (  )"), innerTab6);
     QLabel *labelc4Tab6 = new QLabel((" 1я точка - расположение знака "), innerTab6);
     QLabel *labelc5Tab6 = new QLabel(("X:"), innerTab6);
     QLabel *labelc6Tab6 = new QLabel(("Y:"), innerTab6);

     QLabel *labelc7Tab6 = new QLabel((" 2я точка - направление знака    "), innerTab6);
     QLabel *labelc8Tab6 = new QLabel(("X:"), innerTab6);
     QLabel *labelc9Tab6 = new QLabel(("Y:"), innerTab6);
     QLabel *labelc10Tab6 = new QLabel((" Надпись внутри знака "), innerTab6);
     QLabel *labelc11Tab6 = new QLabel(("Ключ:"), innerTab6);
     QLabel *labelc12Tab6 = new QLabel(("Значение:"), innerTab6);
     QLabel *labelc13Tab6 = new QLabel((" Надпись возле знака   "), innerTab6);
     QLabel *labelc14Tab6 = new QLabel(("Ключ:"), innerTab6);
     QLabel *labelc15Tab6 = new QLabel(("Значение:"), innerTab6);

     QLineEdit* textTab6Edit1 = new QLineEdit(innerTab6);
     textTab6Edit1->setObjectName("TextEdit1Tab6");
     QLineEdit* textTab6Edit2 = new QLineEdit(innerTab6);
     textTab6Edit2->setObjectName("TextEdit2Tab6");
     QLineEdit* textTab6Edit3 = new QLineEdit(innerTab6);
     textTab6Edit3->setObjectName("TextEdit3Tab6");

     QLineEdit* textTab6Edit4 = new QLineEdit(innerTab6);
     textTab6Edit4->setObjectName("TextEdit4Tab6");
     QLineEdit* textTab6Edit5 = new QLineEdit(innerTab6);
     textTab6Edit5->setObjectName("TextEdit5Tab6");

     QLineEdit* textTab6Edit6 = new QLineEdit(innerTab6);
     textTab6Edit6->setObjectName("TextEdit6Tab6");
     QLineEdit* textTab6Edit7 = new QLineEdit(innerTab6);
     textTab6Edit7->setObjectName("TextEdit7Tab6");

     QLineEdit* textTab6Edit8 = new QLineEdit(innerTab6);
     textTab6Edit8->setObjectName("TextEdit8Tab6");
     QLineEdit* textTab6Edit9 = new QLineEdit(innerTab6);
     textTab6Edit9->setObjectName("TextEdit9Tab6");
     QLineEdit* textTab6Edit10 = new QLineEdit(innerTab6);
     textTab6Edit10->setObjectName("TextEdit10Tab6");
     QLineEdit* textTab6Edit11 = new QLineEdit(innerTab6);
     textTab6Edit11->setObjectName("TextEdit11Tab6");

//     QList<QLineEdit*> textTab6EditsLe;
//     for (int i = 0; i < vfvpmodel.txfDataLst.size(); ++i) {
//   //  TXFDataWorker& txfDataWorker = vfvpmodel.txfDataLst[i];
//   //  for (int i = 0; i < txfDataWorker; ++i) {
//         QLineEdit* edit = new QLineEdit(innerTab6);
//         edit->setObjectName(QString("TextEdit%1Tab6").arg(i + 1));
//         textTab6EditsLe.append(edit);
//     }

//     const int numTextTab6Edits = 11;
//     QLineEdit* textTab6Edit[numTextTab6Edits];

//     for (int i = 1; i < numTextTab6Edits; ++i) {
//         textTab6Edit[i] = new QLineEdit(innerTab6);
//         textTab6Edit[i]->setObjectName(QString("TextEdit%1Tab6").arg(i + 1));
//     }

//     textTab6Edit2->setReadOnly(true);
//     textTab6Edit3->setReadOnly(true);
//     textTab6Edit4->setReadOnly(true);
//     textTab6Edit5->setReadOnly(true);
//     textTab6Edit6->setReadOnly(true);
//     textTab6Edit7->setReadOnly(true);
//     textTab6Edit8->setReadOnly(true);
//     textTab6Edit9->setReadOnly(true);
//     textTab6Edit10->setReadOnly(true);
//     textTab6Edit11->setReadOnly(true);
     QList<QLineEdit*> textTab6Edits = innerTab6->findChildren<QLineEdit*>(QString(), Qt::FindChildrenRecursively);
     for (QLineEdit* textTab6Edit : textTab6Edits) {
         QString objectName = textTab6Edit->objectName();
         if (objectName.startsWith("TextEdit") && objectName.endsWith("Tab6")) {
             textTab6Edit->setReadOnly(true);
         }
     }

     QHBoxLayout *coordinatesLayout = new QHBoxLayout();
     coordinatesLayout->addWidget(labelc4Tab6);

     coordinatesLayout->addWidget(labelc5Tab6);
     coordinatesLayout->addWidget(textTab6Edit4);
     coordinatesLayout->addWidget(labelc6Tab6);
     coordinatesLayout->addWidget(textTab6Edit5);

     QHBoxLayout *coordinatesLayout2 = new QHBoxLayout();
     coordinatesLayout2->addWidget(labelc7Tab6);

     coordinatesLayout2->addWidget(labelc8Tab6);
     coordinatesLayout2->addWidget(textTab6Edit6);
     coordinatesLayout2->addWidget(labelc9Tab6);
     coordinatesLayout2->addWidget(textTab6Edit7);

     QGroupBox *groupBox = new QGroupBox("Метрика");
     QVBoxLayout *groupBoxLayout =new QVBoxLayout();
     groupBoxLayout->addLayout(coordinatesLayout);
      groupBoxLayout->addLayout(coordinatesLayout2);

      groupBox->setLayout(groupBoxLayout);

      QHBoxLayout *coordinatesLayoutS = new QHBoxLayout();
      coordinatesLayoutS->addWidget(labelc10Tab6);
      coordinatesLayoutS->addWidget(labelc11Tab6);
      coordinatesLayoutS->addWidget(textTab6Edit8);
      coordinatesLayoutS->addWidget(labelc12Tab6);
      coordinatesLayoutS->addWidget(textTab6Edit9);

      QHBoxLayout *coordinatesLayoutS2 = new QHBoxLayout();
      coordinatesLayoutS2->addWidget(labelc13Tab6);

      coordinatesLayoutS2->addWidget(labelc14Tab6);
      coordinatesLayoutS2->addWidget(textTab6Edit10);
      coordinatesLayoutS2->addWidget(labelc15Tab6);
      coordinatesLayoutS2->addWidget(textTab6Edit11);

      QGroupBox *groupBox2 = new QGroupBox("Семантика");
      QVBoxLayout *groupBoxLayoutS =new QVBoxLayout();
      groupBoxLayoutS->addLayout(coordinatesLayoutS);
      groupBoxLayoutS->addLayout(coordinatesLayoutS2);
      groupBox2->setLayout(groupBoxLayoutS);

//     QHBoxLayout *coordinatesLayout = new QHBoxLayout();
//     coordinatesLayout->addWidget(labelc4Tab6);
//     coordinatesLayout->addWidget(labelc5Tab6);
//     coordinatesLayout->addWidget(textTab6EditsLe.at(2)); // textTab6Edit4
//     coordinatesLayout->addWidget(labelc6Tab6);
//     coordinatesLayout->addWidget(textTab6EditsLe.at(3)); // textTab6Edit5

//     QHBoxLayout *coordinatesLayout2 = new QHBoxLayout();
//     coordinatesLayout2->addWidget(labelc7Tab6);
//     coordinatesLayout2->addWidget(labelc8Tab6);
//     coordinatesLayout2->addWidget(textTab6EditsLe.at(4)); // textTab6Edit6
//     coordinatesLayout2->addWidget(labelc9Tab6);
//     coordinatesLayout2->addWidget(textTab6EditsLe.at(5)); // textTab6Edit7

//     QGroupBox *groupBox = new QGroupBox("Метрика");
//     QVBoxLayout *groupBoxLayout = new QVBoxLayout();
//     groupBoxLayout->addLayout(coordinatesLayout);
//     groupBoxLayout->addLayout(coordinatesLayout2);
//     groupBox->setLayout(groupBoxLayout);

//     QHBoxLayout *coordinatesLayoutS = new QHBoxLayout();
//     coordinatesLayoutS->addWidget(labelc10Tab6);
//     coordinatesLayoutS->addWidget(labelc11Tab6);
//     coordinatesLayoutS->addWidget(textTab6EditsLe.at(6)); // textTab6Edit8
//     coordinatesLayoutS->addWidget(labelc12Tab6);
//     coordinatesLayoutS->addWidget(textTab6EditsLe.at(7)); // textTab6Edit9

//     QHBoxLayout *coordinatesLayoutS2 = new QHBoxLayout();
//     coordinatesLayoutS2->addWidget(labelc13Tab6);
//     coordinatesLayoutS2->addWidget(labelc14Tab6);
//     coordinatesLayoutS2->addWidget(textTab6EditsLe.at(8)); // textTab6Edit10
//     coordinatesLayoutS2->addWidget(labelc15Tab6);
//     coordinatesLayoutS2->addWidget(textTab6EditsLe.at(9)); // textTab6Edit11

//     QGroupBox *groupBox2 = new QGroupBox("Семантика");
//     QVBoxLayout *groupBoxLayoutS = new QVBoxLayout();
//     groupBoxLayoutS->addLayout(coordinatesLayoutS);
//     groupBoxLayoutS->addLayout(coordinatesLayoutS2);
//     groupBox2->setLayout(groupBoxLayoutS);

      if ( !vfvpmodel.txfDataLst.isEmpty() ) {

                //  tabWidget->insertTab(tabIndex5, tab6, "Картографические данные [ kdou ]");

      TXFDataWorker txfDataWorker( vfvpmodel.txfDataLst.at( i ) );
      textTab6Edit1->setText( txfDataWorker.getKEY() );
      textTab6Edit2->setText( txfDataWorker.getCOD() );
      textTab6Edit3->setText( txfDataWorker.getCOD_TYPE() );
      textTab6Edit4->setText( txfDataWorker.getMET().at( 0 ).first);
      textTab6Edit5->setText( txfDataWorker.getMET().at( 0 ).second);
      textTab6Edit6->setText( txfDataWorker.getMET().at( 1 ).first);
      textTab6Edit7->setText( txfDataWorker.getMET().at( 1 ).second);
      QString semKeyGui( txfDataWorker.getSEMList().at( 0 ) );
      QString semValue = ( txfDataWorker.getSEMValue( semKeyGui ));
      textTab6Edit8->setText("SEM 1-> " + semKeyGui);
      textTab6Edit9->setText("SEM 1-> " + semValue);
      QString semKey( txfDataWorker.getSEMList().at( 1 ) );
      QString semValue1 = ( txfDataWorker.getSEMValue( semKey ));
      textTab6Edit10->setText("SEM 2-> " + semKey );
      textTab6Edit11->setText("SEM 2-> " + semValue1);
      tab6Layout->addWidget(labelc1Tab6);
      tab6Layout->addWidget(textTab6Edit1);
      tab6Layout->addWidget(labelc2Tab6);
      tab6Layout->addWidget(textTab6Edit2);
      tab6Layout->addWidget(labelc3Tab6);
      tab6Layout->addWidget(textTab6Edit3);
      tab6Layout->addWidget(groupBox);
      tab6Layout->addWidget(groupBox2);
      tab6Layout->addStretch(1);
      }

      }

//    if (txfDataWorker.mCOD_TYPE_ == "SQR" || txfDataWorker.mCOD_TYPE_ == "LIN") {
        if (txfDataWorker.getCOD_TYPE() == "SQR" || txfDataWorker.mCOD_TYPE_ == "LIN") {
    QWidget *innerTab6 = new QWidget(innerTab6Widget);
    innerTab6Widget->addTab(innerTab6, QString("Знак %1").arg(txfDataWorker.mCOD_TYPE_ , ++positionCount));
    QVBoxLayout *tab6Layout = new QVBoxLayout(innerTab6);
    innerTab6->setLayout(tab6Layout);

    QLabel *labelc1Tab6 = new QLabel(("Ключ знака ( уникальный идентификатор )"), innerTab6);
     QLabel *labelc2Tab6 = new QLabel(("Код знака ( код серии знаков )"), innerTab6);
     QLabel *labelc3Tab6 = new QLabel(("Тип знака (  )"), innerTab6);
     QLabel *labelc4Tab6 = new QLabel((" 1я точка - расположение знака "), innerTab6);
     QLabel *labelc5Tab6 = new QLabel(("X:"), innerTab6);
     QLabel *labelc6Tab6 = new QLabel(("Y:"), innerTab6);

     QLabel *labelc7Tab6 = new QLabel((" 2я точка - направление знака    "), innerTab6);
     QLabel *labelc8Tab6 = new QLabel(("X:"), innerTab6);
     QLabel *labelc9Tab6 = new QLabel(("Y:"), innerTab6);
     QLabel *labelc10Tab6 = new QLabel((" Надпись внутри знака "), innerTab6);
     QLabel *labelc11Tab6 = new QLabel(("Ключ:"), innerTab6);
     QLabel *labelc12Tab6 = new QLabel(("Значение:"), innerTab6);
     QLabel *labelc13Tab6 = new QLabel((" Надпись возле знака   "), innerTab6);
     QLabel *labelc14Tab6 = new QLabel(("Ключ:"), innerTab6);
     QLabel *labelc15Tab6 = new QLabel(("Значение:"), innerTab6);

     QLineEdit* textTab6Edit1 = new QLineEdit(innerTab6);
     textTab6Edit1->setObjectName("TextEdit1Tab6");
     QLineEdit* textTab6Edit2 = new QLineEdit(innerTab6);
     textTab6Edit2->setObjectName("TextEdit2Tab6");
     QLineEdit* textTab6Edit3 = new QLineEdit(innerTab6);
     textTab6Edit3->setObjectName("TextEdit3Tab6");

     QLineEdit* textTab6Edit4 = new QLineEdit(innerTab6);
     textTab6Edit4->setObjectName("TextEdit4Tab6");
     QLineEdit* textTab6Edit5 = new QLineEdit(innerTab6);
     textTab6Edit5->setObjectName("TextEdit5Tab6");

     QLineEdit* textTab6Edit6 = new QLineEdit(innerTab6);
     textTab6Edit6->setObjectName("TextEdit6Tab6");
     QLineEdit* textTab6Edit7 = new QLineEdit(innerTab6);
     textTab6Edit7->setObjectName("TextEdit7Tab6");

     QLineEdit* textTab6Edit8 = new QLineEdit(innerTab6);
     textTab6Edit8->setObjectName("TextEdit8Tab6");
     QLineEdit* textTab6Edit9 = new QLineEdit(innerTab6);
     textTab6Edit9->setObjectName("TextEdit9Tab6");
     QLineEdit* textTab6Edit10 = new QLineEdit(innerTab6);
     textTab6Edit10->setObjectName("TextEdit10Tab6");
     QLineEdit* textTab6Edit11 = new QLineEdit(innerTab6);
     textTab6Edit11->setObjectName("TextEdit11Tab6");

     QList<QLineEdit*> textTab6Edits = innerTab6->findChildren<QLineEdit*>(QString(), Qt::FindChildrenRecursively);
     for (QLineEdit* textTab6Edit : textTab6Edits) {
         QString objectName = textTab6Edit->objectName();
         if (objectName.startsWith("TextEdit") && objectName.endsWith("Tab6")) {
             textTab6Edit->setReadOnly(true);
         }
     }

     QHBoxLayout *coordinatesLayout = new QHBoxLayout();
     coordinatesLayout->addWidget(labelc4Tab6);

     coordinatesLayout->addWidget(labelc5Tab6);
     coordinatesLayout->addWidget(textTab6Edit4);
     coordinatesLayout->addWidget(labelc6Tab6);
     coordinatesLayout->addWidget(textTab6Edit5);

     QHBoxLayout *coordinatesLayout2 = new QHBoxLayout();
     coordinatesLayout2->addWidget(labelc7Tab6);

     coordinatesLayout2->addWidget(labelc8Tab6);
     coordinatesLayout2->addWidget(textTab6Edit6);
     coordinatesLayout2->addWidget(labelc9Tab6);
     coordinatesLayout2->addWidget(textTab6Edit7);

     QGroupBox *groupBox = new QGroupBox("Метрика");
     QVBoxLayout *groupBoxLayout =new QVBoxLayout();
     groupBoxLayout->addLayout(coordinatesLayout);
      groupBoxLayout->addLayout(coordinatesLayout2);

      groupBox->setLayout(groupBoxLayout);

      QHBoxLayout *coordinatesLayoutS = new QHBoxLayout();
      coordinatesLayoutS->addWidget(labelc10Tab6);
      coordinatesLayoutS->addWidget(labelc11Tab6);
      coordinatesLayoutS->addWidget(textTab6Edit8);
      coordinatesLayoutS->addWidget(labelc12Tab6);
      coordinatesLayoutS->addWidget(textTab6Edit9);

      QHBoxLayout *coordinatesLayoutS2 = new QHBoxLayout();
      coordinatesLayoutS2->addWidget(labelc13Tab6);

      coordinatesLayoutS2->addWidget(labelc14Tab6);
      coordinatesLayoutS2->addWidget(textTab6Edit10);
      coordinatesLayoutS2->addWidget(labelc15Tab6);
      coordinatesLayoutS2->addWidget(textTab6Edit11);

      QGroupBox *groupBox2 = new QGroupBox("Семантика");
      QVBoxLayout *groupBoxLayoutS =new QVBoxLayout();
      groupBoxLayoutS->addLayout(coordinatesLayoutS);
      groupBoxLayoutS->addLayout(coordinatesLayoutS2);
      groupBox2->setLayout(groupBoxLayoutS);


      if ( !vfvpmodel.txfDataLst.isEmpty() ) {

                //  tabWidget->insertTab(tabIndex5, tab6, "Картографические данные [ kdou ]");

      TXFDataWorker txfDataWorker( vfvpmodel.txfDataLst.at( i ) );
      textTab6Edit1->setText( txfDataWorker.getKEY() );
      textTab6Edit2->setText( txfDataWorker.getCOD() );
      textTab6Edit3->setText( txfDataWorker.getCOD_TYPE() );
      textTab6Edit4->setText( txfDataWorker.getMET().at( 0 ).first);
      textTab6Edit5->setText( txfDataWorker.getMET().at( 0 ).second);
      textTab6Edit6->setText( txfDataWorker.getMET().at( 1 ).first);
      textTab6Edit7->setText( txfDataWorker.getMET().at( 1 ).second);
      QString semKeyGui( txfDataWorker.getSEMList().at( 0 ) );
      QString semValue = ( txfDataWorker.getSEMValue( semKeyGui ));
      textTab6Edit8->setText( semKeyGui);
      textTab6Edit9->setText( semValue);
      QString semKey( txfDataWorker.getSEMList().at( 1 ) );
      QString semValue1 = ( txfDataWorker.getSEMValue( semKey ));
      textTab6Edit10->setText( semKey );
      textTab6Edit11->setText(semValue1);
      tab6Layout->addWidget(labelc1Tab6);
      tab6Layout->addWidget(textTab6Edit1);
      tab6Layout->addWidget(labelc2Tab6);
      tab6Layout->addWidget(textTab6Edit2);
      tab6Layout->addWidget(labelc3Tab6);
      tab6Layout->addWidget(textTab6Edit3);
      tab6Layout->addWidget(groupBox);
      tab6Layout->addWidget(groupBox2);
      tab6Layout->addStretch(1);
      }

      }

    }
       tabWidget->setCurrentIndex(activeTabIndex);
}

//void MainWindow::createTabWidget()
//{
//    tabWidget = new QTabWidget(this);
//    tab6 = new QWidget(tabWidget);
//    tabWidget->addTab(tab6, "Какие-то данные");
//    QVBoxLayout *tab6Layout = new QVBoxLayout(tab6);
//    tab6->setLayout(tab6Layout);

//    QList<QPair<QString, QString>> labels;  // Список QLabel для точек и надписей
//    labels.append(qMakePair(" точка - расположение знака    ", "X:"));
//    labels.append(qMakePair("Y:", ""));
//    labels.append(qMakePair(" точка - вектора знака    ", "X:"));
//    labels.append(qMakePair("Y:", ""));
//    labels.append(qMakePair(" Надпись внутри знака ", "Ключ:"));
//    labels.append(qMakePair("Значение:", ""));
//    labels.append(qMakePair(" Надпись возле знака   ", "Ключ:"));
//    labels.append(qMakePair("Значение:", ""));

//    QList<QPair<QString, QLineEdit *>> lineEdits;  // Список QLineEdit для значений точек и надписей

//    int count = vfvpmodel.txfDataLst.count();
//    if (count > 1) {
//        for (int i = 0; i < count; i++) {
//            QWidget *dynamicTab = new QWidget(tabWidget);
//            QString tabName = "знак " + QString::number(i + 1);
//            tabWidget->addTab(dynamicTab, tabName);

//            QVBoxLayout *dynamicLayout = new QVBoxLayout(dynamicTab);

//            for (auto label : labels) {
//                QLabel *dynamicLabel = new QLabel(label.first, dynamicTab);
//                QLineEdit *lineEdit = new QLineEdit(dynamicTab);
//                lineEdits.append(qMakePair(label.second, lineEdit));

//                QHBoxLayout *layout = new QHBoxLayout();
//                layout->addWidget(dynamicLabel);
//                layout->addWidget(lineEdit);
//                dynamicLayout->addLayout(layout);
//            }

//            dynamicTab->setLayout(dynamicLayout);
//        }
//    } else {
//        for (auto label : labels) {
//            QLabel *dynamicLabel = new QLabel(label.first, tab6);
//            QLineEdit *lineEdit = new QLineEdit(tab6);
//            lineEdits.append(qMakePair(label.second, lineEdit));

//            QHBoxLayout *layout = new QHBoxLayout();
//            layout->addWidget(dynamicLabel);
//            layout->addWidget(lineEdit);
//            tab6Layout->addLayout(layout);
//        }
//    }

//    // Добавление значений в QLineEdit
//    if (!vfvpmodel.txfDataLst.isEmpty()) {
//        TXFDataWorker txfDataWorker(vfvpmodel.txfDataLst.at(0));
//        textTab6Edit1->setText(txfDataWorker.getKEY());
//        textTab6Edit2->setText(txfDataWorker.getCOD());
//        textTab6Edit3->setText(txfDataWorker.getCOD_TYPE());

//        for (auto lineEdit : lineEdits) {
//            QString key = lineEdit.first;
//            QLineEdit *edit = lineEdit.second;
//            QString value = "";

//            if (key == "X:")
//                value = txfDataWorker.getPOINT().x();
//                            else if (key == "Y:")
//                                value = txfDataWorker.getPOINT().y();
//                            else if (key == "Ключ:")
//                                value = txfDataWorker.getKEY();
//                            else if (key == "Значение:")
//                                value = txfDataWorker.getVAL();

//                            edit->setText(value);
//                        }
//                    }
//                }
/// проверить
//    if (!tabsCreatedTab6) {
//        QVBoxLayout *tab6Layout = new QVBoxLayout(tab6);
//        tab6->setLayout(tab6Layout);

//        QVBoxLayout *groupBoxLayout = new QVBoxLayout();
//        QHBoxLayout *coordinatesLayout = new QHBoxLayout();
//        QHBoxLayout *coordinatesLayout2 = new QHBoxLayout();

//        QStringList labels = {
//            "Ключ знака ( уникальный идентификатор )",
//            "Код знака ( код серии знаков )",
//            "Тип знака (  )",
//            " 1я точка - расположение знака ",
//            "X:", "Y:",
//            " 2я точка - направление знака    ",
//            "X:", "Y:",
//            " Надпись внутри знака ",
//            "Ключ:", "Значение:",
//            " Надпись возле знака   ",
//            "Ключ:", "Значение:"
//        };

//        QVector<QLineEdit*> textEdits;

//        for (const QString &label : labels) {
//            QLabel *newLabel = new QLabel(label, tab6);
//            tab6Layout->addWidget(newLabel);

//            if (label.startsWith("X:") || label.startsWith("Y:")) {
//                QLineEdit *lineEdit = new QLineEdit(tab6);
//                lineEdit->setObjectName("TextEdit" + QString::number(textEdits.size() + 1) + "Tab6");
//                lineEdit->setReadOnly(true);
//                textEdits.append(lineEdit);

//                if (label.startsWith("X:")) {
//                    coordinatesLayout->addWidget(newLabel);
//                    coordinatesLayout->addWidget(lineEdit);
//                } else {
//                    coordinatesLayout2->addWidget(newLabel);
//                    coordinatesLayout2->addWidget(lineEdit);
//                }
//            } else {
//                QLineEdit *lineEdit = createReadOnlyLineEdit(tab6, "TextEdit" + QString::number(textEdits.size() + 1) + "Tab6");
//                textEdits.append(lineEdit);
//                tab6Layout->addWidget(lineEdit);
//            }
//        }

//        QGroupBox *groupBox = createGroupBoxWithLayout("Метрика", groupBoxLayout);
//        groupBoxLayout->addLayout(coordinatesLayout);
//        groupBoxLayout->addLayout(coordinatesLayout2);
//        tab6Layout->addWidget(groupBox);

//        QGroupBox *groupBox2 = createGroupBoxWithLayout("Семантика", groupBoxLayout);
//        QHBoxLayout *coordinatesLayoutS = new QHBoxLayout();
//        QHBoxLayout *coordinatesLayoutS2 = new QHBoxLayout();

//        labels = {
//            " Надпись внутри знака ",
//            "Ключ:", "Значение:",
//            " Надпись возле знака   ",
//            "Ключ:", "Значение:"
//        };

//        for (const QString &label : labels) {
//            QLabel *newLabel = new QLabel(label, tab6);
//            groupBox2->layout()->addWidget(newLabel);

//            if (label.startsWith(" Ключ:") || label.startsWith(" Значение:")) {
//                QLineEdit *lineEdit = new QLineEdit(tab6);
//                lineEdit->setObjectName("TextEdit" + QString::number(textEdits.size() + 1) + "Tab6");
//                lineEdit->setReadOnly(true);
//                textEdits.append(lineEdit);

//                if (label.startsWith(" Ключ:")) {
//                    coordinatesLayoutS->addWidget(newLabel);
//                    coordinatesLayoutS->addWidget(lineEdit);
//                } else {
//                    coordinatesLayoutS2->addWidget(newLabel);
//                    coordinatesLayoutS2->addWidget(lineEdit);
//                }
//            }
//        }

//        groupBoxLayout->addLayout(coordinatesLayoutS);
//        groupBoxLayout->addLayout(coordinatesLayoutS2);
//        tab6Layout->addWidget(groupBox2);
//        tab6Layout->addStretch(1);
//        tabsCreatedTab6 = true;
//    }

//    if (!vfvpmodel.txfDataLst.isEmpty()) {
//        TXFDataWorker txfDataWorker(vfvpmodel.txfDataLst.at(0));
//        QVector<QPair<QString, QString>> metData = txfDataWorker.getMET();

//        if (metData.size() >= 2) {
//            textEdits[4]->setText(metData[0].first);
//            textEdits[5]->setText(metData[0].second);
//            textEdits[6]->setText(metData[1].first);
//            textEdits[7]->setText(metData[1].second);
//        }

//        QVector<QString> semList = txfDataWorker.getSEMList();

//        if (semList.size() >= 2) {
//            QString semKeyGui = semList[0];
//            QString semValue = txfDataWorker.getSEMValue(semKeyGui);
//            textEdits[8]->setText("SEM 1-> " + semKeyGui);
//            textEdits[9]->setText("SEM 1-> " + semValue);

//            QString semKey = semList[1];
//            QString semValue1 = txfDataWorker.getSEMValue(semKey);
//            textEdits[10]->setText("SEM 2-> " + semKey);
//            textEdits[11]->setText("SEM 2-> " + semValue1);
//        }
//    }
