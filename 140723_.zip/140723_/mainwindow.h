#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QTreeView>
#include <QStandardItemModel>
#include <QTabWidget>
#include <QLineEdit>
#include <QTextEdit>
#include <QWidget>
#include <QScrollArea>
#include <QLabel>
#include <QMap>
#include <QGridLayout>
#include <QTreeWidgetItem>
#include <QtWidgets/QScrollBar>
#include <QWidget>
#include "vfvpmodel/include/vfvpmodel.h"

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
    int activeTabIndex;
    int tabIndex2;
   int tabIndex3;
   int tabIndex4;
  int  tabIndex5;
  int  tabIndex8;


   // int tabIndex4;
bool hasParent(VFVPModel* vfvpModel);
void createChildItems(QStandardItem* parentItem, QList<QStandardItem*>& topLevelItems);
QStandardItem* createTreeItem(VFVPModel* vfvpModel);
QList<VFVPModel *> getVfvpModelLst() const;
void setVfvpModelLst();
//int tabIndex;
//int tabIndex2;
void createInnerTab6Widget();
private:
    void createTreeView();
    void createTabWidget();
    void setModel( VFVPModel &vfvpmodel );
     void setModel1( VFVPModel &vfvpmodel );
     void setModel2( VFVPModel &vfvpmodel );
     void setModel3( VFVPModel &vfvpmodel );
     void setModel4( VFVPModel &vfvpmodel );
void createInnerTab(QWidget* parent, const POSVFVP& posVfvp);
///добавил
bool tabsCreatedTab6 = false;
bool tabsCreatedTab3 = false;
bool tabsCreatedTab5 = false;
bool tabsCreatedTab4 = false;
bool tabsCreated = false; // Объявление переменной tabsCreated
void onTreeViewItemClickedTab2();
void onTreeViewItemClickedTab5();

private slots:
   void onTreeViewItemClicked(const QModelIndex &modelIndex);

private:
   QVBoxLayout *tab4Layout;
   QMap<QTreeWidgetItem*, int> activeTabMap;
   QHBoxLayout *rowLayout1;
QHBoxLayout *rowLayout2;
    QTreeView *treeView;
       QScrollArea *scrollArea;
    QStandardItemModel *model;
    QTabWidget *tabWidget;
    QWidget *tab1, *tab2, *tab3, *tab4, *tab5, *tab6;
    QLineEdit *textEditsTab6;
    QLineEdit *textTab6Edit1, *textTab6Edit2, *textTab6Edit3, *textTab6Edit4, *textTab6Edit5, *textTab6Edit6, *textTab6Edit7, *textTab6Edit8, *textTab6Edit9, *textTab6Edit10, *textTab6Edit11, *textTab6Edit12;
    QTextEdit *textTab5Edit1, *textTab5Edit2, *textTab5Edit3, *textTab5Edit4, *textTab5Edit5;
    QLineEdit *leTab1Edit1, *textTab4Edit2, *textTab4Edit3, *textTab4Edit4;
    QScrollBar *verticalScrollBar;
     VFVPModel  vfvpModel, vfvpModel1, vfvpModel2, vfvpModel3, vfvpModel4, vfvpmodel, vfvpModel5;
    QMap <QString, VFVPModel*> vfvpMap;
//QGridLayout *tab5Layout;
QStandardItem *childItem;
 QTabWidget *innerTab5Widget, *innerTab3Widget, *innerTab6Widget;
  QTabWidget *innerTabWidget; // Объявление вкладок как члена класса
   //  QList < VFVPModel * > vfvpModelLst, vfvpModelLst_orig;
 //  POSVFVP& posVfvp : vfvpmodel.posVfvpLst;
};

#endif // MAINWINDOW_H
