#include "connectdatabase.h"
//#include "mainwindow.h"
#include <QSettings>
#include <QMessageBox>
#include <QSqlError>
#include <QSqlQuery>
#include <QtSql/QSqlDatabase>
ConnectDatabase::ConnectDatabase(QObject *parent)
    : QObject{parent}
{

}
void ConnectDatabase::checkDatabaseConnection()
{
    QSettings settings("config.conf", QSettings::IniFormat);

    emit databaseConnected(
                connectToDatabase(
                    settings.value("DataBase/host").toString(),
                    settings.value("DataBase/port").toInt(),
                    settings.value("DataBase/name").toString(),
                    settings.value("DataBase/user").toString(),
                    settings.value("DataBase/pass").toString()
                    ));
}

bool ConnectDatabase::connectToDatabase(const QString &host, int port, const QString &databaseName,
                                       const QString &userName, const QString &password)
{
//    // Закрываем предыдущее подключение, если оно существует (костыль)
//        if (QSqlDatabase::contains("qt_sql_default_connection")) {
//            QSqlDatabase::database("qt_sql_default_connection").close();
//            QSqlDatabase::removeDatabase("qt_sql_default_connection");
//        }
    closeDatabaseConnection();

        QSqlDatabase db = QSqlDatabase::addDatabase("QPSQL"/*, "qt_sql_default_connection"*/);

    db.setHostName(host);
    db.setPort(port);
    db.setDatabaseName(databaseName);
    db.setUserName(userName);
    db.setPassword(password);
    if (!db.open()) {
        QMessageBox::critical(nullptr, "Ошибка подключения к серверу!", db.lastError().text());
//         QMessageBox msgBox =  new QMessageBox;
//         msgBox critical(nullptr, "Ошибка подключения к серверу!", db.lastError().text());
       }
    else  {
        QMessageBox::information(nullptr, "Успешное подключение", "Подключение к серверу установлено!");
    }
    bool connected = db.open();

    return connected;

}
void ConnectDatabase::closeDatabaseConnection()
{
    // Закрытие соединения с базой данных
    QSqlDatabase::database().close();
    QSqlDatabase::removeDatabase(QSqlDatabase::defaultConnection);
}
