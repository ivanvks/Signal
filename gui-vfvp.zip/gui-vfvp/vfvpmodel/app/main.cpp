#include <QCoreApplication>
#include <QDebug>
#include <QDateTime>

#include "include/vfvpmodel.h"

/// задаем модель данных
void setModel( VFVPModel &vfvpmodel ){

    /// Учетный номер ВФВП
    vfvpmodel.charVfvp.vfvp_kod = "18200000004000040";
    /// Организационно-штатная принадлежность
    vfvpmodel.charVfvp.vfvp_org = "18200000004000040";
    /// Дата и время состояния
    vfvpmodel.charVfvp.vfvp_dt  = QDateTime::currentDateTime();

    POSVFVP posVfvp; /// инициализируем модель данных положения воинского формирования
    /// наименование блока данных координат
    posVfvp.description = QString( "pvfvp" );
    /// геодезическая широта
    posVfvp.latitude    = QString( "56.314014573" );
    /// геодезическая долгота
    posVfvp.longitude   = QString( "42.911885365" );
    /// высота
    posVfvp.height      = QString( "404" );
    /// пояснение
    posVfvp.OK          = QString( "Позиция на высоте 404" );
    /// добавляем модель данных положения воинского формирования в коллекцию
    vfvpmodel.posVfvpLst.append( posVfvp );

    LSVFVP lsVfvp; /// инициализируем модель данных личного состава
    /// наименование блока личного состава
    lsVfvp.description = QString( "личный состав" );
    /// колличество по штату личного состава
    lsVfvp.kolshtat    = QString( "300" );
    /// колличество в наличии личного состава
    lsVfvp.kolnal      = QString( "30" );
    /// укомплектованность личного состава ( на самом деле 10, но так красивее ;-)
    lsVfvp.ukompl      = QString( "3" );
    /// добавляем модель данных личного состава в коллекцию
    vfvpmodel.lsVfvpLst.append( lsVfvp );

    VVTVFVP vvtVfvp; /// инициализируем модель данных ВВТ
    /// наименование блока ВВТ
    vvtVfvp.description = QString( "ВВТ" );
    /// код по классификатору "Конкретные образцы оружия и военной техники"
    vvtVfvp.kkoovt_kod  = QString( "5025200" ); /// М706(V-100) "КОММАНДО"
    /// колличество по штату ВВТ
    vvtVfvp.kolshtat    = QString( "300" );
    /// колличество в наличии ВВТ
    vvtVfvp.kolnal      = QString( "30" );
    /// укомплектованность ВВТ ( ну Вы поняли => 10 )
    vvtVfvp.ukompl      = QString( "3" );
    /// добавляем модель данных ВВТ в коллекцию
    vfvpmodel.vvtVfsvLst.append( vvtVfvp );

    /** пример файла данных ГИС векторный
     *****************************
     * .KEY V77708012            *
     * .COD 77708012 VEC         *
     * .MET 1                    *
     * 2                         *
     * 56.314014573 42.911885365 *
     * 56.962916333 44.038253903 *
     * .SEM 2                    *
     * 5400 10 дшд               *
     * 9216 КП                   *
     *****************************
    **/

    /// инициализируем модель картографических данных
    TXFDataWorker txfDataWorker;
    /// ключ знака ( уникальный идентификатор )
    txfDataWorker.setKEY( "V77708012" );
    /// код знака ( код серии знаков )
    txfDataWorker.setCOD( "77708012" );
    /// тип знака ( векторный / линейный / площадной ) => VEC - векторный
    txfDataWorker.setCOD_TYPE( "VEC" );
    /// метрика знака
    /// координаты объекта ( 1я точка - расположение знака )
    txfDataWorker.setMETValue( "56.314014573", "42.911885365" );
    /// координаты объекта ( 2я точка - направление знака )
    txfDataWorker.setMETValue( "56.962916333", "44.038253903" );
    /// семантика знака
    /// надпись внутри знака
    txfDataWorker.setSEMValue( "5400", "10 дшд" );
    /// надпись возле знака
    txfDataWorker.setSEMValue( "9216", "КП" );
    /// добавляем модель картографических данных в коллекцию
    vfvpmodel.txfDataLst.append( txfDataWorker );
};

/// отображаем модель данных
void showModel( const VFVPModel &vfvpmodel )
{    qDebug() << "Модель данных ТВФ в части ВФВП";

    /// характеристики ВФВП [ vfvp ]
    qDebug() << "характеристики ВФВП [ vfvp ]:";
    qDebug() << "vfvp_kod => " << vfvpmodel.charVfvp.vfvp_kod;
    qDebug() << "vfvp_org => " << vfvpmodel.charVfvp.vfvp_org;
    qDebug() << "vfvp_dt  => " << vfvpmodel.charVfvp.vfvp_dt;

    /// положение воинского формирования [ pvfvp ]
    qDebug() << "положение воинского формирования [ pvfvp ]:";
    qDebug() << "description => " << vfvpmodel.posVfvpLst.value( 0 ).description;
    qDebug() << "latitude    => " << vfvpmodel.posVfvpLst.value( 0 ).latitude;
    qDebug() << "longitude   => " << vfvpmodel.posVfvpLst.value( 0 ).longitude;
    qDebug() << "height      => " << vfvpmodel.posVfvpLst.value( 0 ).height;
    qDebug() << "OK          => " << vfvpmodel.posVfvpLst.value( 0 ).OK;

    /// личный состав [ lsvfvp ]
    qDebug() << "личный состав [ lsvfvp ]:";
    qDebug() << "description => " << vfvpmodel.lsVfvpLst.value( 0 ).description;
    qDebug() << "kolshtat    => " << vfvpmodel.lsVfvpLst.value( 0 ).kolshtat;
    qDebug() << "kolnal      => " << vfvpmodel.lsVfvpLst.value( 0 ).kolnal;
    qDebug() << "ukompl      => " << vfvpmodel.lsVfvpLst.value( 0 ).ukompl;

    /// ВВТ [ vvtvfvp ]
    qDebug() << "ВВТ [ vvtvfvp ]:";
    qDebug() << "description => " << vfvpmodel.vvtVfsvLst.value( 0 ).description;
    qDebug() << "kkoovt_kod  => " << vfvpmodel.vvtVfsvLst.value( 0 ).kkoovt_kod;
    qDebug() << "kolshtat    => " << vfvpmodel.vvtVfsvLst.value( 0 ).kolshtat;
    qDebug() << "kolnal      => " << vfvpmodel.vvtVfsvLst.value( 0 ).kolnal;
    qDebug() << "ukompl      => " << vfvpmodel.vvtVfsvLst.value( 0 ).ukompl;

    /// картографические данные [ kdou ]
    qDebug() << "картографические данные [ kdou ]:";
    TXFDataWorker txfDataWorker( vfvpmodel.txfDataLst.at( 0 ) );
    qDebug() << "KEY      => " << txfDataWorker.getKEY();
    qDebug() << "COD      => " << txfDataWorker.getCOD();
    qDebug() << "COD_TYPE => " << txfDataWorker.getCOD_TYPE();
    qDebug() << "MET 1    => " << txfDataWorker.getMET().at( 0 );
    qDebug() << "MET 2    => " << txfDataWorker.getMET().at( 1 );
    QString semKey( txfDataWorker.getSEMList().at( 0 ) );
    qDebug() << "SEM 1    => " << semKey << txfDataWorker.getSEMValue( semKey );
    semKey = txfDataWorker.getSEMList().at( 1 );
    qDebug() << "SEM 2    => " << semKey << txfDataWorker.getSEMValue( semKey );

    /// картографические данные [ kdou ] ( txf )
    qDebug() << "картографические данные [ kdou ] ( txf ):";
    qDebug() << txfDataWorker.createTxfData().toStdString().c_str();
};

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);

    /// инициализируем модель данных
    VFVPModel vfvpmodel;
    /// задаем модель данных
    setModel( vfvpmodel );
    VFVPModel vfvpModel_new(vfvpmodel);
    /// отображаем модель данных
    showModel( vfvpModel_new );

    exit(0);
    return a.exec();
}
