#ifndef VFVPMODEL_H
#define VFVPMODEL_H

#include <QObject>
#include <QDateTime>
#include <QList>
#include <QString>

#include "../txfworker/include/txfdata.h"

struct CHARVFVP{
    /// le
    QString vfvp_kod;
    QString vfvp_dlkod;
    QDateTime vfvp_dt;
    QString vfvp_num;
    QString ktvfig_kod;
    QString kvvsig_kod;
    QString krvig_kod;
    QString vfvp_org;

    QString oksm_kod;
    QString ksmt_kod;
    QString kuvf_kod;
    QString ktor_kod;

    QString vfvp_name;
    QString vfvp_sname;

    QString vfvp_kod_esutz;

    QDateTime vfvp_vro;
    QString vfvp_numc;
    QString vfvp_numcnew;
    QString ksuo_kod;
    QString kpo_kod;
    QString kio_kod;
    QString kdo_kod;
    QString kir_kod;
    QString vfvp_bp;

    QString vfvp_importance;
    QString vfvp_info; /// te

    /// характер действий [ hdvfvp ]
    QString kod_khdvf;
    /// боеспособность [ bsvfvp ]
    QString kod_ksbs;
    /// высота [ heightvfvp ]
    QString height;
};

struct POSVFVP{
    /// le
    QString description;
    QString latitude;
    QString longitude;
    QString height;
    QString OK; /// te
};

struct LSVFVP{
    /// le
    QString description;
    QString kolshtat;
    QString kolnal;
    QString ukompl;
};

struct VVTVFVP{
    /// le
    QString description;
    QString kkoovt_kod;
    QString kolshtat;
    QString kolnal;
    QString ukompl;
};

class VFVPModel : public QObject
{
    Q_OBJECT

public:
    CHARVFVP                charVfvp;
    QList < POSVFVP       > posVfvpLst;
    QList < TXFDataWorker > txfDataLst;
    QList < LSVFVP        > lsVfvpLst;
    QList < VVTVFVP       > vvtVfsvLst;

public:
    explicit VFVPModel( QObject *parent = nullptr );

    explicit VFVPModel( const VFVPModel &other, QObject *parent = nullptr );

    explicit VFVPModel( const CHARVFVP &charact,
                        const QList < POSVFVP > &posVfvpLst, const QList < TXFDataWorker > &txfDataLst,
                        const QList < LSVFVP  > &lsVfvpLst , const QList < VVTVFVP       > &vvtVfsvLst,
                        QObject *parent = nullptr );

    ~VFVPModel();

    VFVPModel& operator = ( const VFVPModel &vfvpModel );
};

#endif // VFVPMODEL_H
