#include "../include/vfvpmodel.h"

VFVPModel::VFVPModel( QObject *parent )
    : QObject( parent ) {}

VFVPModel::VFVPModel( const VFVPModel &other, QObject *parent )
    : QObject( parent ), charVfvp( other.charVfvp ),
      posVfvpLst( other.posVfvpLst ), txfDataLst( other.txfDataLst ),
      lsVfvpLst( other.lsVfvpLst ), vvtVfsvLst( other.vvtVfsvLst ) {}

VFVPModel::VFVPModel(const CHARVFVP &charVfvp,
                     const QList < POSVFVP > &posVfvpLst, const QList < TXFDataWorker > &txfDataLst,
                     const QList < LSVFVP  > &lsVfvpLst , const QList < VVTVFVP       > &vvtVfsvLst,
                     QObject *parent)
    : QObject( parent ), charVfvp( charVfvp ),
      posVfvpLst( posVfvpLst ), txfDataLst( txfDataLst ),
      lsVfvpLst( lsVfvpLst ), vvtVfsvLst( vvtVfsvLst ) {}

VFVPModel::~VFVPModel(){
    posVfvpLst.clear();
    lsVfvpLst.clear();
    vvtVfsvLst.clear();
    txfDataLst.clear();
}

VFVPModel& VFVPModel::operator = ( const VFVPModel &vfvpModel ) {
    this->charVfvp   = vfvpModel.charVfvp;
    this->posVfvpLst = vfvpModel.posVfvpLst;
    this->txfDataLst = vfvpModel.txfDataLst;
    this->lsVfvpLst  = vfvpModel.lsVfvpLst;
    this->vvtVfsvLst = vfvpModel.vvtVfsvLst;

    return *this;
}
