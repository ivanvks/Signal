#include <QCoreApplication>
#include <QDebug>

#include "../include/txfdata.h"

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);

    TXFDataWorker txfDataWorker;
    txfDataWorker.setKEY( "009991001011020600010000000100" );
    txfDataWorker.setCOD( "400" );
    txfDataWorker.setCOD_TYPE( "LIN" );
    txfDataWorker.setMETValue( "58.607944130", "27.269784900" );
    txfDataWorker.setMETValue( "58.620305590", "27.350499310" );
    txfDataWorker.setSEMValue( "5400", "10 дшд" );

    qDebug() << txfDataWorker.createTxfData().toStdString().c_str();

    exit(0);
    return a.exec();
}
