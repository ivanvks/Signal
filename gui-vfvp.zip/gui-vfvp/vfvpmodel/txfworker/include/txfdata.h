/***************************************************************************
 *   Author:  Koshurnikov A.A.                                             *
 *   E-mail:  KoshurnikovAA@niissu.ru                                      *
 *   Date:    2023-03                                                      *
 *   Summary: Работа с TXF данными ( текстовый формат SXF данных )         *
 *   License: NIISSU                                                       *
 ***************************************************************************/

#ifndef TXFDATA_H
#define TXFDATA_H

#include <QObject>
#include <QMap>

/** пример файла данных ГИС векторный
 *****************************
 * .KEY V77708012            *
 * .COD 77708012 VEC         *
 * .MET 2                    *
 * 1                         *
 * 56.314014573 42.911885365 *
 * 2                         *
 * 56.314014573 42.911885365 *
 * 56.962916333 44.038253903 *
 * .SEM 2                    *
 * 5400 10 дшд               *
 * 9216 КП                   *
 *****************************
**/
/** пример файла данных ГИС линейный
*****************************
* .KEY L77702012            *
* .COD 77702012 LIN         *
* .SPL POINTS               *
* .MET 1                    *
* 5                         *
* 56.322578786 42.904816528 *
* 56.329171349 42.927361353 *
* 56.315762757 42.944789991 *
* 56.304513808 42.921156386 *
* 56.310890111 42.895355858 *
* .SEM 1                    *
* 5400 10 дшд               *
*****************************
**/
/** пример файла данных ГИС площадной
*****************************
* .KEY S77702012            *
* .COD 77702012 SQR         *
* .SPL POINTS               *
* .MET 1                    *
* 5                         *
* 56.322578786 42.904816528 *
* 56.329171349 42.927361353 *
* 56.315762757 42.944789991 *
* 56.304513808 42.921156386 *
* 56.310890111 42.895355858 *
* .SEM 1                    *
* 5400 10 дшд               *
*****************************
**/

/**
 * @brief The TXFDataWorker class - Класс работы с TXF данными ( текстовый формат SXF данных )
 */
class TXFDataWorker : public QObject
{
    Q_OBJECT

    /// ключ знака ( уникальный идентификатор )
    QString mKEY_;
    /// код знака ( код серии знаков )
    QString mCOD_;
    /// тип знака ( векторный / линейный / площадной )
    QString mCOD_TYPE_;
    /// колекция координат ( метрика знака )
    QVector < QPair < QString, QString > > mMET_;
    /// колекция параметров ( семантика знака )
    QMap < QString, QString > mSEM_;
    /// коллекция типов знака
    QStringList mCodTypeLst_;
    /// типы перечислений знака
    enum enumCODType {
        VEC,    /// тип знака векторный
        LIN,    /// тип знака линейный
        SQR     /// тип знака площадной
    };

public:
    /**
     * @brief TXFDataWorker - Конструктор работы с TXF данными ( инициализация )
     * @param parent        - родительский объект ( QObject )
     */
    explicit TXFDataWorker( QObject *parent = nullptr );
    /**
     * @brief TXFDataWorker - Конструктор работы с TXF данными ( инициализация + разбор )
     * @param txfData       - содержимое TXF данных
     * @param parent        - родительский объект ( QObject )
     */
    explicit TXFDataWorker( const QString &txfData, QObject *parent = nullptr );

    /**
     * @brief TXFDataWorker - Конструктор работы с TXF данными ( копирование )
     * @param txfDataWorker - объект класса работы с TXF данными
     * @param parent        - родительский объект ( QObject )
     */
    explicit TXFDataWorker( const TXFDataWorker &txfDataWorker, QObject *parent = nullptr );

    /**
     * @brief operator =    - Оператор копирования класса работы с TXF данными
     * @param txfDataWorker - объект класса работы с TXF данными
     * @return
     */
    TXFDataWorker &operator=( const TXFDataWorker &txfDataWorker );

    /**
     * @brief getKEY - Метод получения значения поля mKEY_
     * @return       - значение поля mKEY_
     */
    QString getKEY() const;
    /**
     * @brief setKEY - Метод задания значения поля mKEY_
     * @param newKEY - значение поля mKEY_
     */
    void setKEY( const QString &newKEY );

    /**
     * @brief getCOD - Метод получения значения поля mCOD_
     * @return       - значение поля mCOD_
     */
    QString getCOD() const;
    /**
     * @brief setCOD - Метод задания значения поля mCOD_
     * @param newCOD - значение поля mCOD_
     */
    void setCOD( const QString &newCOD );

    /**
     * @brief getCOD_TYPE - Метод получения значения поля mCOD_TYPE_
     * @return            - значение поля mCOD_TYPE_
     */
    QString getCOD_TYPE() const;
    /**
     * @brief setCOD_TYPE - Метод задания значения поля mCOD_TYPE_
     * @param newCOD_TYPE - значение поля mCOD_TYPE_
     */
    void setCOD_TYPE( const QString &newCOD_TYPE );

    /**
     * @brief getMET - Метод получения значения поля mMET_
     * @return       - значение поля mMET_
     */
    QVector < QPair < QString, QString > > getMET() const;
    /**
     * @brief setMET - Метод задания значения поля mMET_
     * @param newMET - значение поля mMET_
     */
    void setMET( const QVector < QPair < QString, QString > > &newMET );
    /**
     * @brief setMETValue - Метод добавления значения элемента поля mMET_
     * @param latitude    - значение геодезической широты
     * @param longitude   - значение геодезической долготы
     */
    void setMETValue( const QString &latitude, const QString &longitude );

    /**
     * @brief getSEM - Метод получения значения поля mMET_
     * @return       - значение поля mMET_
     */
    QMap < QString, QString > getSEM() const;
    /**
     * @brief setSEM - Метод задания значения поля mSEM_
     * @param newSEM - значение поля mSEM_
     */
    void setSEM( const QMap < QString, QString > &newSEM );
    /**
     * @brief getSEMList - Метод получения значения поля mSEM_
     * @return           - значение поля mSEM_
     */
    QStringList getSEMList();
    /**
     * @brief setSEMValue - Метод добавления значения элемента поля mSEM_
     * @param newSEMKey   - ключ семантики
     * @param newSEMValue - значение смантики
     */
    void setSEMValue( const QString &newSEMKey, const QString &newSEMValue );
    /**
     * @brief getSEMValue - Метод получения значения элемента поля mSEM_
     * @param keySEM      - ключ семантики
     * @return            - значение семантики
     */
    QString getSEMValue( const QString &keySEM );

    /**
     * @brief createTxfData - Создание TXF данных
     * @return              - содержимое TXF данных
     */
    QString createTxfData();

    /**
     * @brief parseTxfData - Разбор TXF данных
     * @param txfData      - содержимое TXF данных
     */
    void parseTxfData( const QString& txfData );
};

#endif // TXFDATA_H
