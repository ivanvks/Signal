#include "../include/txfdata.h"

/// Метод получения значения поля mKEY_
QString TXFDataWorker::getKEY() const
{
    return mKEY_;
}

/// Метод задания значения поля mKEY_
void TXFDataWorker::setKEY( const QString &newKEY )
{
    mKEY_ = newKEY;
}
 /// Метод получения значения поля mCOD_
QString TXFDataWorker::getCOD() const
{
    return mCOD_;
}

/// Метод задания значения поля mCOD_
void TXFDataWorker::setCOD( const QString &newCOD )
{
    mCOD_ = newCOD;
}

/// Метод получения значения поля mCOD_TYPE_
QString TXFDataWorker::getCOD_TYPE() const
{
    return mCOD_TYPE_;
}

/// Метод задания значения поля mCOD_TYPE_
void TXFDataWorker::setCOD_TYPE( const QString &newCOD_TYPE )
{
    mCOD_TYPE_ = newCOD_TYPE;
}

/// Метод получения значения поля mMET_
QVector < QPair < QString, QString > > TXFDataWorker::getMET() const
{
    return mMET_;
}

/// Метод задания значения поля mMET_
void TXFDataWorker::setMET( const QVector < QPair < QString, QString > > &newMET )
{
    mMET_ = newMET;
}

/// Метод добавления значения элемента поля mMET_
void TXFDataWorker::setMETValue( const QString &latitude, const QString &longitude )
{
    mMET_.append( qMakePair( latitude, longitude ) );
}

/// Метод получения значения поля mMET_
QMap < QString, QString > TXFDataWorker::getSEM() const
{
    return mSEM_;
}

/// Метод задания значения поля mSEM_
void TXFDataWorker::setSEM( const QMap < QString, QString > &newSEM )
{
    mSEM_ = newSEM;
}

/// Метод получения значения поля mSEM_
QStringList TXFDataWorker::getSEMList()
{
    return mSEM_.keys();
}

/// Метод добавления значения элемента поля mSEM_
void TXFDataWorker::setSEMValue( const QString &newSEMKey, const QString &newSEMValue )
{
    mSEM_.insert( newSEMKey,newSEMValue );
}

/// Метод получения значения элемента поля mSEM_
QString TXFDataWorker::getSEMValue( const QString &keySEM )
{
    return mSEM_.value( keySEM );
}

/// Конструктор работы с TXF данными ( инициализация )
TXFDataWorker::TXFDataWorker( QObject *parent )
    : QObject{ parent }
{
    /// задаем коллекцию типов знака
    mCodTypeLst_ = QStringList() << "VEC" << "LIN" << "SQR";
}

/// Конструктор работы с TXF данными ( инициализация + разбор )
TXFDataWorker::TXFDataWorker( const QString &txfData, QObject *parent )
    : QObject{ parent }
{
    /// задаем коллекцию типов знака
    mCodTypeLst_ = QStringList() << "VEC" << "LIN" << "SQR";
    /// разбираем TXF данные
    parseTxfData( txfData );
}

/// Конструктор работы с TXF данными ( копирование )
TXFDataWorker::TXFDataWorker( const TXFDataWorker &txfDataWorker, QObject *parent )
    : QObject( parent ), mKEY_( txfDataWorker.mKEY_ ), mCOD_( txfDataWorker.mCOD_ ),
    mCOD_TYPE_( txfDataWorker.mCOD_TYPE_ ), mMET_( txfDataWorker.mMET_ ),
    mSEM_( txfDataWorker.mSEM_ ), mCodTypeLst_( txfDataWorker.mCodTypeLst_ ) {}

/// Оператор копирования класса работы с TXF данными
TXFDataWorker &TXFDataWorker::operator=( const TXFDataWorker &txfDataWorker )
{
    this->mKEY_        = txfDataWorker.mKEY_;
    this->mCOD_        = txfDataWorker.mCOD_;
    this->mCOD_TYPE_   = txfDataWorker.mCOD_TYPE_;
    this->mMET_        = txfDataWorker.mMET_;
    this->mSEM_        = txfDataWorker.mSEM_;
    this->mCodTypeLst_ = txfDataWorker.mCodTypeLst_;

    return *this;
}

/// Создание TXF данных
QString TXFDataWorker::createTxfData()
{
    /// ключ знака ( уникальный идентификатор )
    QString key( QString( ".KEY %1" ).arg( mKEY_ ) );
    /// код знака ( код серии знаков )
    QString cod( QString( ".COD %1" ).arg( mCOD_ ) );
    /// тип знака ( векторный / линейный / площадной )
    switch ( mCodTypeLst_.indexOf( mCOD_TYPE_ ) ) {
    case VEC: /// ( векторный )
        cod.append( " VEC" );
        break;
    case LIN: /// ( линейный  ) ( метод отрисовки области сплайнами )
        cod.append( " LIN\n" ).append( ".SPL POINTS" );
        break;
    case SQR: /// ( площадной ) ( метод отрисовки области сплайнами )
        cod.append( " SQR\n" ).append( ".SPL POINTS" );
        break;
    default:  /// ( векторный )
        cod.append( " VEC" );
        break;
    }
    if ( !mCOD_.isEmpty() ) /// проверка присутствия типа знака
        key.append( '\n' ).append( cod );
    /// инициализируем метрику знака ( число подобъектов )
    QStringList met( QString( ".MET %1" ).arg( "1" ) );
    /// задем колличество координат
    int metCount = mMET_.count();
    /// координаты объекта ( линейные ( площадные ) объекты -> 3+ пары координат )
    met.append( QString::number( metCount ) );
    /// задаем координаты ( максимальная длина координаты -> 12 символов )
    for ( int i = 0; i < metCount; ++ i ) {
        met.append( QString( "%1 %2" )
                    .arg( mMET_.at( i ).first.left( 12 ), mMET_.at( i ).second.left( 12 ) ) );
    }
    /// инициализируем семантику знака ( атрибуты ( надписи ) )
    QStringList semKeys( mSEM_.keys() ), sem( QString( ".SEM %1" ).arg( semKeys.count() ) );
    /// задаем семантику знака
    foreach ( const QString &semKey , semKeys ) {
        sem.append( QString( "%1 %2" ).arg( semKey ,mSEM_.value( semKey ) ) );
    }
    /// готовый набор данных
    QStringList sxfData( QStringList() << key << met.join( '\n' ) << sem.join( '\n' ) );
    /// возвращаем готовый набор данных в виде строки
    return sxfData.join( "\n" );
}

/// Разбор TXF данных
void TXFDataWorker::parseTxfData( const QString& txfData )
{
    /// инициализируем коллекцию блоков данных TXF
    QStringList gisList( txfData.split( '\x04' ).at( 1 ).split( '\n' ) );
    /// перебираем построчно данные гис
    for ( int i = 0; i < gisList.count(); ++ i ) {
        /// ищим строку типа .KEY ( ключ знака )
        if ( gisList.at( i ).contains( ".KEY" ) )
            /// задем ключ знака
            mKEY_ = gisList.at( i ).split( ' ' ).last();
        /// ищим строку типа .COD ( код знака )
        if ( gisList.at( i ).contains( ".COD" ) ) {
            /// задем код знака
            mCOD_      = gisList.at( i ).split( ' ' ).at( 1 );
            /// задем тип знака
            mCOD_TYPE_ = gisList.at( i ).split( ' ' ).last();
        }
        /// ищим строку типа .МЕТ ( метрика знака )
        /// фильтр типа "57.606320239 27.506331047"
        /// QRegExp( "^[0-9]{1,2}\\.[0-9]{4,}\\s[0-9]{1,2}\\.[0-9]{4,}$" )
        if ( gisList.at( i ).contains( ".MET" ) )
        {
            /// колличество блоков координат
            int metCount = gisList.at( i ).split( ' ' ).last().toInt();
            /// начальная позиция координат
            int metNum = i + 2;
            /// колличество координат
            int crdCount = gisList.at( i + 1 ).toInt();
            /// определяем тип блоков координат ( КП? )
            if ( metCount > 1 ) {
                /// задаем смещение начальной позиции координат типа КП
                metNum += 2;
                /// задаем колличество координат типа КП
                crdCount = gisList.at( i + 3 ).toInt();
            }
            /// получаем набор координат
            for ( int j = metNum, npp = 1; j < metNum + crdCount; ++ j, ++ npp ) {
                /// инициализируем пару координат
                QStringList metStr( gisList.at( j ).split( ' ' ) );
                /// добавляем пару координат в коллекцию
                mMET_ << qMakePair( metStr.first(), metStr.last() );
            }
            /// задаем конец блока координат
            i = metNum + crdCount;
        }
        /// ищим строку типа .SEM ( семантика знака )
        if ( gisList.at( i ).contains( ".SEM" ) )
        {
            /// задаем счетчик семантик знака
            int semCount = gisList.at( i ).split( ' ' ).last().toInt();
            /// получаем параметры семантик
            for ( int num = i + 1; num < i + 1 + semCount; ++ num ) {
                /// инициализируем параметр семантики ( ключ значение )
                QStringList semStr( gisList.at( num ).split( ' ' ) );
                /// инициализируем ключ семантики
                QString semKey( semStr.takeFirst() );
                /// инициализируем значение семантики
                QString semVal( semStr.join( ' ' ) );
                /// добавляем параметр семантики в коллекцию
                mSEM_.insert( semKey, semVal );
            }
            break;
        }
    }
}
