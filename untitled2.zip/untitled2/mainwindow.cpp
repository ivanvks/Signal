#include "mainwindow.h"

TrayMenu::TrayMenu(QObject *parent)
    : QObject(parent)
{
    createTrayIcon();
    createTrayMenu();
}

TrayMenu::~TrayMenu()
{
    delete trayIcon;
    delete trayMenu;
}

void TrayMenu::createTrayIcon()
{
    trayIcon = new QSystemTrayIcon(this);
    QIcon icon(":/image/image/tray.png");
    trayIcon->setIcon(icon);
    trayIcon->show();
}

void TrayMenu::createTrayMenu()
{
    trayMenu = new QMenu();

    QAction *action1 = new QAction("Action 1", trayMenu);
    connect(action1, &QAction::triggered, this, &TrayMenu::onAction1Triggered);
    trayMenu->addAction(action1);

    trayMenu->addSeparator();

    QAction *action2 = new QAction("Action 2", trayMenu);
    connect(action2, &QAction::triggered, this, &TrayMenu::onAction2Triggered);
    trayMenu->addAction(action2);

    trayIcon->setContextMenu(trayMenu);
}

void TrayMenu::onAction1Triggered()
{
    // Действия при выборе Action 1
}

void TrayMenu::onAction2Triggered()
{
    // Действия при выборе Action 2
}
