#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QSystemTrayIcon>
#include <QMenu>

class TrayMenu : public QObject
{
    Q_OBJECT

public:
    explicit TrayMenu(QObject *parent = nullptr);
    ~TrayMenu();

private:
    QSystemTrayIcon *trayIcon;
    QMenu *trayMenu;

    void createTrayIcon();
    void createTrayMenu();

private slots:
    void onAction1Triggered();
    void onAction2Triggered();
};

#endif // MAINWINDOW_H
